package com.valdoria.rpg.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Aura colada no corpo do jogador: casca brilhante do modelo + chamas/raios. */
public class AuraBodyLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    private static final ResourceLocation SWIRL = new ResourceLocation("textures/entity/creeper/creeper_armor.png");

    public AuraBodyLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> p) { super(p); }

    @Override
    public void render(PoseStack ps, MultiBufferSource buf, int light, AbstractClientPlayer pl,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        if (pl != Minecraft.getInstance().player || !ClientData.auraActive) return;
        int lv = ClientData.auraEquipped;
        if (lv <= 0 || lv > PlayerData.AURA_MAX) return;

        float[] c = GokuAura.palette(lv);
        float pulse = 0.75F + 0.25F * (float) Math.sin(ageInTicks * 0.3F);

        // casca brilhante moldada no corpo (escala em torno do centro do corpo)
        float s = 1.07F + 0.02F * (float) Math.sin(ageInTicks * 0.4F);
        ps.pushPose();
        ps.translate(0.0D, 0.6D, 0.0D);
        ps.scale(s, s, s);
        ps.translate(0.0D, -0.6D, 0.0D);
        var vc = buf.getBuffer(RenderType.energySwirl(SWIRL, (ageInTicks * 0.01F) % 1.0F, (ageInTicks * 0.015F) % 1.0F));
        getParentModel().renderToBuffer(ps, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                c[0] * 0.7F * pulse, c[1] * 0.7F * pulse, c[2] * 0.7F * pulse, 1.0F);
        ps.popPose();

        // chamas e raios rente ao corpo (Y para cima)
        ps.pushPose();
        ps.translate(0.0D, 1.501D, 0.0D);
        ps.scale(-1.0F, -1.0F, 1.0F);
        GokuAura.draw(ps, buf.getBuffer(RenderType.lightning()), ageInTicks, c,
                lv / 7.0F, 0.42F, 1.9F + lv * 0.08F, 0.5F, lv >= 3);
        ps.popPose();
    }
}
