package com.valdoria.rpg.client.renderer;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.util.Mth;

/**
 * Spirit Aura (chamas + raios), por nível: 1 Verdante, 2 Radiante, 3 Brasa, 4 Carmesim, 5 Arcana, 6 Glacial, 7 Onipotente.
 * Chamado em RenderLevelStageEvent (AFTER_ENTITIES) a partir de ClientEvents.
 */
public final class SpiritAuraRenderer {
    private SpiritAuraRenderer() {}

    private static long tickCounter = 0;

    public static void clientTick() { tickCounter++; }

    public static void render(PoseStack poseStack, float partialTick) {
        if (!ClientData.auraActive) return;
        int lv = ClientData.auraEquipped;
        if (lv <= 0 || lv > PlayerData.AURA_MAX) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        var p = mc.player;

        double px = Mth.lerp(partialTick, p.xo, p.getX());
        double py = Mth.lerp(partialTick, p.yo, p.getY());
        double pz = Mth.lerp(partialTick, p.zo, p.getZ());

        float alpha = mc.options.getCameraType().isFirstPerson() ? 0.12F : 0.55F;

        poseStack.pushPose();
        poseStack.translate(px, py, pz);

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        GokuAura.draw(poseStack, buf, tickCounter + partialTick, GokuAura.palette(lv),
                lv / 7.0F, 0.5F, 1.9F + lv * 0.08F, alpha, lv >= 3);
        tess.end();

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        poseStack.popPose();
    }
}
