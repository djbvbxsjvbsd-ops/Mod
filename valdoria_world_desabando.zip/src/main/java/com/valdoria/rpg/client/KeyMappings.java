package com.valdoria.rpg.client;

import com.mojang.blaze3d.platform.InputConstants;
import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD,
        value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class KeyMappings {
    private KeyMappings() {}

    private static final String CAT = "key.category." + ValdoriaMod.MODID;

    public static final KeyMapping PROFILE = new KeyMapping(
            "key." + ValdoriaMod.MODID + ".profile",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_P, CAT);

    public static final KeyMapping MAP = new KeyMapping(
            "key." + ValdoriaMod.MODID + ".map",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, CAT);

    public static final KeyMapping HUD = new KeyMapping(
            "key." + ValdoriaMod.MODID + ".hud",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, CAT);

    public static final KeyMapping CLASS_SCR = new KeyMapping(
            "key." + ValdoriaMod.MODID + ".class",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_C, CAT);

    public static final KeyMapping WHIRLPOOL = new KeyMapping(
            "key." + ValdoriaMod.MODID + ".whirlpool",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, CAT);

    /** G — ligar/desligar Spirit Aura atual. */
    public static final KeyMapping SPIRIT_AURA = new KeyMapping(
            "key." + ValdoriaMod.MODID + ".spirit_aura",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CAT);

    /** Shift+G — avançar para próximo nível de aura (consome 1 token). */
    public static final KeyMapping SPIRIT_AURA_ADVANCE = new KeyMapping(
            "key." + ValdoriaMod.MODID + ".spirit_aura_advance",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, CAT);

    /** B — abrir Hub de Mundos (Lobby). */
    public static final KeyMapping WORLD_HUB = new KeyMapping(
            "key." + ValdoriaMod.MODID + ".world_hub",
            InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_B, CAT);

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent e) {
        e.register(PROFILE);
        e.register(MAP);
        e.register(HUD);
        e.register(CLASS_SCR);
        e.register(WHIRLPOOL);
        e.register(SPIRIT_AURA);
        e.register(WORLD_HUB);
        // SPIRIT_AURA_ADVANCE usa a mesma tecla mas checaremos Shift manualmente no tick
    }
}
