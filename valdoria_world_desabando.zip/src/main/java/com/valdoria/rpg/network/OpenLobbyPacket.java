package com.valdoria.rpg.network;

import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Enviado pelo servidor para abrir o WorldHubScreen no cliente. */
public class OpenLobbyPacket {
    public OpenLobbyPacket() {}

    public static void encode(OpenLobbyPacket p, FriendlyByteBuf buf) {}
    public static OpenLobbyPacket decode(FriendlyByteBuf buf) { return new OpenLobbyPacket(); }

    public void handle(NetworkEvent.Context ctx) {
        ctx.enqueueWork(() -> {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null && mc.screen == null) {
                mc.setScreen(new com.valdoria.rpg.client.screen.WorldHubScreen());
            }
        });
        ctx.setPacketHandled(true);
    }
}
