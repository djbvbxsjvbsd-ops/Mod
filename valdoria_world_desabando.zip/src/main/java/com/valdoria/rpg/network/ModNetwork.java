package com.valdoria.rpg.network;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "7";  // bumped: TeleportWorldPacket + OpenLobbyPacket
    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ValdoriaMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);
    private static int id = 0;
    private ModNetwork() {}

    public static void register() {
        INSTANCE.messageBuilder(SyncDataPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncDataPacket::encode).decoder(SyncDataPacket::decode)
                .consumerMainThread((msg, ctx) -> SyncDataPacket.handle(msg, () -> ctx.get())).add();
        INSTANCE.messageBuilder(OpenFactionPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenFactionPacket::encode).decoder(OpenFactionPacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();
        INSTANCE.messageBuilder(FactionChoicePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(FactionChoicePacket::encode).decoder(FactionChoicePacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();
        INSTANCE.messageBuilder(SyncNiveriaPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncNiveriaPacket::encode).decoder(SyncNiveriaPacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();
        INSTANCE.messageBuilder(ClassChangePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ClassChangePacket::encode).decoder(ClassChangePacket::decode)
                .consumerMainThread((msg, ctx) -> ClassChangePacket.handle(msg, () -> ctx.get())).add();
        INSTANCE.messageBuilder(WhirlpoolPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(WhirlpoolPacket::encode).decoder(WhirlpoolPacket::decode)
                .consumerMainThread((msg, ctx) -> WhirlpoolPacket.handle(msg, () -> ctx.get())).add();
        INSTANCE.messageBuilder(SyncQuestTargetPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncQuestTargetPacket::encode).decoder(SyncQuestTargetPacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();
        INSTANCE.messageBuilder(SyncEspPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncEspPacket::encode).decoder(SyncEspPacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();
        INSTANCE.messageBuilder(SpiritAuraPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SpiritAuraPacket::encode).decoder(SpiritAuraPacket::decode)
                .consumerMainThread((msg, ctx) -> SpiritAuraPacket.handle(msg, () -> ctx.get())).add();
        // Cutscene final — quest 101
        INSTANCE.messageBuilder(EndingCutscenePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(EndingCutscenePacket::encode).decoder(EndingCutscenePacket::decode)
                .consumerMainThread((msg, ctx) -> EndingCutscenePacket.handle(msg, () -> ctx.get())).add();
        // Hub de mundos — cliente pede teleporte / servidor abre tela
        INSTANCE.messageBuilder(TeleportWorldPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(TeleportWorldPacket::encode).decoder(TeleportWorldPacket::decode)
                .consumerMainThread((msg, ctx) -> TeleportWorldPacket.handle(msg, () -> ctx.get())).add();
        INSTANCE.messageBuilder(OpenLobbyPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenLobbyPacket::encode).decoder(OpenLobbyPacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();
    }

    public static void sync(ServerPlayer p) {
        sendTo(p, SyncDataPacket.from(p));
        boolean inNiveria = p.level().dimension().location().toString().equals("valdorianrpg:niveria");
        int frags = com.valdoria.rpg.quest.QuestManager.count(p, "valdorianrpg:fragmento_glacial");
        sendTo(p, new SyncNiveriaPacket(inNiveria, frags));
        syncQuestTarget(p);
    }

    public static void syncQuestTarget(ServerPlayer p) {
        int done = com.valdoria.rpg.data.PlayerData.getCompleted(p);
        int questId = done + 1;
        if (questId > com.valdoria.rpg.quest.QuestData.size()) {
            sendTo(p, new SyncQuestTargetPacket(0, "", 0));
            sendTo(p, new SyncEspPacket(0, "", java.util.List.of()));
            return;
        }
        com.valdoria.rpg.quest.Quest q = com.valdoria.rpg.quest.QuestData.get(questId);
        int type = switch (q.type()) {
            case KILL  -> 1;
            case HAVE  -> 2;
            default    -> 3;
        };
        sendTo(p, new SyncQuestTargetPacket(type, q.target(), questId));
        com.valdoria.rpg.quest.EspTracker.send(p);
    }

    public static void sendTo(ServerPlayer p, Object msg) {
        INSTANCE.send(PacketDistributor.PLAYER.with(() -> p), msg);
    }
}
