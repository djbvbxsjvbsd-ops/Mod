// [CastleBuilder.java] — Castelo Valdoria ENORME: 60x60 base, 70+ blocos de altura
// 4 andares reais, nave central gótica, 6 torres imponentes — inspirado na imagem
package com.valdoria.rpg.world;

import com.valdoria.rpg.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.DoorHingeSide;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.block.state.properties.StairsShape;
import net.minecraft.world.level.levelgen.Heightmap;

public final class CastleBuilder {
    private CastleBuilder() {}

    // ============================================================
    //  ENTRY POINTS
    // ============================================================
    public static void build(ServerLevel level, int stage) {
        ServerLevel ow = level.getServer().getLevel(Level.OVERWORLD);
        if (ow == null) return;
        BlockPos spawn = ow.getSharedSpawnPos();
        int groundY = ow.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn.getX(), spawn.getZ());
        BlockPos origin = new BlockPos(spawn.getX(), groundY, spawn.getZ());
        buildAt(ow, origin, stage);
    }

    public static void build(ServerLevel level, BlockPos ignored, int stage) {
        build(level, stage);
    }

    // ============================================================
    //  DISPATCHER — 16 estágios ligados ao nível do jogador
    // ============================================================
    private static void buildAt(ServerLevel lvl, BlockPos o, int stage) {
        // Sempre aplica todos os estágios anteriores (castelo cumulativo)
        if (stage >= 1)  { clearTerrain(lvl, o); buildStage1(lvl, o); }  // lv 5
        if (stage >= 2)  buildStage2(lvl, o);   // lv 10 — muralha externa
        if (stage >= 3)  buildStage3(lvl, o);   // lv 15 — 4 torres cantos muralha
        if (stage >= 4)  buildStage4(lvl, o);   // lv 20 — nave central (corpo principal)
        if (stage >= 5)  buildStage5(lvl, o);   // lv 25 — 1º andar (grande salão)
        if (stage >= 6)  buildStage6(lvl, o);   // lv 30 — 2º andar (câmara do conselho)
        if (stage >= 7)  buildStage7(lvl, o);   // lv 35 — 2 torres frontais imponentes
        if (stage >= 8)  buildStage8(lvl, o);   // lv 40 — 2 torres traseiras altas
        if (stage >= 9)  buildStage9(lvl, o);   // lv 45 — 3º andar (biblioteca)
        if (stage >= 10) buildStage10(lvl, o);  // lv 50 — 4º andar (sala do trono)
        if (stage >= 11) buildStage11(lvl, o);  // lv 55 — torre central (spire máximo)
        if (stage >= 12) buildStage12(lvl, o);  // lv 60 — ala norte (portal de Nivéria)
        if (stage >= 13) buildStage13(lvl, o);  // lv 65 — ala sul (pátio + capelinha)
        if (stage >= 14) buildStage14(lvl, o);  // lv 70 — sala de treino + estábulo
        if (stage >= 15) buildStage15(lvl, o);  // lv 75 — decoração total + iluminação
        if (stage >= 16) buildStage16(lvl, o);  // lv 80 — estado final: relíquias, bandeiras
    }

    // ============================================================
    //  HELPERS GENÉRICOS
    // ============================================================
    private static void p(ServerLevel l, int x, int y, int z, BlockState b) {
        l.setBlockAndUpdate(new BlockPos(x, y, z), b);
    }

    private static void fill(ServerLevel l, int x1, int y1, int z1, int x2, int y2, int z2, BlockState b) {
        for (int x = Math.min(x1,x2); x <= Math.max(x1,x2); x++)
            for (int y = Math.min(y1,y2); y <= Math.max(y1,y2); y++)
                for (int z = Math.min(z1,z2); z <= Math.max(z1,z2); z++)
                    l.setBlockAndUpdate(new BlockPos(x, y, z), b);
    }

    private static void fillHollow(ServerLevel l, int x1, int y1, int z1, int x2, int y2, int z2, BlockState w) {
        for (int x = Math.min(x1,x2); x <= Math.max(x1,x2); x++)
            for (int y = Math.min(y1,y2); y <= Math.max(y1,y2); y++)
                for (int z = Math.min(z1,z2); z <= Math.max(z1,z2); z++)
                    if (x==Math.min(x1,x2)||x==Math.max(x1,x2)
                     || y==Math.min(y1,y2)||y==Math.max(y1,y2)
                     || z==Math.min(z1,z2)||z==Math.max(z1,z2))
                        l.setBlockAndUpdate(new BlockPos(x, y, z), w);
    }

    // Piso sólido dentro de um retângulo (sem o teto, apenas o chão)
    private static void floor(ServerLevel l, int x1, int y, int z1, int x2, int z2, BlockState b) {
        fill(l, x1, y, z1, x2, y, z2, b);
    }

    // ============================================================
    //  TORRES GÓTICAS — reutilizável
    //  cx,cz = centro; oy = base; r = raio; h = altura corpo; spire = altura agulha
    // ============================================================
    private static void gothicTower(ServerLevel l, int cx, int oy, int cz, int r, int h, int spire) {
        BlockState brick   = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState cracked = Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
        BlockState dark    = Blocks.DARK_OAK_LOG.defaultBlockState();
        BlockState slate   = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        BlockState mossed  = Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
        BlockState cwall   = Blocks.COBBLESTONE_WALL.defaultBlockState();

        // === Corpo da torre ===
        for (int dy = 0; dy <= h; dy++) {
            BlockState mat;
            if      (dy % 8 == 0) mat = dark;
            else if (dy % 5 == 0) mat = cracked;
            else if (dy % 3 == 0) mat = mossed;
            else                  mat = brick;

            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    boolean isWall = (Math.abs(dx)==r || Math.abs(dz)==r);
                    if (isWall) {
                        l.setBlockAndUpdate(new BlockPos(cx+dx, oy+dy, cz+dz), mat);
                    } else if (dy == 0) {
                        l.setBlockAndUpdate(new BlockPos(cx+dx, oy+dy, cz+dz), brick);
                    }
                }
            }

            // Janelas a cada 5 blocos de altura
            if (dy > 2 && dy % 5 == 2 && r >= 2) {
                // Janela N e S
                l.setBlockAndUpdate(new BlockPos(cx,   oy+dy, cz-r), Blocks.GLASS.defaultBlockState());
                l.setBlockAndUpdate(new BlockPos(cx,   oy+dy, cz+r), Blocks.GLASS.defaultBlockState());
                // Janela L e O
                l.setBlockAndUpdate(new BlockPos(cx-r, oy+dy, cz),   Blocks.GLASS.defaultBlockState());
                l.setBlockAndUpdate(new BlockPos(cx+r, oy+dy, cz),   Blocks.GLASS.defaultBlockState());
            }
        }

        // === Ameias no topo ===
        for (int dx = -r; dx <= r; dx++) {
            if (Math.abs(dx) % 2 == 0) {
                l.setBlockAndUpdate(new BlockPos(cx+dx, oy+h+1, cz-r), cwall);
                l.setBlockAndUpdate(new BlockPos(cx+dx, oy+h+1, cz+r), cwall);
            }
        }
        for (int dz = -r+1; dz <= r-1; dz++) {
            if (Math.abs(dz) % 2 == 0) {
                l.setBlockAndUpdate(new BlockPos(cx-r, oy+h+1, cz+dz), cwall);
                l.setBlockAndUpdate(new BlockPos(cx+r, oy+h+1, cz+dz), cwall);
            }
        }

        // === Spire (agulha gótica pontiaguda) ===
        for (int dy = 1; dy <= spire; dy++) {
            // Raio diminui linearmente
            double frac = (double) dy / spire;
            int sr = Math.max(0, (int) Math.round(r * (1.0 - frac)));
            for (int dx = -sr; dx <= sr; dx++) {
                for (int dz = -sr; dz <= sr; dz++) {
                    boolean edge = (Math.abs(dx)==sr || Math.abs(dz)==sr);
                    if (edge || dy == spire) {
                        l.setBlockAndUpdate(new BlockPos(cx+dx, oy+h+1+dy, cz+dz), slate);
                    }
                }
            }
        }

        // Lanterna no pico
        l.setBlockAndUpdate(new BlockPos(cx, oy+h+spire+2, cz), Blocks.LANTERN.defaultBlockState());
    }

    // ============================================================
    //  PAREDES COM JANELAS EM ARCO — decoração gótica nas paredes longas
    // ============================================================
    private static void gothicWindows(ServerLevel l, int x, int y1, int z1, int z2, BlockState frame) {
        // Janelas a cada 4 blocos ao longo de Z, com 3 blocos de altura (arco)
        for (int z = z1+2; z <= z2-2; z += 4) {
            l.setBlockAndUpdate(new BlockPos(x, y1,   z), frame);
            l.setBlockAndUpdate(new BlockPos(x, y1+1, z), Blocks.GLASS.defaultBlockState());
            l.setBlockAndUpdate(new BlockPos(x, y1+2, z), Blocks.GLASS.defaultBlockState());
            l.setBlockAndUpdate(new BlockPos(x, y1+3, z), frame);
        }
    }

    // ============================================================
    //  ESTÁGIO 1 — Terraplanagem + fundação (nível 5)
    //  Área limpa: 70x70, piso de pedra
    // ============================================================
    private static void clearTerrain(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        // Limpa 70 blocos ao redor + até 80 de altura
        for (int x = ox-35; x <= ox+35; x++) {
            for (int z = oz-35; z <= oz+35; z++) {
                // Remove tudo do chão pra cima
                for (int y = oy; y <= oy+80; y++)
                    lvl.setBlockAndUpdate(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState());
                // Nivelar o chão
                for (int y = oy-6; y < oy; y++)
                    lvl.setBlockAndUpdate(new BlockPos(x, y, z), Blocks.STONE.defaultBlockState());
                lvl.setBlockAndUpdate(new BlockPos(x, oy-1, z), Blocks.GRASS_BLOCK.defaultBlockState());
            }
        }
    }

    private static void buildStage1(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        BlockState cobble = Blocks.COBBLESTONE.defaultBlockState();
        BlockState granite = Blocks.POLISHED_GRANITE.defaultBlockState();
        BlockState diorite = Blocks.POLISHED_DIORITE.defaultBlockState();

        // Piso principal do castelo (30x40)
        floor(lvl, ox-15, oy-1, oz-20, ox+15, oz+20, cobble);

        // Padrão de piso: listras de granito e diorito alternadas
        for (int x = ox-14; x <= ox+14; x++) {
            BlockState mat = (Math.abs(x - ox) % 4 == 0) ? granite : diorite;
            for (int z = oz-19; z <= oz+19; z++)
                lvl.setBlockAndUpdate(new BlockPos(x, oy-1, z), mat);
        }

        // Contorno de fundação elevado (1 bloco)
        for (int x = ox-15; x <= ox+15; x++) {
            p(lvl, x, oy, oz-20, cobble);
            p(lvl, x, oy, oz+20, cobble);
        }
        for (int z = oz-20; z <= oz+20; z++) {
            p(lvl, ox-15, oy, z, cobble);
            p(lvl, ox+15, oy, z, cobble);
        }
    }

    // ============================================================
    //  ESTÁGIO 2 — Muralha externa (nível 10)
    //  48x48, altura 8, com ameias e portão sul
    // ============================================================
    private static void buildStage2(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState cwall = Blocks.COBBLESTONE_WALL.defaultBlockState();
        BlockState slate = Blocks.DEEPSLATE_BRICKS.defaultBlockState();

        // Muralha 48x48, altura 8
        for (int h = 0; h <= 8; h++) {
            BlockState mat = (h == 4) ? slate : brick;
            for (int x = ox-24; x <= ox+24; x++) {
                p(lvl, x, oy+h, oz-24, mat);
                p(lvl, x, oy+h, oz+24, mat);
            }
            for (int z = oz-23; z <= oz+23; z++) {
                p(lvl, ox-24, oy+h, z, mat);
                p(lvl, ox+24, oy+h, z, mat);
            }
        }

        // Ameias no topo
        for (int x = ox-24; x <= ox+24; x+=2) {
            p(lvl, x, oy+9, oz-24, cwall);
            p(lvl, x, oy+9, oz+24, cwall);
        }
        for (int z = oz-24; z <= oz+24; z+=2) {
            p(lvl, ox-24, oy+9, z, cwall);
            p(lvl, ox+24, oy+9, z, cwall);
        }

        // Portão sul (abertura 5x6)
        for (int h = 1; h <= 6; h++)
            for (int px = ox-2; px <= ox+2; px++)
                p(lvl, px, oy+h, oz+24, Blocks.AIR.defaultBlockState());

        // Arco do portão em pedra lapidada
        for (int px = ox-2; px <= ox+2; px++) {
            p(lvl, px, oy+7, oz+24, slate);
        }

        // Piso entre muralha e castelo (pátio externo)
        floor(lvl, ox-23, oy-1, oz-23, ox+23, oz+23, Blocks.COBBLESTONE.defaultBlockState());

        // Fosso ao redor da muralha (água)
        for (int x = ox-27; x <= ox+27; x++) {
            for (int z = oz-27; z <= oz+27; z++) {
                boolean inFosse = (Math.abs(x-ox) >= 25 || Math.abs(z-oz) >= 25)
                               && (Math.abs(x-ox) <= 27 && Math.abs(z-oz) <= 27);
                if (inFosse) {
                    for (int y = oy-3; y <= oy-1; y++)
                        lvl.setBlockAndUpdate(new BlockPos(x, y, z), Blocks.WATER.defaultBlockState());
                    p(lvl, x, oy, z, Blocks.AIR.defaultBlockState());
                }
            }
        }

        // Ponte sul sobre o fosso
        for (int z = oz+24; z <= oz+30; z++) {
            for (int px = ox-3; px <= ox+3; px++) {
                p(lvl, px, oy-1, z, Blocks.OAK_PLANKS.defaultBlockState());
                // Grade lateral da ponte
                if (px == ox-3 || px == ox+3)
                    p(lvl, px, oy, z, Blocks.OAK_FENCE.defaultBlockState());
            }
        }
    }

    // ============================================================
    //  ESTÁGIO 3 — Torres dos 4 cantos da muralha (nível 15)
    //  Raio 3, altura 14, spire 8
    // ============================================================
    private static void buildStage3(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        gothicTower(lvl, ox-24, oy, oz-24, 3, 14, 8);
        gothicTower(lvl, ox+24, oy, oz-24, 3, 14, 8);
        gothicTower(lvl, ox-24, oy, oz+24, 3, 14, 8);
        gothicTower(lvl, ox+24, oy, oz+24, 3, 14, 8);
    }

    // ============================================================
    //  ESTÁGIO 4 — NAVE CENTRAL (corpo principal do castelo) (nível 20)
    //  28x36, 4 andares visíveis, paredes de pedra lapidada
    //  ISSO É O CORAÇÃO DO CASTELO — identico à catedral da imagem
    // ============================================================
    private static void buildStage4(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        BlockState brick   = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState cracked = Blocks.CRACKED_STONE_BRICKS.defaultBlockState();
        BlockState mossed  = Blocks.MOSSY_STONE_BRICKS.defaultBlockState();
        BlockState dark    = Blocks.DARK_OAK_LOG.defaultBlockState();
        BlockState darkP   = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        BlockState slate   = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        BlockState air     = Blocks.AIR.defaultBlockState();

        // === CORPO TOTAL: 28x36 (ox-14 a ox+14, oz-18 a oz+18) ===
        // Paredes externas com 2 de espessura para robustez visual
        // Altura total do corpo: 48 blocos (4 andares de 12 cada)

        int x1 = ox-14, x2 = ox+14;
        int z1 = oz-18, z2 = oz+18;
        int totalH = 48;

        // Paredes norte e sul (eixo Z)
        for (int h = 0; h <= totalH; h++) {
            BlockState mat;
            // Faixas horizontais de materiais diferentes = "andares visíveis externamente"
            if      (h == 12 || h == 24 || h == 36) mat = dark;    // vigas divisórias
            else if (h % 7 == 0)                    mat = cracked;
            else if (h % 4 == 0)                    mat = mossed;
            else                                     mat = brick;

            for (int x = x1; x <= x2; x++) {
                p(lvl, x, oy+h, z1, mat);
                p(lvl, x, oy+h, z2, mat);
                // Dobra da parede (1 bloco atrás)
                p(lvl, x, oy+h, z1+1, mat);
                p(lvl, x, oy+h, z2-1, mat);
            }
        }

        // Paredes leste e oeste (eixo X)
        for (int h = 0; h <= totalH; h++) {
            BlockState mat;
            if      (h == 12 || h == 24 || h == 36) mat = dark;
            else if (h % 7 == 0)                    mat = cracked;
            else if (h % 4 == 0)                    mat = mossed;
            else                                     mat = brick;

            for (int z = z1+1; z <= z2-1; z++) {
                p(lvl, x1,   oy+h, z, mat);
                p(lvl, x1+1, oy+h, z, mat);
                p(lvl, x2,   oy+h, z, mat);
                p(lvl, x2-1, oy+h, z, mat);
            }
        }

        // === TETO INCLINADO em V (como a catedral da imagem) ===
        // Dois lados inclinados que se encontram no meio
        int roofBase = oy + totalH + 1;
        int roofWidth = x2 - x1; // 28
        for (int step = 0; step <= roofWidth/2; step++) {
            int rx1 = x1 + step;
            int rx2 = x2 - step;
            int roofY = roofBase + step;
            BlockState roofMat = (step % 3 == 0) ? dark : slate;
            for (int z = z1; z <= z2; z++) {
                p(lvl, rx1, roofY, z, roofMat);
                p(lvl, rx2, roofY, z, roofMat);
            }
        }
        // Topo do telhado (cumeeira)
        for (int z = z1; z <= z2; z++)
            p(lvl, ox, oy+totalH+1+roofWidth/2, z, dark);

        // === ENTRADA PRINCIPAL SUL — arco triplo ===
        for (int h = 1; h <= 8; h++) {
            for (int px = ox-3; px <= ox+3; px++)
                p(lvl, px, oy+h, z2, air);
        }
        // Arco em volta da porta (deepslate lapidado)
        for (int px = ox-3; px <= ox+3; px++)
            p(lvl, px, oy+9, z2, slate);
        for (int h = 1; h <= 8; h++) {
            p(lvl, ox-4, oy+h, z2, slate);
            p(lvl, ox+4, oy+h, z2, slate);
        }
        // --- PORTA DUPLA DE CARVALHO (entrada sul) ---
        // Porta esquerda (hinge LEFT, facing NORTH = player sai pelo sul)
        p(lvl, ox-1, oy+1, z2,
            Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, Direction.NORTH)
                .setValue(DoorBlock.HALF,   DoubleBlockHalf.LOWER)
                .setValue(DoorBlock.HINGE,  DoorHingeSide.LEFT)
                .setValue(DoorBlock.OPEN,   false));
        p(lvl, ox-1, oy+2, z2,
            Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, Direction.NORTH)
                .setValue(DoorBlock.HALF,   DoubleBlockHalf.UPPER)
                .setValue(DoorBlock.HINGE,  DoorHingeSide.LEFT)
                .setValue(DoorBlock.OPEN,   false));
        // Porta direita (hinge RIGHT)
        p(lvl, ox+1, oy+1, z2,
            Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, Direction.NORTH)
                .setValue(DoorBlock.HALF,   DoubleBlockHalf.LOWER)
                .setValue(DoorBlock.HINGE,  DoorHingeSide.RIGHT)
                .setValue(DoorBlock.OPEN,   false));
        p(lvl, ox+1, oy+2, z2,
            Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, Direction.NORTH)
                .setValue(DoorBlock.HALF,   DoubleBlockHalf.UPPER)
                .setValue(DoorBlock.HINGE,  DoorHingeSide.RIGHT)
                .setValue(DoorBlock.OPEN,   false));

        // === ENTRADA NORTE (acesso às alas) ===
        for (int h = 1; h <= 6; h++)
            for (int px = ox-2; px <= ox+2; px++)
                p(lvl, px, oy+h, z1, air);

        // === PISOS INTERNOS (lajes de madeira escura) ===
        // Andar 1 (nível oy+12)
        floor(lvl, x1+2, oy+12, z1+2, x2-2, z2-2, darkP);
        // Andar 2 (nível oy+24)
        floor(lvl, x1+2, oy+24, z1+2, x2-2, z2-2, darkP);
        // Andar 3 (nível oy+36)
        floor(lvl, x1+2, oy+36, z1+2, x2-2, z2-2, darkP);
        // Piso térreo (oy)
        floor(lvl, x1+2, oy, z1+2, x2-2, z2-2, Blocks.POLISHED_ANDESITE.defaultBlockState());

        // === JANELAS GÓTICAS NAS PAREDES LESTE E OESTE ===
        // A cada 4 blocos de Z, janelas duplas por andar
        for (int andar = 0; andar < 4; andar++) {
            int baseY = oy + andar * 12 + 2;
            for (int z = z1+4; z <= z2-4; z += 5) {
                // Janela leste
                p(lvl, x1,   baseY,   z, Blocks.GLASS.defaultBlockState());
                p(lvl, x1,   baseY+1, z, Blocks.GLASS.defaultBlockState());
                p(lvl, x1,   baseY+2, z, Blocks.GLASS.defaultBlockState());
                p(lvl, x1+1, baseY,   z, Blocks.GLASS.defaultBlockState());
                p(lvl, x1+1, baseY+1, z, Blocks.GLASS.defaultBlockState());
                // Janela oeste
                p(lvl, x2,   baseY,   z, Blocks.GLASS.defaultBlockState());
                p(lvl, x2,   baseY+1, z, Blocks.GLASS.defaultBlockState());
                p(lvl, x2,   baseY+2, z, Blocks.GLASS.defaultBlockState());
                p(lvl, x2-1, baseY,   z, Blocks.GLASS.defaultBlockState());
                p(lvl, x2-1, baseY+1, z, Blocks.GLASS.defaultBlockState());
            }
        }

        // === JANELAS NA PAREDE SUL (grandes, coloridas) ===
        // Vitral central
        for (int px = ox-5; px <= ox+5; px++) {
            p(lvl, px, oy+16, z2, Blocks.YELLOW_STAINED_GLASS.defaultBlockState());
            p(lvl, px, oy+17, z2, Blocks.YELLOW_STAINED_GLASS.defaultBlockState());
        }
        for (int px = ox-3; px <= ox+3; px++) {
            p(lvl, px, oy+28, z2, Blocks.PURPLE_STAINED_GLASS.defaultBlockState());
            p(lvl, px, oy+29, z2, Blocks.PURPLE_STAINED_GLASS.defaultBlockState());
            p(lvl, px, oy+30, z2, Blocks.PURPLE_STAINED_GLASS.defaultBlockState());
        }

        // === ESCADARIA INTERNA — 4 lances com degraus orientados ===
        // Degraus com direção correta para subir suavemente
        BlockState stairN = Blocks.OAK_STAIRS.defaultBlockState()
                .setValue(StairBlock.FACING, Direction.NORTH)
                .setValue(StairBlock.HALF, Half.BOTTOM)
                .setValue(StairBlock.SHAPE, StairsShape.STRAIGHT);
        BlockState stairS = Blocks.OAK_STAIRS.defaultBlockState()
                .setValue(StairBlock.FACING, Direction.SOUTH)
                .setValue(StairBlock.HALF, Half.BOTTOM)
                .setValue(StairBlock.SHAPE, StairsShape.STRAIGHT);
        BlockState stairE = Blocks.OAK_STAIRS.defaultBlockState()
                .setValue(StairBlock.FACING, Direction.EAST)
                .setValue(StairBlock.HALF, Half.BOTTOM)
                .setValue(StairBlock.SHAPE, StairsShape.STRAIGHT);
        BlockState stairW = Blocks.OAK_STAIRS.defaultBlockState()
                .setValue(StairBlock.FACING, Direction.WEST)
                .setValue(StairBlock.HALF, Half.BOTTOM)
                .setValue(StairBlock.SHAPE, StairsShape.STRAIGHT);
        // Lance 1 (Térreo → 1º andar): ao longo do eixo Z, lado leste
        for (int h = 0; h < 12; h++)
            p(lvl, x2-3, oy+h, z2-4+(h % 12), stairN);
        // Lance 2 (1º → 2º andar): ao longo do eixo X, lado norte
        for (int h = 12; h < 24; h++)
            p(lvl, x2-3-(h-12), oy+h, z1+4, stairW);
        // Lance 3 (2º → 3º andar): ao longo do eixo Z, lado oeste
        for (int h = 24; h < 36; h++)
            p(lvl, x1+3, oy+h, z1+4+(h-24), stairS);
        // Lance 4 (3º → 4º andar): ao longo do eixo X, lado sul
        for (int h = 36; h < 48; h++)
            p(lvl, x1+3+(h-36), oy+h, z2-4, stairE);
        // Plataformas de descanso entre lances (facilita a navegação)
        for (int px = x2-5; px <= x2-3; px++) p(lvl, px, oy+12, z2-4, darkP); // 1º andar
        for (int pz = z1+4; pz <= z1+6; pz++) p(lvl, x2-3, oy+24, pz, darkP); // 2º andar
        for (int px = x1+3; px <= x1+5; px++) p(lvl, px, oy+36, z1+4, darkP); // 3º andar
    }

    // ============================================================
    //  ESTÁGIO 5 — 1º ANDAR: Grande Salão (nível 25)
    //  Decoração do térreo + 1º andar
    // ============================================================
    private static void buildStage5(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // === TÉRREO — Grande Salão de entrada ===
        // Tapete vermelho central
        for (int z = oz-16; z <= oz+14; z++)
            fill(lvl, ox-2, oy+1, z, ox+2, oy+1, z, Blocks.RED_CARPET.defaultBlockState());

        // Mesas laterais (pares de bancadas + tochas)
        for (int z = oz-12; z <= oz+10; z += 4) {
            p(lvl, ox-10, oy+1, z, Blocks.CRAFTING_TABLE.defaultBlockState());
            p(lvl, ox+10, oy+1, z, Blocks.CRAFTING_TABLE.defaultBlockState());
            p(lvl, ox-10, oy+2, z, Blocks.TORCH.defaultBlockState());
            p(lvl, ox+10, oy+2, z, Blocks.TORCH.defaultBlockState());
        }

        // Colunas internas — 2 pares flanqueando o salão
        for (int cz : new int[]{oz-10, oz-4, oz+4, oz+10}) {
            pillar(lvl, ox-8, oy, cz, 11, Blocks.STONE_BRICK_SLAB.defaultBlockState());
            pillar(lvl, ox+8, oy, cz, 11, Blocks.STONE_BRICK_SLAB.defaultBlockState());
        }

        // Baús de missão e interação
        p(lvl, ox-12, oy+1, oz-16, Blocks.CHEST.defaultBlockState());  // Baú inicial de missão
        p(lvl, ox+12, oy+1, oz-16, Blocks.CHEST.defaultBlockState());  // Baú de recompensas

        // Lanternas suspensas do teto do 1º andar
        for (int lx = ox-10; lx <= ox+10; lx += 5)
            for (int lz = oz-14; lz <= oz+14; lz += 7)
                p(lvl, lx, oy+11, lz, Blocks.LANTERN.defaultBlockState());

        // === 1º ANDAR — Câmaras dos guardas ===
        int y1 = oy + 13;
        // Divisórias entre câmaras
        for (int z = oz-16; z <= oz+16; z++)
            p(lvl, ox, y1, z, Blocks.STONE_BRICKS.defaultBlockState());
        // Aberturas nas divisórias
        for (int h = 1; h <= 3; h++) {
            p(lvl, ox, y1+h, oz-8, Blocks.AIR.defaultBlockState());
            p(lvl, ox, y1+h, oz,   Blocks.AIR.defaultBlockState());
            p(lvl, ox, y1+h, oz+8, Blocks.AIR.defaultBlockState());
        }

        // Armários e camas dos guardas
        for (int gx : new int[]{ox-8, ox+8}) {
            p(lvl, gx, y1+1, oz-14, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, gx, y1+1, oz-10, Blocks.CHEST.defaultBlockState());
            p(lvl, gx, y1+1, oz-6, Blocks.OAK_PLANKS.defaultBlockState()); // "cama"
            p(lvl, gx, y1+2, oz-6, Blocks.RED_WOOL.defaultBlockState());   // cobertor
            p(lvl, gx, y1+1, oz+6, Blocks.OAK_PLANKS.defaultBlockState());
            p(lvl, gx, y1+2, oz+6, Blocks.BLUE_WOOL.defaultBlockState());
            p(lvl, gx, y1+1, oz+10, Blocks.CHEST.defaultBlockState());
            p(lvl, gx, y1+1, oz+14, Blocks.BOOKSHELF.defaultBlockState());
        }
    }

    // Coluna simples
    private static void pillar(ServerLevel l, int x, int oy, int z, int h, BlockState top) {
        for (int dy = 1; dy <= h-1; dy++)
            l.setBlockAndUpdate(new BlockPos(x, oy+dy, z), Blocks.STONE_BRICKS.defaultBlockState());
        l.setBlockAndUpdate(new BlockPos(x, oy+h, z), top);
    }

    // ============================================================
    //  ESTÁGIO 6 — 2º ANDAR: Câmara do Conselho (nível 30)
    // ============================================================
    private static void buildStage6(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        int y2 = oy + 25;

        // Mesa redonda de conselho
        for (int dx = -4; dx <= 4; dx++) {
            for (int dz = -4; dz <= 4; dz++) {
                double dist = Math.sqrt(dx*dx + dz*dz);
                if (dist >= 3.0 && dist <= 4.5) {
                    p(lvl, ox+dx, y2+1, oz+dz, Blocks.OAK_PLANKS.defaultBlockState());
                }
            }
        }

        // Trono do rei no centro sul
        p(lvl, ox,   y2+1, oz-14, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox,   y2+2, oz-14, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox,   y2+3, oz-14, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox-1, y2+1, oz-14, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox+1, y2+1, oz-14, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox-1, y2+2, oz-14, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox+1, y2+2, oz-14, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox,   y2+4, oz-14, Blocks.LANTERN.defaultBlockState());

        // Tapete dourado do trono
        for (int z = oz-13; z <= oz+5; z++)
            fill(lvl, ox-1, y2, z, ox+1, y2, z, Blocks.YELLOW_CARPET.defaultBlockState());

        // Cadeiras do conselho ao redor da mesa
        for (int ang = 0; ang < 8; ang++) {
            double rad = Math.toRadians(ang * 45);
            int cx = (int)(ox + 5.5 * Math.cos(rad));
            int cz = (int)(oz + 5.5 * Math.sin(rad));
            p(lvl, cx, y2+1, cz, Blocks.OAK_STAIRS.defaultBlockState());
        }

        // Beacon e pirâmide de ouro (símbolo do poder de Valdoria)
        p(lvl, ox, y2+1, oz+8, Blocks.BEACON.defaultBlockState());
        for (int px = ox-2; px <= ox+2; px++)
            for (int pz = oz+6; pz <= oz+10; pz++)
                p(lvl, px, y2, pz, Blocks.GOLD_BLOCK.defaultBlockState());

        // Estantes e livros
        for (int bx = ox-12; bx <= ox+12; bx += 2) {
            p(lvl, bx, y2+1, oz-16, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, bx, y2+2, oz-16, Blocks.BOOKSHELF.defaultBlockState());
        }

        // Janelas de vitral no 2º andar sul
        for (int px = ox-12; px <= ox+12; px += 3) {
            p(lvl, px, y2+5, oz+18, Blocks.CYAN_STAINED_GLASS.defaultBlockState());
            p(lvl, px, y2+6, oz+18, Blocks.CYAN_STAINED_GLASS.defaultBlockState());
        }

        // Lanternas do 2º andar
        for (int lx = ox-10; lx <= ox+10; lx += 5)
            for (int lz = oz-14; lz <= oz+14; lz += 7)
                p(lvl, lx, y2+10, lz, Blocks.LANTERN.defaultBlockState());
    }

    // ============================================================
    //  ESTÁGIO 7 — 2 TORRES FRONTAIS IMPONENTES (nível 35)
    //  Flanqueiam a entrada sul — idênticas à imagem
    //  Raio 4, altura 38, spire 18 — AS MAIS ALTAS DA FACHADA
    // ============================================================
    private static void buildStage7(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // Torres frontais simétricas flanqueando o portão sul
        // Posição: flancos da nave central (x-16/x+16, fachada sul)
        gothicTower(lvl, ox-16, oy, oz+18, 4, 38, 18);
        gothicTower(lvl, ox+16, oy, oz+18, 4, 38, 18);

        // Passarela conectando as torres frontais com a nave no nível 12
        for (int px = ox-12; px <= ox-6; px++) {
            p(lvl, px, oy+12, oz+18, Blocks.OAK_PLANKS.defaultBlockState());
            p(lvl, px, oy+13, oz+18, Blocks.OAK_FENCE.defaultBlockState());
        }
        for (int px = ox+6; px <= ox+12; px++) {
            p(lvl, px, oy+12, oz+18, Blocks.OAK_PLANKS.defaultBlockState());
            p(lvl, px, oy+13, oz+18, Blocks.OAK_FENCE.defaultBlockState());
        }

        // Arco de entrada entre as torres (granito polido decorativo)
        for (int px = ox-5; px <= ox+5; px++)
            p(lvl, px, oy+10, oz+18, Blocks.POLISHED_GRANITE.defaultBlockState());
        for (int h = 8; h <= 10; h++) {
            p(lvl, ox-5, oy+h, oz+18, Blocks.POLISHED_GRANITE.defaultBlockState());
            p(lvl, ox+5, oy+h, oz+18, Blocks.POLISHED_GRANITE.defaultBlockState());
        }
    }

    // ============================================================
    //  ESTÁGIO 8 — 2 TORRES TRASEIRAS ALTAS (nível 40)
    //  Ficam ao norte, ligeiramente mais altas — como na imagem
    //  Raio 3, altura 42, spire 20
    // ============================================================
    private static void buildStage8(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // Torres traseiras (norte) — um pouco mais altas que as frontais
        gothicTower(lvl, ox-13, oy, oz-18, 3, 42, 20);
        gothicTower(lvl, ox+13, oy, oz-18, 3, 42, 20);

        // Conexão com a nave central no andar 2
        for (int z = oz-17; z <= oz-13; z++) {
            p(lvl, ox-13, oy+24, z, Blocks.OAK_PLANKS.defaultBlockState());
            p(lvl, ox+13, oy+24, z, Blocks.OAK_PLANKS.defaultBlockState());
        }
        for (int z = oz-17; z <= oz-13; z++) {
            p(lvl, ox-13, oy+25, z, Blocks.OAK_FENCE.defaultBlockState());
            p(lvl, ox+13, oy+25, z, Blocks.OAK_FENCE.defaultBlockState());
        }
    }

    // ============================================================
    //  ESTÁGIO 9 — 3º ANDAR: Biblioteca e arquivo (nível 45)
    // ============================================================
    private static void buildStage9(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        int y3 = oy + 37;

        // Paredes de estante em todos os lados internos
        for (int bx = ox-12; bx <= ox+12; bx++) {
            p(lvl, bx, y3+1, oz-16, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, bx, y3+2, oz-16, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, bx, y3+3, oz-16, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, bx, y3+1, oz+16, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, bx, y3+2, oz+16, Blocks.BOOKSHELF.defaultBlockState());
        }
        for (int bz = oz-15; bz <= oz+15; bz++) {
            p(lvl, ox-12, y3+1, bz, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, ox-12, y3+2, bz, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, ox+12, y3+1, bz, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, ox+12, y3+2, bz, Blocks.BOOKSHELF.defaultBlockState());
        }

        // Mesa de encantamento central + pirâmide de poder
        p(lvl, ox, y3+1, oz, Blocks.ENCHANTING_TABLE.defaultBlockState());
        for (int dx = -3; dx <= 3; dx += 3)
            for (int dz = -3; dz <= 3; dz += 3)
                p(lvl, ox+dx, y3+1, oz+dz, Blocks.BOOKSHELF.defaultBlockState());

        // Mesas de estudo espalhadas
        for (int i = 0; i < 4; i++) {
            int mx = ox + (i < 2 ? -7 : 7);
            int mz = oz + (i % 2 == 0 ? -8 : 8);
            p(lvl, mx, y3+1, mz, Blocks.OAK_PLANKS.defaultBlockState());
            p(lvl, mx, y3+2, mz, Blocks.TORCH.defaultBlockState());
            p(lvl, mx+1, y3+1, mz, Blocks.LECTERN.defaultBlockState());
        }

        // Baú com missão especial da biblioteca
        p(lvl, ox, y3+1, oz-15, Blocks.CHEST.defaultBlockState());
        p(lvl, ox, y3+1, oz+15, Blocks.CHEST.defaultBlockState());

        // Lanternas
        for (int lx = ox-8; lx <= ox+8; lx += 4)
            for (int lz = oz-12; lz <= oz+12; lz += 6)
                p(lvl, lx, y3+9, lz, Blocks.LANTERN.defaultBlockState());
    }

    // ============================================================
    //  ESTÁGIO 10 — 4º ANDAR: Sala do Trono Final (nível 50)
    //  O lugar onde EnzoGlacial / Malachar aguarda
    // ============================================================
    private static void buildStage10(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        int y4 = oy + 49; // Acima do 4º piso (oy+36 + 13)

        // Paredes da sala do trono em deepslate lapidado (mais sombrio)
        BlockState slate = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        BlockState darkP = Blocks.DARK_OAK_PLANKS.defaultBlockState();

        fillHollow(lvl, ox-12, y4, oz-16, ox+12, y4+14, oz+16, slate);
        // Piso da sala do trono
        floor(lvl, ox-11, y4, oz-15, ox+11, oz+15, Blocks.POLISHED_DEEPSLATE.defaultBlockState());

        // Vitral no teto (telhado colorido)
        for (int px = ox-6; px <= ox+6; px++)
            for (int pz = oz-6; pz <= oz+6; pz++) {
                BlockState glass;
                int dist = Math.abs(px-ox) + Math.abs(pz-oz);
                if      (dist <= 2)  glass = Blocks.YELLOW_STAINED_GLASS.defaultBlockState();
                else if (dist <= 5)  glass = Blocks.PURPLE_STAINED_GLASS.defaultBlockState();
                else                 glass = Blocks.BLUE_STAINED_GLASS.defaultBlockState();
                p(lvl, px, y4+14, pz, glass);
            }

        // === TRONO SUPREMO DE VALDORIA ===
        // Plataforma elevada
        fill(lvl, ox-3, y4, oz-13, ox+3, y4, oz-9, Blocks.GOLD_BLOCK.defaultBlockState());
        fill(lvl, ox-2, y4+1, oz-13, ox+2, y4+1, oz-9, slate);
        // Trono em si
        fill(lvl, ox-1, y4+2, oz-13, ox+1, y4+2, oz-13, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox, y4+3, oz-13, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox, y4+4, oz-13, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox-1, y4+3, oz-13, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, ox+1, y4+3, oz-13, Blocks.GOLD_BLOCK.defaultBlockState());
        // Beacon acima do trono (aura de poder)
        p(lvl, ox, y4+5, oz-13, Blocks.BEACON.defaultBlockState());
        p(lvl, ox, y4+6, oz-13, Blocks.LANTERN.defaultBlockState());

        // Tapete roxo do trono
        for (int z = oz-12; z <= oz+10; z++)
            fill(lvl, ox-2, y4, z, ox+2, y4, z, Blocks.PURPLE_CARPET.defaultBlockState());

        // Colunas do salão do trono
        for (int cz : new int[]{oz-8, oz, oz+8}) {
            pillar(lvl, ox-9, y4, cz, 10, Blocks.DEEPSLATE_BRICK_SLAB.defaultBlockState());
            pillar(lvl, ox+9, y4, cz, 10, Blocks.DEEPSLATE_BRICK_SLAB.defaultBlockState());
        }

        // Lanternas roxas (velas mágicas)
        for (int i = 0; i < 6; i++) {
            int lx = ox - 10 + (i * 4);
            p(lvl, lx, y4+12, oz-14, Blocks.LANTERN.defaultBlockState());
            p(lvl, lx, y4+12, oz+14, Blocks.LANTERN.defaultBlockState());
        }

        // Baú com recompensa final
        p(lvl, ox-5, y4+1, oz-15, Blocks.CHEST.defaultBlockState());
        p(lvl, ox+5, y4+1, oz-15, Blocks.CHEST.defaultBlockState());

        // Entrada sul da sala do trono
        for (int h = 1; h <= 6; h++)
            for (int px = ox-2; px <= ox+2; px++)
                p(lvl, px, y4+h, oz+16, Blocks.AIR.defaultBlockState());
    }

    // ============================================================
    //  ESTÁGIO 11 — TORRE CENTRAL SUPREMA (nível 55)
    //  Sobe do meio da nave — a mais alta de todas
    //  Raio 3, altura 50, spire 25 — domina o skyline
    // ============================================================
    private static void buildStage11(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // Torre central acima do telhado da nave
        gothicTower(lvl, ox, oy+50, oz, 3, 50, 25);

        // Reforço base da torre com deepslate
        BlockState slate = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        for (int h = 50; h <= 56; h++)
            for (int dx = -3; dx <= 3; dx++)
                for (int dz = -3; dz <= 3; dz++)
                    if (Math.abs(dx)==3 || Math.abs(dz)==3)
                        p(lvl, ox+dx, oy+h, oz+dz, slate);
    }

    // ============================================================
    //  ESTÁGIO 12 — ALA NORTE: Portal de Nivéria (nível 60)
    //  Sala anexa ao norte para o portal da dimensão de gelo
    // ============================================================
    private static void buildStage12(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        BlockState ice   = Blocks.PACKED_ICE.defaultBlockState();
        BlockState bice  = Blocks.BLUE_ICE.defaultBlockState();
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState snow  = Blocks.SNOW_BLOCK.defaultBlockState();

        // === Sala de Nivéria (ala norte) — 16x12 ===
        int rx1 = ox-8, rx2 = ox+8;
        int rz1 = oz-34, rz2 = oz-22;

        // Paredes em gelo e pedra misturada
        for (int h = 0; h <= 10; h++) {
            BlockState mat = (h % 3 == 0) ? ice : brick;
            for (int x = rx1; x <= rx2; x++) {
                p(lvl, x, oy+h, rz1, mat);
                p(lvl, x, oy+h, rz2, mat);
            }
            for (int z = rz1+1; z <= rz2-1; z++) {
                p(lvl, rx1, oy+h, z, mat);
                p(lvl, rx2, oy+h, z, mat);
            }
        }

        // Piso de gelo azul
        floor(lvl, rx1+1, oy, rz1+1, rx2-1, rz2-1, bice);

        // Neve ao redor
        for (int x = rx1-2; x <= rx2+2; x++)
            for (int z = rz1-2; z <= rz2-2; z++)
                p(lvl, x, oy, z, snow);

        // === PORTAL DE NIVÉRIA ===
        // Frame de gelo compactado (5x4)
        for (int h = 0; h <= 5; h++) {
            p(lvl, ox-3, oy+h, oz-28, ice);
            p(lvl, ox+3, oy+h, oz-28, ice);
        }
        for (int px = ox-3; px <= ox+3; px++) {
            p(lvl, px, oy+6, oz-28, ice);
            p(lvl, px, oy,   oz-28, ice);
        }

        // Interior do portal (bloco personalizado ou fallback em gelo azul)
        try {
            for (int px = ox-2; px <= ox+2; px++)
                for (int py = oy+1; py <= oy+5; py++)
                    p(lvl, px, py, oz-28, ModBlocks.PORTAL_NIVERIA.get().defaultBlockState());
        } catch (Exception e) {
            for (int px = ox-2; px <= ox+2; px++)
                for (int py = oy+1; py <= oy+5; py++)
                    p(lvl, px, py, oz-28, bice);
        }

        // Beacon acima do portal
        p(lvl, ox, oy+9, oz-28, Blocks.BEACON.defaultBlockState());
        // Piso de ouro abaixo do beacon
        for (int px = ox-2; px <= ox+2; px++)
            for (int pz = oz-30; pz <= oz-26; pz++)
                p(lvl, px, oy-1, pz, Blocks.GOLD_BLOCK.defaultBlockState());

        // Conexão com a nave (abertura no muro norte)
        for (int h = 1; h <= 5; h++)
            for (int px = ox-2; px <= ox+2; px++)
                p(lvl, px, oy+h, oz-18, Blocks.AIR.defaultBlockState());

        // Decoração de gelo espalhada
        for (int dx : new int[]{-5, -3, 3, 5}) {
            p(lvl, ox+dx, oy+1, oz-25, Blocks.ICE.defaultBlockState());
            p(lvl, ox+dx, oy+2, oz-25, bice);
        }
    }

    // ============================================================
    //  ESTÁGIO 13 — ALA SUL: Pátio + Capelinha (nível 65)
    // ============================================================
    private static void buildStage13(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // === Pátio sul decorado ===
        floor(lvl, ox-20, oy-1, oz+19, ox+20, oz+30, Blocks.POLISHED_ANDESITE.defaultBlockState());

        // Padrão de piso em xadrez
        for (int x = ox-20; x <= ox+20; x++)
            for (int z = oz+19; z <= oz+30; z++)
                if ((x + z) % 2 == 0)
                    p(lvl, x, oy-1, z, Blocks.POLISHED_GRANITE.defaultBlockState());

        // Fonte central do pátio
        fill(lvl, ox-4, oy-1, oz+22, ox+4, oy+1, oz+28, Blocks.STONE_BRICKS.defaultBlockState());
        fill(lvl, ox-3, oy+1, oz+23, ox+3, oy+1, oz+27, Blocks.WATER.defaultBlockState());
        p(lvl, ox, oy+2, oz+25, Blocks.SEA_LANTERN.defaultBlockState());
        p(lvl, ox, oy+3, oz+25, Blocks.LANTERN.defaultBlockState());

        // Árvores decorativas
        for (int[] t : new int[][]{{ox-15,oz+22},{ox+15,oz+22},{ox-15,oz+28},{ox+15,oz+28}}) {
            p(lvl, t[0], oy+1, t[1], Blocks.OAK_LOG.defaultBlockState());
            p(lvl, t[0], oy+2, t[1], Blocks.OAK_LOG.defaultBlockState());
            p(lvl, t[0], oy+3, t[1], Blocks.OAK_LEAVES.defaultBlockState());
            for (int dx2 = -1; dx2 <= 1; dx2++)
                for (int dz2 = -1; dz2 <= 1; dz2++)
                    p(lvl, t[0]+dx2, oy+4, t[1]+dz2, Blocks.OAK_LEAVES.defaultBlockState());
        }

        // Lanternas do pátio
        for (int px : new int[]{ox-18,ox-12,ox-6,ox,ox+6,ox+12,ox+18})
            p(lvl, px, oy+1, oz+20, Blocks.LANTERN.defaultBlockState());

        // === Capelinha leste ===
        buildChapel(lvl, ox+22, oy, oz+5);

        // === Jardim norte entre torres traseiras ===
        for (int x = ox-10; x <= ox+10; x++)
            for (int z = oz-21; z <= oz-18; z++)
                p(lvl, x, oy-1, z, Blocks.GRASS_BLOCK.defaultBlockState());
        for (int[] pos : new int[][]{{ox-7,oz-20},{ox,oz-20},{ox+7,oz-20}}) {
            p(lvl, pos[0], oy, pos[1], Blocks.OAK_LOG.defaultBlockState());
            p(lvl, pos[0], oy+1, pos[1], Blocks.OAK_LEAVES.defaultBlockState());
        }
    }

    private static void buildChapel(ServerLevel lvl, int cx, int oy, int cz) {
        BlockState brick   = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState darkP   = Blocks.DARK_OAK_PLANKS.defaultBlockState();

        // Corpo 10x12, altura 10
        fillHollow(lvl, cx-5, oy, cz-6, cx+5, oy+10, cz+6, brick);
        floor(lvl, cx-4, oy, cz-5, cx+4, cz+5, Blocks.POLISHED_ANDESITE.defaultBlockState());

        // Vitral no teto da capelinha
        for (int px = cx-3; px <= cx+3; px++)
            for (int pz = cz-3; pz <= cz+3; pz++) {
                boolean edge = (Math.abs(px-cx)==3 || Math.abs(pz-cz)==3);
                BlockState g = edge ? Blocks.PURPLE_STAINED_GLASS.defaultBlockState()
                                    : Blocks.YELLOW_STAINED_GLASS.defaultBlockState();
                lvl.setBlockAndUpdate(new BlockPos(px, oy+10, pz), g);
            }

        // Altar
        p(lvl, cx, oy+1, cz-4, Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl, cx, oy+2, cz-4, Blocks.SEA_LANTERN.defaultBlockState());
        p(lvl, cx, oy+3, cz-4, Blocks.LANTERN.defaultBlockState());

        // Entrada
        for (int h = 1; h <= 5; h++) p(lvl, cx, oy+h, cz+6, Blocks.AIR.defaultBlockState());

        // Mini-torre da capelinha
        gothicTower(lvl, cx, oy+10, cz-4, 1, 6, 4);
    }

    // ============================================================
    //  ESTÁGIO 14 — Sala de treino + estábulo (nível 70)
    // ============================================================
    private static void buildStage14(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // === Sala de treino (ala oeste) ===
        int tx = ox - 22;
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        fillHollow(lvl, tx-6, oy, oz-8, tx+6, oy+7, oz+8, brick);
        floor(lvl, tx-5, oy, oz-7, tx+5, oz+7, Blocks.OAK_PLANKS.defaultBlockState());

        // Alvos de treino
        p(lvl, tx,     oy+1, oz-6, Blocks.TARGET.defaultBlockState());
        p(lvl, tx-5,   oy+1, oz,   Blocks.TARGET.defaultBlockState());
        p(lvl, tx+5,   oy+1, oz,   Blocks.TARGET.defaultBlockState());
        p(lvl, tx,     oy+1, oz+6, Blocks.CHEST.defaultBlockState());

        // Mesa de crafting + ferreiro
        p(lvl, tx-4, oy+1, oz-6, Blocks.CRAFTING_TABLE.defaultBlockState());
        p(lvl, tx+4, oy+1, oz-6, Blocks.GRINDSTONE.defaultBlockState());
        p(lvl, tx-4, oy+1, oz+6, Blocks.ANVIL.defaultBlockState());
        p(lvl, tx+4, oy+1, oz+6, Blocks.SMITHING_TABLE.defaultBlockState());

        // Entrada
        for (int h = 1; h <= 4; h++) p(lvl, tx+6, oy+h, oz, Blocks.AIR.defaultBlockState());

        // === Estábulo (ala leste) ===
        buildStable(lvl, ox+22, oy, oz);
    }

    private static void buildStable(ServerLevel lvl, int ox, int oy, int oz) {
        BlockState log  = Blocks.OAK_LOG.defaultBlockState();
        BlockState plank = Blocks.OAK_PLANKS.defaultBlockState();
        BlockState hay  = Blocks.HAY_BLOCK.defaultBlockState();

        fillHollow(lvl, ox-6, oy, oz-5, ox+6, oy+5, oz+5, log);
        floor(lvl, ox-5, oy, oz-4, ox+5, oz+4, plank);

        // Teto de feno
        for (int x = ox-5; x <= ox+5; x++)
            for (int z = oz-4; z <= oz+4; z++)
                p(lvl, x, oy+6, z, hay);

        // Divisórias dos estábulos
        for (int px : new int[]{ox-2, ox+2}) {
            for (int z = oz-4; z <= oz+4; z++)
                p(lvl, px, oy+1, z, Blocks.OAK_FENCE.defaultBlockState());
        }

        // Lanternas
        p(lvl, ox-4, oy+4, oz, Blocks.LANTERN.defaultBlockState());
        p(lvl, ox,   oy+4, oz, Blocks.LANTERN.defaultBlockState());
        p(lvl, ox+4, oy+4, oz, Blocks.LANTERN.defaultBlockState());

        // Entrada
        for (int h = 1; h <= 3; h++) p(lvl, ox, oy+h, oz+5, Blocks.AIR.defaultBlockState());
    }

    // ============================================================
    //  ESTÁGIO 15 — Decoração completa + iluminação (nível 75)
    // ============================================================
    private static void buildStage15(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // Iluminação do topo das muralhas
        for (int x = ox-24; x <= ox+24; x += 3) {
            p(lvl, x, oy+10, oz-24, Blocks.LANTERN.defaultBlockState());
            p(lvl, x, oy+10, oz+24, Blocks.LANTERN.defaultBlockState());
        }
        for (int z = oz-24; z <= oz+24; z += 3) {
            p(lvl, ox-24, oy+10, z, Blocks.LANTERN.defaultBlockState());
            p(lvl, ox+24, oy+10, z, Blocks.LANTERN.defaultBlockState());
        }

        // Decoração de bandeiras no topo das torres frontais
        int towerTopFront = oy + 38 + 18 + 2;
        // Torre frontal esquerda
        for (int dy = 0; dy <= 3; dy++) {
            p(lvl, ox-16, towerTopFront+dy, oz+18, Blocks.RED_WOOL.defaultBlockState());
        }
        // Torre frontal direita
        for (int dy = 0; dy <= 3; dy++) {
            p(lvl, ox+16, towerTopFront+dy, oz+18, Blocks.YELLOW_WOOL.defaultBlockState());
        }

        // Contrafotes nas paredes externas da nave
        BlockState slate = Blocks.DEEPSLATE_BRICKS.defaultBlockState();
        for (int z = oz-14; z <= oz+14; z += 7) {
            fill(lvl, ox-15, oy, z-1, ox-16, oy+8, z+1, slate);  // leste
            fill(lvl, ox+15, oy, z-1, ox+16, oy+8, z+1, slate);  // oeste
        }

        // Passarelas nas muralhas
        for (int x = ox-23; x <= ox+23; x++) {
            p(lvl, x, oy+8, oz-24, Blocks.OAK_PLANKS.defaultBlockState());
            p(lvl, x, oy+8, oz+24, Blocks.OAK_PLANKS.defaultBlockState());
        }
        for (int z = oz-23; z <= oz+23; z++) {
            p(lvl, ox-24, oy+8, z, Blocks.OAK_PLANKS.defaultBlockState());
            p(lvl, ox+24, oy+8, z, Blocks.OAK_PLANKS.defaultBlockState());
        }

        // Torres medianas nas muralhas (meio de cada lado)
        gothicTower(lvl, ox,    oy, oz-24, 2, 12, 6);
        gothicTower(lvl, ox,    oy, oz+24, 2, 12, 6);
        gothicTower(lvl, ox-24, oy, oz,    2, 12, 6);
        gothicTower(lvl, ox+24, oy, oz,    2, 12, 6);
    }

    // ============================================================
    //  ESTÁGIO 16 — CASTELO COMPLETO: Relíquias e bandeiras (nível 80)
    // ============================================================
    private static void buildStage16(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();

        // === Bandeira da Valdoria no pico da torre central ===
        int centralPeak = oy + 50 + 50 + 25 + 3;
        for (int dy = 0; dy <= 5; dy++) {
            p(lvl, ox-1, centralPeak+dy, oz, Blocks.RED_WOOL.defaultBlockState());
            if (dy <= 2) p(lvl, ox, centralPeak+dy, oz, Blocks.YELLOW_WOOL.defaultBlockState());
        }
        p(lvl, ox, centralPeak+6, oz, Blocks.GOLD_BLOCK.defaultBlockState());

        // === Estátuas de guardiões nos cantos internos ===
        for (int[] pos : new int[][]{{ox-12,oz+17},{ox+12,oz+17},{ox-12,oz-17},{ox+12,oz-17}}) {
            p(lvl, pos[0], oy+1, pos[1], Blocks.IRON_BLOCK.defaultBlockState());
            p(lvl, pos[0], oy+2, pos[1], Blocks.IRON_BLOCK.defaultBlockState());
            p(lvl, pos[0], oy+3, pos[1], Blocks.IRON_BLOCK.defaultBlockState());
            p(lvl, pos[0], oy+4, pos[1], Blocks.GOLD_BLOCK.defaultBlockState());  // cabeça dourada
            p(lvl, pos[0], oy+5, pos[1], Blocks.LANTERN.defaultBlockState());
        }

        // === Relíquias no salão do trono ===
        int y4 = oy + 49;
        // Espadas cruzadas (blocos decorativos)
        p(lvl, ox-2, y4+2, oz+10, Blocks.IRON_BARS.defaultBlockState());
        p(lvl, ox+2, y4+2, oz+10, Blocks.IRON_BARS.defaultBlockState());
        p(lvl, ox, y4+3, oz+10, Blocks.IRON_BARS.defaultBlockState());

        // === Neve ao redor da ala de Nivéria ===
        for (int x = ox-10; x <= ox+10; x++)
            for (int z = oz-35; z <= oz-30; z++)
                p(lvl, x, oy, z, Blocks.SNOW_BLOCK.defaultBlockState());

        // === Flores no pátio ===
        for (int px : new int[]{ox-18,ox-14,ox+14,ox+18}) {
            p(lvl, px, oy, oz+22, Blocks.DANDELION.defaultBlockState());
            p(lvl, px, oy, oz+28, Blocks.POPPY.defaultBlockState());
        }

        // === Iluminação final: tochas em todas as passarelas internas ===
        for (int x = ox-12; x <= ox+12; x += 4) {
            p(lvl, x, oy+2, oz-17, Blocks.TORCH.defaultBlockState());
            p(lvl, x, oy+2, oz+17, Blocks.TORCH.defaultBlockState());
        }
        for (int z = oz-14; z <= oz+14; z += 4) {
            p(lvl, ox-13, oy+2, z, Blocks.TORCH.defaultBlockState());
            p(lvl, ox+13, oy+2, z, Blocks.TORCH.defaultBlockState());
        }

        // === Mar de gelo azul dentro do portal de Nivéria (finalização) ===
        for (int x = ox-2; x <= ox+2; x++)
            for (int z = oz-29; z <= oz-27; z++)
                p(lvl, x, oy+1, z, Blocks.BLUE_ICE.defaultBlockState());

        // === Fim: mensagem de conquista (bloco de comando simulado) ===
        // O sistema de quests cuida do resto — o castelo está completo
    }
}
