package com.valdoria.rpg.data;

import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

/** Tudo salvo em persistentData (sobrevive à morte). */
public final class PlayerData {
    public static final float MAX_MANA = 100.0F;

    // Classes disponíveis
    public static final int CLASS_NONE      = 0;
    public static final int CLASS_GUERREIRO = 1;
    public static final int CLASS_MAGO      = 2;
    public static final int CLASS_ARQUEIRO  = 3;
    public static final int CLASS_REI_GELO  = 4; // 40% menos debuffs Nivéria + Redemoinho de Gelo

    // ===== SPIRIT AURA — 7 níveis, 1 token a cada 15 missões =====
    public static final int AURA_NONE        = 0;
    public static final int AURA_VERDANT     = 1;  // Verde  — Natureza      (15 quests)
    public static final int AURA_RADIANCE    = 2;  // Amarelo — Luz           (30 quests)
    public static final int AURA_EMBER       = 3;  // Laranja — Fogo          (45 quests)
    public static final int AURA_CRIMSON     = 4;  // Vermelho — Guerra       (60 quests)
    public static final int AURA_ARCANE      = 5;  // Roxo — Magia            (75 quests)
    public static final int AURA_GLACIAL     = 6;  // Azul — Gelo/Nivéria     (90 quests)
    public static final int AURA_OMNIPOTENT  = 7;  // Preto radiante — Full   (101 quests)
    public static final int AURA_MAX         = 7;

    private PlayerData() {}

    public static CompoundTag root(Player p) {
        CompoundTag forge = p.getPersistentData();
        if (!forge.contains(Player.PERSISTED_NBT_TAG, 10)) forge.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag persisted = forge.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains(ValdoriaMod.MODID, 10)) persisted.put(ValdoriaMod.MODID, new CompoundTag());
        return persisted.getCompound(ValdoriaMod.MODID);
    }

    public static int getFaction(Player p)          { return root(p).getInt("faction"); }
    public static void setFaction(Player p, int f)  { root(p).putInt("faction", f); }

    public static int getCompleted(Player p)         { return root(p).getInt("completed"); }
    public static void setCompleted(Player p, int n) { root(p).putInt("completed", n); }

    // ===== CLASSE =====
    public static int getPlayerClass(Player p)       { return root(p).getInt("playerClass"); }
    public static void setPlayerClass(Player p, int c) { root(p).putInt("playerClass", c); }

    public static String getClassName(Player p) {
        return switch (getPlayerClass(p)) {
            case CLASS_GUERREIRO -> "Guerreiro";
            case CLASS_MAGO      -> "Mago";
            case CLASS_ARQUEIRO  -> "Arqueiro";
            case CLASS_REI_GELO  -> "Rei Secreto do Gelo";
            default              -> "Sem Classe";
        };
    }

    /** Número de trocas de classe já usadas (máx 2 permitidas). */
    public static int getClassChanges(Player p)      { return root(p).getInt("classChanges"); }
    public static void addClassChange(Player p)      { root(p).putInt("classChanges", getClassChanges(p) + 1); }

    /** Cooldown do Redemoinho de Gelo (Rei Secreto) em ticks. 0 = disponível. */
    public static int getWhirlpoolCooldown(Player p) { return root(p).getInt("whirlpoolCd"); }
    public static void setWhirlpoolCooldown(Player p, int ticks) { root(p).putInt("whirlpoolCd", Math.max(0, ticks)); }
    public static void tickWhirlpool(Player p) {
        int cd = getWhirlpoolCooldown(p);
        if (cd > 0) root(p).putInt("whirlpoolCd", cd - 1);
    }

    // ===== MANA (Mago tem +50% de mana máxima) =====
    public static float getMaxMana(Player p) {
        return getPlayerClass(p) == CLASS_MAGO ? MAX_MANA * 1.5F : MAX_MANA;
    }
    public static float getMana(Player p) {
        CompoundTag t = root(p);
        return t.contains("mana") ? t.getFloat("mana") : MAX_MANA;
    }
    public static void setMana(Player p, float v) {
        root(p).putFloat("mana", Math.max(0.0F, Math.min(getMaxMana(p), v)));
    }
    public static void addMana(Player p, float v) { setMana(p, getMana(p) + v); }

    // ===== KILLS / FLAGS =====
    public static int getKills(Player p, String key) {
        CompoundTag t = root(p);
        return t.contains("kills", 10) ? t.getCompound("kills").getInt(key) : 0;
    }
    public static void addKill(Player p, String key) {
        CompoundTag t = root(p);
        if (!t.contains("kills", 10)) t.put("kills", new CompoundTag());
        CompoundTag k = t.getCompound("kills");
        k.putInt(key, k.getInt(key) + 1);
    }

    public static boolean hasFlag(Player p, String flag) {
        CompoundTag t = root(p);
        return t.contains("flags", 10) && t.getCompound("flags").getBoolean(flag);
    }
    public static void setFlag(Player p, String flag) {
        CompoundTag t = root(p);
        if (!t.contains("flags", 10)) t.put("flags", new CompoundTag());
        t.getCompound("flags").putBoolean(flag, true);
    }

    // ===== SPIRIT AURA =====

    /** Tokens de troca disponíveis (1 a cada 15 missões concluídas). */
    public static int getAuraTokens(Player p)        { return root(p).getInt("auraTokens"); }
    public static void setAuraTokens(Player p, int n){ root(p).putInt("auraTokens", Math.max(0, n)); }
    public static void addAuraToken(Player p)        { setAuraTokens(p, getAuraTokens(p) + 1); }

    /** Nível máximo de aura desbloqueado (0 = nenhuma, 1-7). */
    public static int getAuraLevel(Player p)         { return root(p).getInt("auraLevel"); }
    public static void setAuraLevel(Player p, int lv){ root(p).putInt("auraLevel", Math.min(lv, AURA_MAX)); }

    /** Nível de aura atualmente equipado/selecionado (0 = desligado). */
    public static int getAuraEquipped(Player p)      { return root(p).getInt("auraEquipped"); }
    public static void setAuraEquipped(Player p, int lv){ root(p).putInt("auraEquipped", lv); }

    /** Aura está ativa (brilhando / dando buffs)? */
    public static boolean isAuraActive(Player p)     { return root(p).getBoolean("auraActive"); }
    public static void setAuraActive(Player p, boolean b){ root(p).putBoolean("auraActive", b); }

    /** Nível desbloqueado que ainda não foi "usado" para trocar (precisa de token). */
    public static int nextAuraLevel(Player p) {
        int completed = getCompleted(p);
        if (completed >= 101) return AURA_OMNIPOTENT;
        return Math.min(completed / 15, AURA_MAX);
    }

    public static String getAuraName(int level) {
        return switch (level) {
            case AURA_VERDANT    -> "§a✦ Aura Verdante";
            case AURA_RADIANCE   -> "§e✦ Aura Radiante";
            case AURA_EMBER      -> "§6✦ Aura Brasa";
            case AURA_CRIMSON    -> "§c✦ Aura Carmesim";
            case AURA_ARCANE     -> "§5✦ Aura Arcana";
            case AURA_GLACIAL    -> "§b✦ Aura Glacial";
            case AURA_OMNIPOTENT -> "§0§l✦ AURA ONIPOTENTE ✦";
            default              -> "§7Sem Aura";
        };
    }
}
