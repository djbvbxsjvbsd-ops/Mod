// [CastleBuilder.java] — Castelo refeito: maior, com quartos, terraplanagem, portal Nivéria
package com.valdoria.rpg.world;

import com.valdoria.rpg.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

public final class CastleBuilder {
    private CastleBuilder() {}

    // ===== ENTRY POINTS =====

    public static void build(ServerLevel level, int stage) {
        ServerLevel ow = level.getServer().getLevel(Level.OVERWORLD);
        if (ow == null) return;
        BlockPos spawn = ow.getSharedSpawnPos();
        // Ancora o castelo: o piso fica em y = altura do terreno no spawn
        int groundY = ow.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, spawn.getX(), spawn.getZ());
        BlockPos origin = new BlockPos(spawn.getX(), groundY, spawn.getZ());
        buildAt(ow, origin, stage);
    }

    public static void build(ServerLevel level, BlockPos ignored, int stage) { build(level, stage); }

    // ===== MAIN DISPATCHER =====

    private static void buildAt(ServerLevel lvl, BlockPos o, int stage) {
        if (stage >= 1) { clearTerrain(lvl, o); buildStage1(lvl, o); }
        if (stage >= 2) buildStage2(lvl, o);
        if (stage >= 3) buildStage3(lvl, o);
        if (stage >= 4) buildStage4(lvl, o);
        if (stage >= 5) buildStage5(lvl, o);
        if (stage >= 6) buildStage6(lvl, o);
        if (stage >= 7) buildStage7(lvl, o);
        if (stage >= 8) buildStage8(lvl, o);
        if (stage >= 9) buildFullCastle(lvl, o);
    }

    // ===== HELPERS =====

    private static void p(ServerLevel lvl, int x, int y, int z, BlockState b) {
        lvl.setBlockAndUpdate(new BlockPos(x, y, z), b);
    }

    private static void fill(ServerLevel lvl, int x1, int y1, int z1, int x2, int y2, int z2, BlockState b) {
        for (int x = Math.min(x1,x2); x <= Math.max(x1,x2); x++)
            for (int y = Math.min(y1,y2); y <= Math.max(y1,y2); y++)
                for (int z = Math.min(z1,z2); z <= Math.max(z1,z2); z++)
                    lvl.setBlockAndUpdate(new BlockPos(x, y, z), b);
    }

    private static void fillHollow(ServerLevel lvl, int x1, int y1, int z1, int x2, int y2, int z2, BlockState wall) {
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++) {
                    boolean edge = x==x1||x==x2||y==y1||y==y2||z==z1||z==z2;
                    if (edge) lvl.setBlockAndUpdate(new BlockPos(x,y,z), wall);
                }
    }

    // ===== TERRAPLANAGEM (limpa 50x50 ao redor do spawn) =====

    private static void clearTerrain(ServerLevel lvl, BlockPos o) {
        int ox = o.getX(), oy = o.getY(), oz = o.getZ();
        for (int x = ox-25; x <= ox+25; x++)
            for (int z = oz-25; z <= oz+25; z++) {
                // Remove blocos acima do piso base
                for (int y = oy; y <= oy + 40; y++)
                    lvl.setBlockAndUpdate(new BlockPos(x, y, z), Blocks.AIR.defaultBlockState());
                // Nivela o chão
                for (int y = oy - 5; y < oy; y++)
                    lvl.setBlockAndUpdate(new BlockPos(x, y, z), Blocks.STONE.defaultBlockState());
            }
    }

    // ===== ESTÁGIO 1 — Fundação e piso =====
    private static void buildStage1(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        // Piso externo (42x42)
        fill(lvl, ox-21, oy-1, oz-21, ox+21, oy-1, oz+21, Blocks.STONE_BRICKS.defaultBlockState());
        // Piso interno (praça central)
        fill(lvl, ox-15, oy-1, oz-15, ox+15, oy-1, oz+15, Blocks.POLISHED_ANDESITE.defaultBlockState());
        // Fosso
        for (int x = ox-23; x <= ox+23; x++)
            for (int z = oz-23; z <= oz+23; z++)
                if (Math.abs(x-ox)>=22 || Math.abs(z-oz)>=22)
                    fill(lvl, x, oy-3, z, x, oy-1, z, Blocks.WATER.defaultBlockState());
    }

    // ===== ESTÁGIO 2 — Muralhas externas =====
    private static void buildStage2(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        BlockState wall = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState merlon = Blocks.COBBLESTONE_WALL.defaultBlockState();
        // 4 lados da muralha (H=6)
        for (int h=0; h<6; h++) {
            for (int x=ox-21; x<=ox+21; x++) {
                p(lvl,x,oy+h,oz-21,wall); p(lvl,x,oy+h,oz+21,wall);
            }
            for (int z=oz-20; z<=oz+20; z++) {
                p(lvl,ox-21,oy+h,z,wall); p(lvl,ox+21,oy+h,z,wall);
            }
        }
        // Ameias (a cada 2 blocos)
        for (int x=ox-21; x<=ox+21; x+=2) {
            p(lvl,x,oy+6,oz-21,merlon); p(lvl,x,oy+6,oz+21,merlon);
        }
        for (int z=oz-21; z<=oz+21; z+=2) {
            p(lvl,ox-21,oy+6,z,merlon); p(lvl,ox+21,oy+6,z,merlon);
        }
        // Portão frontal (sul)
        for (int h=0; h<5; h++) for (int px=-2; px<=2; px++)
            p(lvl,ox+px,oy+h,oz+21,Blocks.AIR.defaultBlockState());
        p(lvl,ox-3,oy+5,oz+21,Blocks.STONE_BRICK_SLAB.defaultBlockState());
        p(lvl,ox+3,oy+5,oz+21,Blocks.STONE_BRICK_SLAB.defaultBlockState());
        // Ponte sobre o fosso
        for (int z=oz+21; z<=oz+24; z++)
            for (int px=-2; px<=2; px++)
                p(lvl,ox+px,oy-1,z,Blocks.OAK_PLANKS.defaultBlockState());
    }

    // ===== ESTÁGIO 3 — Torres dos cantos =====
    private static void buildStage3(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        int[][] corners = {{ox-21,oz-21},{ox+21,oz-21},{ox-21,oz+21},{ox+21,oz+21}};
        for (int[] c : corners) buildCornerTower(lvl, c[0], oy, c[1]);
    }

    private static void buildCornerTower(ServerLevel lvl, int tx, int oy, int tz) {
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState roof  = Blocks.RED_WOOL.defaultBlockState();
        int sign = (tx < 0 ? -1 : 1);
        int signz = (tz < 0 ? -1 : 1);
        // Torre 5x5x12
        for (int h=0; h<=12; h++)
            for (int dx=-2; dx<=2; dx++) for (int dz=-2; dz<=2; dz++) {
                boolean wall = dx==-2||dx==2||dz==-2||dz==2||h==0||h==12;
                if (wall) lvl.setBlockAndUpdate(new BlockPos(tx+dx*sign,oy+h,tz+dz*signz),brick);
            }
        // Telhado cônico
        for (int dy=0; dy<=3; dy++) {
            int r = 2-dy;
            for (int dx=-r; dx<=r; dx++) for (int dz=-r; dz<=r; dz++)
                lvl.setBlockAndUpdate(new BlockPos(tx+dx*sign,oy+13+dy,tz+dz*signz),
                        dy==3?Blocks.TORCH.defaultBlockState():roof);
        }
    }

    // ===== ESTÁGIO 4 — Keep central (edifício principal) =====
    private static void buildStage4(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        BlockState dark = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        // Keep 21x25, H=10
        fillHollow(lvl, ox-10, oy, oz-12, ox+10, oy+10, oz+10, brick);
        // Piso interno
        fill(lvl, ox-9, oy, oz-11, ox+9, oy, oz+9, dark);
        // Teto
        fill(lvl, ox-9, oy+10, oz-11, ox+9, oy+10, oz+9, dark);
        // Entrada (norte da keep)
        for (int h=1; h<=3; h++) for (int px=-1; px<=1; px++)
            p(lvl,ox+px,oy+h,oz+10,Blocks.AIR.defaultBlockState());
        // Janelas laterais
        for (int wz : new int[]{oz-5,oz,oz+5}) {
            p(lvl,ox-10,oy+4,wz,Blocks.GLASS.defaultBlockState());
            p(lvl,ox+10,oy+4,wz,Blocks.GLASS.defaultBlockState());
        }
        for (int wx : new int[]{ox-5,ox,ox+5}) {
            p(lvl,wx,oy+4,oz-12,Blocks.GLASS.defaultBlockState());
        }
        // Portão da keep
        p(lvl,ox-1,oy+1,oz+10,Blocks.OAK_DOOR.defaultBlockState());
        p(lvl,ox,oy+1,oz+10,Blocks.AIR.defaultBlockState());
        p(lvl,ox+1,oy+1,oz+10,Blocks.OAK_DOOR.defaultBlockState());
    }

    // ===== ESTÁGIO 5 — Quartos internos =====
    private static void buildStage5(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        // ---- QUARTO DO TRONO (fundo da keep) ----
        fill(lvl,ox-5,oy,oz-11,ox+5,oy,oz-6, Blocks.RED_CARPET.defaultBlockState());
        // Trono
        p(lvl,ox,oy+1,oz-10,Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl,ox,oy+2,oz-10,Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl,ox-1,oy+1,oz-10,Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl,ox+1,oy+1,oz-10,Blocks.GOLD_BLOCK.defaultBlockState());
        p(lvl,ox,oy+3,oz-10,Blocks.TORCH.defaultBlockState());
        // Separação com parede parcial
        for (int px=ox-9; px<=ox+9; px++)
            p(lvl,px,oy+1,oz-5,Blocks.STONE_BRICK_SLAB.defaultBlockState());

        // ---- QUARTO DO CHEFE (missões) ----
        // Sala de reuniões: mesa de crafting, bancada, baús
        p(lvl,ox-6,oy+1,oz+3,Blocks.CRAFTING_TABLE.defaultBlockState());
        p(lvl,ox-7,oy+1,oz+3,Blocks.CHEST.defaultBlockState());
        p(lvl,ox-6,oy+1,oz+4,Blocks.FURNACE.defaultBlockState());

        // ---- QUARTO DA BIBLIOTECA ----
        for (int bx=ox+5; bx<=ox+9; bx++) {
            p(lvl,bx,oy+1,oz-3,Blocks.BOOKSHELF.defaultBlockState());
            p(lvl,bx,oy+2,oz-3,Blocks.BOOKSHELF.defaultBlockState());
        }
        p(lvl,ox+7,oy+1,oz-2,Blocks.ENCHANTING_TABLE.defaultBlockState());

        // ---- ARMÁRIO DE ARMAS ----
        for (int bx=ox-9; bx<=ox-5; bx++) {
            p(lvl,bx,oy+1,oz+7,Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        }
        p(lvl,ox-7,oy+1,oz+6,Blocks.ANVIL.defaultBlockState());
        p(lvl,ox-6,oy+1,oz+6,Blocks.CHEST.defaultBlockState());

        // ---- DORMITÓRIO ----
        for (int bx : new int[]{ox+4, ox+6, ox+8}) {
            p(lvl,bx,oy+1,oz+7,Blocks.RED_BED.defaultBlockState());
        }
    }

    // ===== ESTÁGIO 6 — Andar 2 da keep (salão elevado) =====
    private static void buildStage6(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        int y2 = oy+11;
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState dark  = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        // Segundo andar (mesmo tamanho) H=7
        fillHollow(lvl, ox-10, y2, oz-12, ox+10, y2+7, oz+10, brick);
        fill(lvl, ox-9, y2+7, oz-11, ox+9, y2+7, oz+9, dark);
        // Janelas
        for (int wx=ox-7; wx<=ox+7; wx+=3) {
            p(lvl,wx,y2+3,oz-12,Blocks.GLASS.defaultBlockState());
            p(lvl,wx,y2+3,oz+10, Blocks.GLASS.defaultBlockState());
        }
        // Escada interna (conecta térreo ao 2º andar)
        for (int h=0; h<11; h++)
            p(lvl,ox+9,oy+h,oz+8,Blocks.OAK_STAIRS.defaultBlockState());
        // Sala do conselho
        fill(lvl, ox-7, y2+1, oz-8, ox+7, y2+1, oz+5, dark);
        // Mesa central (linha de gold)
        for (int px=ox-4; px<=ox+4; px++)
            p(lvl,px,y2+2,oz,Blocks.GOLD_BLOCK.defaultBlockState());
        // Beacon no centro
        p(lvl,ox,y2+3,oz,Blocks.BEACON.defaultBlockState());
        // Tochas
        for (int[] t : new int[][]{{ox-8,oz-8},{ox+8,oz-8},{ox-8,oz+7},{ox+8,oz+7}})
            p(lvl,t[0],y2+4,t[1],Blocks.LANTERN.defaultBlockState());
    }

    // ===== ESTÁGIO 7 — Torre central alta + passarelas =====
    private static void buildStage7(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        // Torre central acima da keep: 5x5x20
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        int yBase = oy+18;
        for (int h=0; h<=20; h++)
            for (int dx=-2; dx<=2; dx++) for (int dz=-2; dz<=2; dz++) {
                if (dx==-2||dx==2||dz==-2||dz==2||h==0||h==20)
                    p(lvl,ox+dx,yBase+h,oz+dz,brick);
            }
        // Bandeiras
        p(lvl,ox-2,yBase+20,oz,Blocks.RED_WOOL.defaultBlockState());
        p(lvl,ox+2,yBase+20,oz,Blocks.RED_WOOL.defaultBlockState());
        p(lvl,ox,yBase+21,oz,Blocks.YELLOW_WOOL.defaultBlockState());

        // Passarelas das torres dos cantos até a keep
        for (int[] c : new int[][]{{ox-21,oz-21},{ox+21,oz-21},{ox-21,oz+21},{ox+21,oz+21}}) {
            int tx=c[0], tz=c[1];
            // Passarela no nível y+7 (topo da muralha)
            int stepX = (tx<ox?1:-1), stepZ = (tz<oz?1:-1);
            for (int step=0; step<=5; step++) {
                int wx = tx + stepX*step;
                int wz = tz + stepZ*step;
                p(lvl,wx,oy+7,wz,Blocks.OAK_PLANKS.defaultBlockState());
            }
        }
    }

    // ===== ESTÁGIO 8 — Pátio, jardim e iluminação =====
    private static void buildStage8(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        // Jardim leste
        for (int x=ox+12; x<=ox+19; x++) for (int z=oz-8; z<=oz+8; z++)
            p(lvl,x,oy,z,Blocks.GRASS_BLOCK.defaultBlockState());
        for (int[] t : new int[][]{{ox+14,oz-5},{ox+14,oz+5},{ox+17,oz}})
            p(lvl,t[0],oy+1,t[1],Blocks.OAK_LOG.defaultBlockState());

        // Jardim oeste
        for (int x=ox-19; x<=ox-12; x++) for (int z=oz-8; z<=oz+8; z++)
            p(lvl,x,oy,z,Blocks.GRASS_BLOCK.defaultBlockState());

        // Pátio sul (frente da keep)
        fill(lvl,ox-9,oy,oz+11,ox+9,oy,oz+19, Blocks.POLISHED_ANDESITE.defaultBlockState());
        // Fonte central no pátio
        fill(lvl,ox-2,oy,oz+14,ox+2,oy+1,oz+16, Blocks.STONE_BRICKS.defaultBlockState());
        fill(lvl,ox-1,oy+1,oz+15,ox+1,oy+1,oz+15, Blocks.WATER.defaultBlockState());
        p(lvl,ox,oy+2,oz+15,Blocks.SEA_LANTERN.defaultBlockState());

        // Lanternas ao longo das muralhas
        for (int x : new int[]{ox-18,ox-12,ox-6,ox,ox+6,ox+12,ox+18}) {
            p(lvl,x,oy+6,oz-21,Blocks.LANTERN.defaultBlockState());
            p(lvl,x,oy+6,oz+21,Blocks.LANTERN.defaultBlockState());
        }
        for (int z : new int[]{oz-18,oz-12,oz-6,oz,oz+6,oz+12,oz+18}) {
            p(lvl,ox-21,oy+6,z,Blocks.LANTERN.defaultBlockState());
            p(lvl,ox+21,oy+6,z,Blocks.LANTERN.defaultBlockState());
        }

        // Torres intermediárias (meio de cada lado)
        buildSideTower(lvl, ox, oy, oz-21, true);  // norte
        buildSideTower(lvl, ox, oy, oz+21, true);  // sul
        buildSideTower(lvl, ox-21, oy, oz, false); // oeste
        buildSideTower(lvl, ox+21, oy, oz, false); // leste
    }

    private static void buildSideTower(ServerLevel lvl, int tx, int oy, int tz, boolean nsAxis) {
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        for (int h=0; h<=9; h++)
            for (int a=-2; a<=2; a++) for (int b=-2; b<=2; b++) {
                boolean wall = a==-2||a==2||b==-2||b==2||h==0||h==9;
                if (!wall) continue;
                int x = nsAxis ? tx+a : tx;
                int z = nsAxis ? tz   : tz+a;
                if (nsAxis) z = tz+b; else x = tx+b;
                lvl.setBlockAndUpdate(new BlockPos(x,oy+h,z),brick);
            }
        p(lvl,tx,oy+10,tz,Blocks.TORCH.defaultBlockState());
    }

    // ===== ESTÁGIO 9 — Castelo completo + Portal de Nivéria =====
    private static void buildFullCastle(ServerLevel lvl, BlockPos o) {
        int ox=o.getX(), oy=o.getY(), oz=o.getZ();
        // === PORTAL DE NIVÉRIA no pátio oeste da keep ===
        // Frame de blocos de gelo empacotado 4x5
        for (int h=0; h<=5; h++) {
            p(lvl,ox-14,oy+h,oz,Blocks.PACKED_ICE.defaultBlockState());
            p(lvl,ox-10,oy+h,oz,Blocks.PACKED_ICE.defaultBlockState());
        }
        for (int px=ox-14; px<=ox-10; px++) {
            p(lvl,px,oy+6,oz,Blocks.PACKED_ICE.defaultBlockState());
            p(lvl,px,oy,oz,Blocks.PACKED_ICE.defaultBlockState());
        }
        // Bloco especial do portal (2 de altura dentro do frame)
        try {
            p(lvl,ox-13,oy+1,oz,lvl.getServer().registryAccess()!=null
                    ? ModBlocks.PORTAL_NIVERIA.get().defaultBlockState()
                    : Blocks.BLUE_ICE.defaultBlockState());
            p(lvl,ox-12,oy+1,oz,ModBlocks.PORTAL_NIVERIA.get().defaultBlockState());
            p(lvl,ox-11,oy+1,oz,ModBlocks.PORTAL_NIVERIA.get().defaultBlockState());
            p(lvl,ox-13,oy+2,oz,ModBlocks.PORTAL_NIVERIA.get().defaultBlockState());
            p(lvl,ox-12,oy+2,oz,ModBlocks.PORTAL_NIVERIA.get().defaultBlockState());
            p(lvl,ox-11,oy+2,oz,ModBlocks.PORTAL_NIVERIA.get().defaultBlockState());
        } catch (Exception e) {
            // Fallback se bloco ainda não registrado
            for (int px=ox-13; px<=ox-11; px++)
                for (int py=oy+1; py<=oy+2; py++)
                    p(lvl,px,py,oz,Blocks.BLUE_ICE.defaultBlockState());
        }
        // Placa de sinalização
        p(lvl,ox-12,oy+7,oz,Blocks.BEACON.defaultBlockState());
        // Neve ao redor do portal (decoração)
        for (int dx=ox-15; dx<=ox-9; dx++)
            p(lvl,dx,oy,oz-1,Blocks.SNOW_BLOCK.defaultBlockState());
        for (int dx=ox-15; dx<=ox-9; dx++)
            p(lvl,dx,oy,oz+1,Blocks.SNOW_BLOCK.defaultBlockState());

        // === SALAS ADICIONAIS (térreo leste) ===
        // Sala de treino (leste externo)
        buildTrainingRoom(lvl, ox+16, oy, oz);
        // Estábulo (norte)
        buildStable(lvl, ox, oy, oz-16);
    }

    private static void buildTrainingRoom(ServerLevel lvl, int ox, int oy, int oz) {
        BlockState brick = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState wood  = Blocks.OAK_PLANKS.defaultBlockState();
        fillHollow(lvl, ox-4, oy, oz-4, ox+4, oy+5, oz+4, brick);
        fill(lvl, ox-3, oy, oz-3, ox+3, oy, oz+3, wood);
        // Alvos de treino
        p(lvl,ox,oy+1,oz-3,Blocks.TARGET.defaultBlockState());
        p(lvl,ox-3,oy+1,oz,Blocks.TARGET.defaultBlockState());
        p(lvl,ox+3,oy+1,oz,Blocks.TARGET.defaultBlockState());
        p(lvl,ox,oy+1,oz+3,Blocks.CHEST.defaultBlockState());
        p(lvl,ox,oy+2,oz,Blocks.CRAFTING_TABLE.defaultBlockState());
        // Entrada
        for (int h=1; h<=3; h++) p(lvl,ox,oy+h,oz+4,Blocks.AIR.defaultBlockState());
    }

    private static void buildStable(ServerLevel lvl, int ox, int oy, int oz) {
        BlockState wood = Blocks.OAK_LOG.defaultBlockState();
        BlockState plank = Blocks.OAK_PLANKS.defaultBlockState();
        fillHollow(lvl, ox-5, oy, oz-4, ox+5, oy+4, oz+4, wood);
        fill(lvl, ox-4, oy, oz-3, ox+4, oy, oz+3, plank);
        // Telhado de palha
        for (int x=ox-5; x<=ox+5; x++) for (int z=oz-4; z<=oz+4; z++)
            p(lvl,x,oy+5,z,Blocks.HAY_BLOCK.defaultBlockState());
        // Separações dos boxes
        for (int px : new int[]{ox-2, ox+2}) {
            for (int z=oz-3; z<=oz+3; z++) p(lvl,px,oy+1,z,Blocks.OAK_FENCE.defaultBlockState());
        }
        p(lvl,ox,oy+4,oz,Blocks.LANTERN.defaultBlockState());
        // Entrada
        for (int h=1; h<=3; h++) p(lvl,ox,oy+h,oz+4,Blocks.AIR.defaultBlockState());
    }
}
