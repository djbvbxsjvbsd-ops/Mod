package com.valdoria.rpg.client.renderer;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.world.entity.player.Player;
import org.joml.Matrix4f;

/**
 * Renderiza a Spirit Aura ao redor do jogador local.
 *
 * Chamado em RenderLevelStageEvent (AFTER_ENTITIES) a partir de ClientEvents.
 *
 * Implementação: dois anéis rotativos de partículas/segmentos coloridos ao redor do
 * bounding-box do jogador, usando vertex imediato (modo compatibilidade Forge 1.20).
 * A aura Onipotente adiciona um terceiro anel e um overlay escuro pulsante.
 */
public final class SpiritAuraRenderer {
    private SpiritAuraRenderer() {}

    // Cores ARGB por nível de aura (corresponde às constantes de PlayerData)
    private static final int[] AURA_COLORS = {
        0x00000000, // 0 = nenhuma
        0xFF44FF44, // 1 Verdant  — verde
        0xFFFFEE44, // 2 Radiance — amarelo
        0xFFFF8800, // 3 Ember    — laranja
        0xFFFF3333, // 4 Crimson  — vermelho
        0xFFAA44FF, // 5 Arcane   — roxo
        0xFF44CCFF, // 6 Glacial  — azul gelo
        0xFF111111, // 7 Omnipotent — preto radiante (desenhamos efeito especial)
    };

    // Cor do "brilho" interno para a aura Onipotente (branco/cinza muito brilhante)
    private static final int OMNI_INNER = 0xFFCCCCCC;

    private static long tickCounter = 0;

    /** Deve ser chamado no tick do cliente para animar. */
    public static void clientTick() { tickCounter++; }

    /**
     * Renderiza a aura em volta do jogador local.
     *
     * @param poseStack  PoseStack com a câmera já posicionada (espaço-mundo)
     * @param partialTick partialTick para interpolação suave
     */
    public static void render(PoseStack poseStack, float partialTick) {
        if (!ClientData.auraActive) return;
        int lv = ClientData.auraEquipped;
        if (lv <= 0 || lv > PlayerData.AURA_MAX) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        AbstractClientPlayer player = mc.player;

        // Posição interpolada do jogador
        double px = player.xo + (player.getX() - player.xo) * partialTick;
        double py = player.yo + (player.getY() - player.yo) * partialTick;
        double pz = player.zo + (player.getZ() - player.zo) * partialTick;

        // Offset relativo à câmera (já aplicado pela PoseStack)
        // O PoseStack aqui assume coordenadas do mundo; a câmera deve ser subtraída
        // pelo chamador (ver ClientEvents.renderLevel).

        poseStack.pushPose();
        poseStack.translate(px, py + 1.0, pz); // centro do corpo

        double angleBase = (tickCounter + partialTick) * 0.04; // velocidade de rotação

        int color = AURA_COLORS[lv];
        int r = (color >> 16) & 0xFF;
        int g = (color >>  8) & 0xFF;
        int b = (color      ) & 0xFF;

        boolean isOmni = (lv == PlayerData.AURA_OMNIPOTENT);

        // ---- Setup render ----
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();

        // Anel 1 — anel horizontal ao redor da cintura
        drawRing(poseStack, buf, tess, r, g, b, 0.7, 0.0, angleBase, 32, 0.08F, isOmni);

        // Anel 2 — anel inclinado sobre a cabeça
        drawRing(poseStack, buf, tess, r, g, b, 0.55, 0.9, angleBase * -0.7, 32, 0.07F, isOmni);

        // Anel 3 extra — apenas para aura Onipotente (maior, pulsante, cinza brilhante)
        if (isOmni) {
            int pulse = (int)(Math.abs(Math.sin(tickCounter * 0.06)) * 180) + 75;
            int ir = (OMNI_INNER >> 16) & 0xFF;
            int ig = (OMNI_INNER >>  8) & 0xFF;
            int ib = (OMNI_INNER      ) & 0xFF;
            poseStack.pushPose();
            poseStack.scale(1.0F, 1.0F, 1.0F);
            drawRingRaw(poseStack, buf, tess, ir, ig, ib, pulse, 1.1, 0.0, angleBase * 1.3, 48, 0.12F);
            poseStack.popPose();

            // Partículas explosivas de energia (pequenos segmentos radiais)
            drawEnergyBursts(poseStack, buf, tess, angleBase);
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();

        poseStack.popPose();
    }

    /** Anel horizontal/inclinado em 2D. */
    private static void drawRing(PoseStack ps, BufferBuilder buf, Tesselator tess,
                                  int r, int g, int b,
                                  double radius, double yOff, double angle,
                                  int segments, float thickness, boolean pulsing) {
        int alpha = pulsing
                ? (int)(Math.abs(Math.sin(tickCounter * 0.05)) * 155) + 100
                : 180;
        drawRingRaw(ps, buf, tess, r, g, b, alpha, radius, yOff, angle, segments, thickness);
    }

    private static void drawRingRaw(PoseStack ps, BufferBuilder buf, Tesselator tess,
                                     int r, int g, int b, int alpha,
                                     double radius, double yOff, double angle,
                                     int segments, float thickness) {
        Matrix4f m = ps.last().pose();
        buf.begin(VertexFormat.Mode.DEBUG_LINE_STRIP, DefaultVertexFormat.POSITION_COLOR);
        for (int i = 0; i <= segments; i++) {
            double a = angle + (i / (double) segments) * Math.PI * 2.0;
            float x = (float)(Math.cos(a) * radius);
            float z = (float)(Math.sin(a) * radius);
            buf.vertex(m, x, (float) yOff, z).color(r, g, b, alpha).endVertex();
        }
        tess.end();
    }

    /** Raios de energia curtos pulsando para fora — apenas Onipotente. */
    private static void drawEnergyBursts(PoseStack ps, BufferBuilder buf, Tesselator tess, double angleBase) {
        Matrix4f m = ps.last().pose();
        int numRays = 12;
        for (int i = 0; i < numRays; i++) {
            double a = angleBase * 2.0 + (i / (double) numRays) * Math.PI * 2.0;
            float pulse = (float)(0.5 + Math.abs(Math.sin(tickCounter * 0.08 + i * 0.5)) * 0.6);
            float x0 = (float)(Math.cos(a) * 0.6);
            float z0 = (float)(Math.sin(a) * 0.6);
            float x1 = (float)(Math.cos(a) * (0.6 + pulse));
            float z1 = (float)(Math.sin(a) * (0.6 + pulse));
            int alpha = (int)(80 + pulse * 100);
            buf.begin(VertexFormat.Mode.DEBUG_LINES, DefaultVertexFormat.POSITION_COLOR);
            buf.vertex(m, x0, 0F, z0).color(220, 220, 220, alpha).endVertex();
            buf.vertex(m, x1, 0F, z1).color(80,  80,  80, alpha / 2).endVertex();
            tess.end();
        }
    }
}
