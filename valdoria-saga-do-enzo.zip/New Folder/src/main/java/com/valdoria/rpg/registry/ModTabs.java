package com.valdoria.rpg.registry;

import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ValdoriaMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.valdorianrpg"))
                    .icon(() -> new ItemStack(ModItems.FOUNDATION_STONE.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.FOUNDATION_STONE.get());
                        out.accept(ModItems.DUNGEON_KEY.get());
                        out.accept(ModItems.GUARDIAN_ESSENCE.get());
                        out.accept(ModItems.ULTIMATE_SWORD.get());
                        out.accept(ModItems.ULTIMATE_HELMET.get());
                        out.accept(ModItems.ULTIMATE_CHESTPLATE.get());
                        out.accept(ModItems.ULTIMATE_LEGGINGS.get());
                        out.accept(ModItems.ULTIMATE_BOOTS.get());
                    })
                    .build());
}
