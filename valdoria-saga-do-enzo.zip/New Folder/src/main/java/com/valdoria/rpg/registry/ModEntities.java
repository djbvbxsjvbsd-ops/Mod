package com.valdoria.rpg.registry;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.entity.MalacharEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ValdoriaMod.MODID);

    public static final RegistryObject<EntityType<MalacharEntity>> MALACHAR = ENTITIES.register("malachar",
            () -> EntityType.Builder.<MalacharEntity>of(MalacharEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.1F).fireImmune().clientTrackingRange(10)
                    .build("malachar"));
}
