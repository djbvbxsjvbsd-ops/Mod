package com.valdoria.rpg.client;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.client.screen.MapScreen;
import com.valdoria.rpg.client.screen.ProfileScreen;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (KeyMappings.PROFILE.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new ProfileScreen());
        }
        while (KeyMappings.MAP.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new MapScreen());
        }
        while (KeyMappings.HUD.consumeClick()) {
            ClientData.hudVisible = !ClientData.hudVisible;
        }
    }

    /** Céu/nevoeiro vermelho do Ato III até a derrota de Malachar. */
    @SubscribeEvent
    public static void fog(ViewportEvent.ComputeFogColor e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (ClientData.completed >= 20 && ClientData.completed < 49 && mc.level.dimension() == Level.OVERWORLD) {
            e.setRed(0.70F);
            e.setGreen(0.05F);
            e.setBlue(0.05F);
        }
    }
}
