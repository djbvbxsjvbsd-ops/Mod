package com.valdoria.rpg.client;

/** Estado sincronizado do servidor (sem imports client-only). */
public final class ClientData {
    public static int faction = 0;
    public static int completed = 0;
    public static float mana = 100.0F;
    public static float maxMana = 100.0F;
    public static boolean hudVisible = true;

    private ClientData() {}

    public static void update(int f, int c, float m, float mm) {
        faction = f; completed = c; mana = m; maxMana = mm;
    }

    public static int act() { return Math.min(5, completed / 10 + 1); }

    public static String factionName() {
        return faction == 1 ? "Anjo (Luz)" : faction == 2 ? "Demônio (Trevas)" : "Nenhuma";
    }
}
