package com.valdoria.rpg.quest;

import net.minecraft.server.level.ServerPlayer;

import java.util.function.Consumer;

public record Quest(int id, int act, String title, Type type, String target, int amount, String lore,
                    Consumer<ServerPlayer> reward) {

    public enum Type { HAVE, KILL, DIM, FACTION, FLAG }

    public String objective() {
        String name = target.contains(":") ? target.substring(target.indexOf(':') + 1).replace('_', ' ') : target;
        return switch (type) {
            case HAVE -> "Ter " + amount + "x " + name + " no inventário";
            case KILL -> "Matar (total) " + amount + "x " + name;
            case DIM -> "Viajar para: " + name;
            case FACTION -> "Escolher uma facção";
            case FLAG -> "Derrotar o Enzo Demoníaco";
        };
    }
}
