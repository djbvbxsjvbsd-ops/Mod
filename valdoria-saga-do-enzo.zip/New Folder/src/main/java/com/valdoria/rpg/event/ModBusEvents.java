package com.valdoria.rpg.event;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.entity.MalacharEntity;
import com.valdoria.rpg.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModBusEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.MALACHAR.get(), MalacharEntity.createAttributes().build());
    }
}
