package com.valdoria.rpg.quest;

import com.valdoria.rpg.entity.MalacharEntity;
import com.valdoria.rpg.registry.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import static com.valdoria.rpg.quest.Quest.Type.*;

public final class QuestData {
    public static final String[] ACT_NAMES = {
            "Ato I - O Despertar", "Ato II - A Sombra se Aproxima", "Ato III - O Despertar do Nether",
            "Ato IV - A Jornada ao End", "Ato V - A Batalha Final"};

    private static final List<Quest> Q = new ArrayList<>();

    private static void q(String title, Quest.Type t, String target, int amt, String lore, Consumer<ServerPlayer> reward) {
        int id = Q.size() + 1;
        Q.add(new Quest(id, (id - 1) / 10 + 1, title, t, target, amt, lore, reward));
    }

    private static Consumer<ServerPlayer> essence() {
        return p -> QuestManager.give(p, new ItemStack(ModItems.GUARDIAN_ESSENCE.get()));
    }

    private static Consumer<ServerPlayer> essenceKey() {
        return p -> {
            QuestManager.give(p, new ItemStack(ModItems.GUARDIAN_ESSENCE.get()));
            QuestManager.give(p, new ItemStack(ModItems.DUNGEON_KEY.get()));
        };
    }

    static {
        // ===== ATO I - O DESPERTAR (1-10) =====
        q("A Chegada", HAVE, "minecraft:oak_log", 16, "Enzo abriu os olhos em um mundo estranho. Valdoria o recebeu com vento frio e bosques silenciosos. Madeira foi o primeiro passo para sobreviver.", null);
        q("O Rei Aldric", HAVE, "minecraft:cobblestone", 64, "Entre as árvores surgiu o Rei Aldric. 'Você é o Escolhido, Enzo. Mas antes da glória, precisa de pedra.'", null);
        q("A Pedra de Fundação", HAVE, "valdorianrpg:foundation_stone", 1, "No coração do vale repousa a Pedra de Fundação. Ao tocá-la, Enzo sentiu o chão de Valdoria acordar.", null);
        q("O Chão do Castelo", HAVE, "minecraft:oak_planks", 64, "Sobre a Pedra, Enzo ergueu o chão do castelo, tábua por tábua, sob o olhar atento de Aldric.", null);
        q("As Muralhas", HAVE, "minecraft:cobblestone", 128, "As muralhas começaram a subir. 'Um reino sem muros é apenas uma promessa', disse o rei.", null);
        q("Pedra Lapidada", HAVE, "minecraft:stone_bricks", 64, "A pedra lapidada trouxe ordem aos muros. O povo de Valdoria já olhava com esperança para o jovem construtor.", null);
        q("Portões de Ferro", HAVE, "minecraft:iron_ingot", 16, "O ferro forjou portões e dobradiças. O castelo, enfim, respirava.", null);
        q("Luz nas Muralhas", HAVE, "minecraft:torch", 32, "Tochas acesas ao longo dos muros afastaram as sombras da primeira noite de Valdoria.", null);
        q("A Profecia", KILL, "minecraft:zombie", 10, "Aldric revelou a profecia: 'Um ser de trevas, seu espelho, virá. Malachar, o Enzo Demoníaco.' Enzo empunhou a espada e enfrentou os primeiros mortos.", null);
        q("O Juramento", KILL, "minecraft:spider", 10, "A profecia está completa. Enzo jurou proteger Valdoria. O Ato I termina, e a hora de escolher um lado se aproxima.", essence());

        // ===== ATO II - A SOMBRA SE APROXIMA (11-20) =====
        q("Luz ou Trevas", FACTION, "", 1, "Anjo ou Demônio. A escolha moldou a alma de Enzo e mudou a cor do vento sobre Valdoria.", null);
        q("As Torres", HAVE, "minecraft:iron_ingot", 32, "O castelo ganhou torres. Do alto, Enzo viu fumaça no horizonte: a sombra se aproximava.", null);
        q("A Primeira Invasão", KILL, "minecraft:zombie", 30, "Hordas de mortos cercaram os muros ao anoitecer. Enzo resistiu até o amanhecer.", null);
        q("Arqueiros de Osso", KILL, "minecraft:skeleton", 20, "Flechas cruzaram o céu escuro. Os esqueletos de Malachar testavam as defesas de Valdoria.", null);
        q("Explosões na Noite", KILL, "minecraft:creeper", 10, "Criaturas verdes rastejaram até as muralhas. Cada estrondo era um aviso do inimigo.", null);
        q("Recursos Raros", HAVE, "minecraft:diamond", 5, "Nas profundezas, Enzo encontrou diamantes. 'Isto forjará nossa esperança', disse Aldric.", null);
        q("O Ouro do Reino", HAVE, "minecraft:gold_ingot", 32, "O ouro adornou as torres e pagou os artesãos. Valdoria prosperava, apesar do medo.", null);
        q("Esmeraldas da Paz", HAVE, "minecraft:emerald", 10, "Aldeões trouxeram esmeraldas em troca de proteção. A aliança entre os povos se fortalecia.", null);
        q("Teias nas Sombras", KILL, "minecraft:spider", 25, "As aranhas tomaram a floresta ao redor. Enzo abriu caminho com fogo e aço.", null);
        q("O Coração das Torres", HAVE, "minecraft:diamond", 10, "As torres brilharam com diamantes. O Ato II termina, mas o céu já começava a avermelhar.", essence());

        // ===== ATO III - O DESPERTAR DO NETHER (21-30) =====
        q("O Céu Vermelho", HAVE, "minecraft:obsidian", 10, "O céu de Valdoria sangrou em vermelho. Malachar despertou o Nether. Enzo reuniu obsidiana para abrir o portal.", null);
        q("O Portal", DIM, "minecraft:the_nether", 1, "Enzo atravessou o portal. O calor queimou seus pulmões, e o Nether o encarou de volta.", null);
        q("Hastes de Blaze", HAVE, "minecraft:blaze_rod", 8, "Os Blazes guardavam a fortaleza em chamas. Enzo tomou suas hastes e seguiu adiante.", null);
        q("Os Piglins", KILL, "minecraft:piglin", 10, "Piglins de ouro e fúria bloquearam a trilha. Malachar os havia comprado com promessas.", null);
        q("Ouro Maldito", HAVE, "minecraft:gold_ingot", 64, "Enzo juntou ouro suficiente para a sala do trono, mas o metal parecia sussurrar o nome do inimigo.", null);
        q("Quartzo Branco", HAVE, "minecraft:quartz", 64, "O quartzo do Nether iluminou os corredores do castelo como pequenas estrelas.", null);
        q("Esqueletos Negros", KILL, "minecraft:wither_skeleton", 5, "Na fortaleza, Enzo enfrentou os guardas sombrios de Malachar e saiu vivo por pouco.", null);
        q("A Sala do Trono", HAVE, "minecraft:polished_blackstone_bricks", 64, "Pedra negra polida revestiu a sala do trono. Aldric sorriu: 'Agora Valdoria tem um coração.'", null);
        q("O Trono de Ouro", HAVE, "minecraft:gold_block", 9, "O trono foi forjado em ouro puro. Enzo sentou-se nele e sentiu o peso de ser o Escolhido.", null);
        q("Hordas de Malachar", KILL, "minecraft:zombified_piglin", 15, "Malachar enviou hordas do Nether contra o castelo. Enzo as derrotou e recebeu a Chave da Masmorra.", essenceKey());

        // ===== ATO IV - A JORNADA AO END (31-40) =====
        q("Pérolas do Fim", HAVE, "minecraft:ender_pearl", 12, "Aldric falou do End: 'Lá repousam os artefatos que podem deter Malachar.' Enzo partiu atrás de pérolas.", null);
        q("Olhos do Fim", HAVE, "minecraft:ender_eye", 12, "Com os Olhos de Ender, Enzo encontrou o caminho para a fortaleza escondida sob o mundo.", null);
        q("O Fim", DIM, "minecraft:the_end", 1, "O portal se abriu. Ilhas flutuantes, silêncio e um dragão adormecido esperavam por Enzo.", null);
        q("Os Altos", KILL, "minecraft:enderman", 15, "Os Endermans o observaram em silêncio. Cada um que caiu levou um eco do plano de Malachar.", null);
        q("Fruto do Coro", HAVE, "minecraft:chorus_fruit", 8, "O fruto do coro o levou entre ilhas distantes. Enzo aprendeu a confiar no salto no escuro.", null);
        q("Pedra do Fim", HAVE, "minecraft:end_stone", 64, "Pedra do End foi levada a Valdoria para selar os subterrâneos do castelo.", null);
        q("Púrpura Real", HAVE, "minecraft:purpur_block", 32, "As torres ganharam detalhes em púrpura, cor dos que enfrentam o abismo sem recuar.", null);
        q("Estrela do Nether", HAVE, "minecraft:nether_star", 1, "A Estrela do Nether brilhou nas mãos de Enzo. Com ela, o castelo teria seu farol.", null);
        q("O Farol de Valdoria", HAVE, "minecraft:beacon", 1, "No topo do castelo, o Farol acendeu. Sua luz atravessou o céu vermelho e chegou até os mais distantes.", null);
        q("Preparação para a Guerra", HAVE, "minecraft:diamond", 32, "A guerra final se aproximava. Enzo forjou, treinou e recebeu uma segunda Chave da Masmorra.", essenceKey());

        // ===== ATO V - A BATALHA FINAL (41-50) =====
        q("Maçãs Douradas", HAVE, "minecraft:golden_apple", 8, "Aldric entregou a Espada Definitiva de Valdoria: 'Ela será sua voz quando as palavras acabarem.'",
                p -> QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_SWORD.get())));
        q("O Dragão do End", KILL, "minecraft:ender_dragon", 1, "O Dragão do End caiu. O céu do Fim se calou e Enzo viu, ao longe, o brilho vermelho de Valdoria.", null);
        q("O Retorno", DIM, "minecraft:overworld", 1, "Enzo voltou a Valdoria. O reino o recebeu em silêncio, sabendo que a hora final havia chegado.", null);
        q("Essências do Guardião", HAVE, "valdorianrpg:guardian_essence", 3, "As Essências dos Guardiões vibraram em harmonia. Aldric disse que elas eram o último segredo do reino.", null);
        q("Totem da Esperança", HAVE, "minecraft:totem_of_undying", 1, "O totem repousou no peito de Enzo. Ao fundo, um forjador deixou a Armadura Definitiva diante dele.",
                p -> {
                    QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_HELMET.get()));
                    QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_CHESTPLATE.get()));
                    QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_LEGGINGS.get()));
                    QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_BOOTS.get()));
                });
        q("A Espada Pronta", HAVE, "valdorianrpg:ultimate_sword", 1, "Com a espada em mãos, Enzo sentiu o peso da profecia. Não havia mais volta.", null);
        q("A Armadura Pronta", HAVE, "valdorianrpg:ultimate_chestplate", 1, "A armadura envolveu Enzo como uma segunda pele. Ele olhou no espelho e viu um herói.", null);
        q("A Chave Final", HAVE, "valdorianrpg:dungeon_key", 1, "A Chave da Masmorra girou. Das sombras abaixo do castelo ergueu-se Malachar, o Enzo Demoníaco.",
                p -> MalacharEntity.spawnNear(p));
        q("Enzo contra Malachar", FLAG, "malachar_dead", 1, "Dois Enzos, uma Valdoria. Aço contra fogo, Luz contra Trevas. Quando o último golpe caiu, só um deles continuou de pé.", null);
        q("Epílogo: A Saga do Enzo", DIM, "minecraft:overworld", 1, "O céu de Valdoria voltou ao azul. O Rei Aldric inclinou a cabeça: 'A lenda de Enzo, o Escolhido, será contada para sempre.' FIM.", null);
    }

    private QuestData() {}

    public static int size() { return Q.size(); }
    public static Quest get(int id) { return Q.get(id - 1); }
    public static List<Quest> all() { return Q; }
}
