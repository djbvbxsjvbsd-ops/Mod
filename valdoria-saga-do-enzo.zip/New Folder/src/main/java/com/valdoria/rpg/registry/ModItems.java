package com.valdoria.rpg.registry;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.item.ValdoriaSword;
import com.valdoria.rpg.network.ModNetwork;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(Registries.ITEM, ValdoriaMod.MODID);

    public static final RegistryObject<Item> FOUNDATION_STONE = ITEMS.register("foundation_stone",
            () -> new Item(new Item.Properties().stacksTo(1).rarity(Rarity.RARE)) {
                @Override
                public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
                    if (!level.isClientSide) {
                        player.sendSystemMessage(Component.literal("§bA Pedra de Fundação pulsa... Valdoria desperta sob seus pés."));
                        player.playSound(SoundEvents.BEACON_ACTIVATE, 1.0F, 1.0F);
                    }
                    return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
                }
            });

    public static final RegistryObject<Item> DUNGEON_KEY = ITEMS.register("dungeon_key",
            () -> new Item(new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> GUARDIAN_ESSENCE = ITEMS.register("guardian_essence",
            () -> new Item(new Item.Properties().stacksTo(16).rarity(Rarity.EPIC)) {
                @Override
                public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
                    ItemStack st = player.getItemInHand(hand);
                    if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.pass(st);
                    if (!level.isClientSide && player instanceof ServerPlayer sp) {
                        PlayerData.addMana(sp, 50.0F);
                        sp.playSound(SoundEvents.AMETHYST_BLOCK_CHIME, 1.0F, 1.0F);
                        sp.getCooldowns().addCooldown(this, 600);
                        ModNetwork.sync(sp);
                    }
                    return InteractionResultHolder.sidedSuccess(st, level.isClientSide);
                }
            });

    public static final RegistryObject<Item> ULTIMATE_SWORD = ITEMS.register("ultimate_sword",
            () -> new ValdoriaSword(Tiers.NETHERITE, 6, -2.4F, new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> ULTIMATE_HELMET = ITEMS.register("ultimate_helmet",
            () -> new ArmorItem(ModArmorMaterial.VALDORIA, ArmorItem.Type.HELMET, new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> ULTIMATE_CHESTPLATE = ITEMS.register("ultimate_chestplate",
            () -> new ArmorItem(ModArmorMaterial.VALDORIA, ArmorItem.Type.CHESTPLATE, new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> ULTIMATE_LEGGINGS = ITEMS.register("ultimate_leggings",
            () -> new ArmorItem(ModArmorMaterial.VALDORIA, ArmorItem.Type.LEGGINGS, new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> ULTIMATE_BOOTS = ITEMS.register("ultimate_boots",
            () -> new ArmorItem(ModArmorMaterial.VALDORIA, ArmorItem.Type.BOOTS, new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
}
