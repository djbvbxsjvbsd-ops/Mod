package com.valdoria.rpg.event;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.network.OpenFactionPacket;
import com.valdoria.rpg.quest.QuestManager;
import com.valdoria.rpg.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID)
public class ServerEvents {

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (!PlayerData.hasFlag(sp, "starter")) {
            PlayerData.setFlag(sp, "starter");
            PlayerData.setMana(sp, PlayerData.MAX_MANA);
            QuestManager.give(sp, new ItemStack(ModItems.FOUNDATION_STONE.get()));
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    "§6Bem-vindo a Valdoria, Enzo. Use /valdoria quest para ver sua missão. P = Perfil, M = Mapa, H = HUD."));
        }
        ModNetwork.sync(sp);
        if (PlayerData.getCompleted(sp) >= 10 && PlayerData.getFaction(sp) == 0) {
            ModNetwork.sendTo(sp, new OpenFactionPacket());
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        CompoundTag old = e.getOriginal().getPersistentData();
        if (old.contains(Player.PERSISTED_NBT_TAG, 10)) {
            e.getEntity().getPersistentData().put(Player.PERSISTED_NBT_TAG, old.getCompound(Player.PERSISTED_NBT_TAG).copy());
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ModNetwork.sync(sp);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer sp)) return;

        if (sp.tickCount % 20 == 0) {
            PlayerData.addMana(sp, PlayerData.getFaction(sp) == 1 ? 3.0F : 2.0F);
            QuestManager.tick(sp);
            ModNetwork.sync(sp);
        }
        if (sp.tickCount % 1200 == 600) horde(sp);
    }

    /** Hordas de Malachar: invasões a partir do Ato II. */
    private static void horde(ServerPlayer sp) {
        int done = PlayerData.getCompleted(sp);
        if (done < 11 || done >= 49) return;
        ServerLevel lvl = sp.serverLevel();
        int n = 2 + done / 10;
        for (int i = 0; i < n; i++) {
            double x = sp.getX() + (lvl.random.nextDouble() - 0.5D) * 24.0D;
            double z = sp.getZ() + (lvl.random.nextDouble() - 0.5D) * 24.0D;
            Mob mob;
            if (lvl.dimension() == Level.NETHER && done >= 20) {
                Piglin pg = EntityType.PIGLIN.create(lvl);
                if (pg == null) continue;
                pg.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_SWORD));
                mob = pg;
            } else if (i % 2 == 0) {
                mob = EntityType.ZOMBIE.create(lvl);
            } else {
                mob = EntityType.SKELETON.create(lvl);
            }
            if (mob == null) continue;
            mob.moveTo(x, sp.getY(), z, lvl.random.nextFloat() * 360.0F, 0.0F);
            if (!lvl.noCollision(mob)) continue;
            mob.setTarget(sp);
            lvl.addFreshEntity(mob);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer sp) {
            ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(e.getEntity().getType());
            if (key != null) PlayerData.addKill(sp, key.toString());
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer sp && PlayerData.getFaction(sp) == 2) {
            e.setAmount(e.getAmount() * 1.15F);
        }
    }
}
