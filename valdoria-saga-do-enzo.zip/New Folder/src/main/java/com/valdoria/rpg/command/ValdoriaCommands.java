package com.valdoria.rpg.command;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.entity.MalacharEntity;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.quest.Quest;
import com.valdoria.rpg.quest.QuestData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID)
public class ValdoriaCommands {

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("valdoria")
                .then(Commands.literal("quest").executes(ctx -> quest(ctx.getSource())))
                .then(Commands.literal("setquest").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("n", IntegerArgumentType.integer(0, 50))
                                .executes(ctx -> setQuest(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "n")))))
                .then(Commands.literal("boss").requires(s -> s.hasPermission(2)).executes(ctx -> boss(ctx.getSource())))
                .then(Commands.literal("dumpboss").requires(s -> s.hasPermission(2)).executes(ctx -> dumpBoss(ctx.getSource()))));
    }

    private static int quest(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        int done = PlayerData.getCompleted(p);
        if (done >= QuestData.size()) {
            src.sendSuccess(() -> Component.literal("§6A Saga do Enzo está completa!"), false);
            return 1;
        }
        Quest q = QuestData.get(done + 1);
        src.sendSuccess(() -> Component.literal("§e" + QuestData.ACT_NAMES[q.act() - 1]
                + "\n§fMissão " + q.id() + "/50: " + q.title() + "\n§7" + q.objective()), false);
        return 1;
    }

    private static int setQuest(CommandSourceStack src, int n) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerData.setCompleted(p, n);
        ModNetwork.sync(p);
        src.sendSuccess(() -> Component.literal("Missões concluídas = " + n), true);
        return 1;
    }

    private static int boss(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        MalacharEntity.spawnNear(p);
        return 1;
    }

    private static int dumpBoss(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        List<MalacharEntity> list = p.serverLevel().getEntitiesOfClass(MalacharEntity.class, p.getBoundingBox().inflate(100.0D));
        if (list.isEmpty()) {
            src.sendSuccess(() -> Component.literal("Nenhum Malachar por perto."), false);
            return 0;
        }
        CompoundTag tag = new CompoundTag();
        list.get(0).save(tag);
        float hp = tag.getFloat("Health");
        int phase = tag.getInt("MalacharPhase");
        src.sendSuccess(() -> Component.literal("Malachar: HP " + hp + " | fase " + phase), false);
        return 1;
    }
}
