package com.valdoria.rpg.network;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ValdoriaMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private static int id = 0;

    private ModNetwork() {}

    public static void register() {
        INSTANCE.messageBuilder(SyncDataPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncDataPacket::encode).decoder(SyncDataPacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();

        INSTANCE.messageBuilder(OpenFactionPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenFactionPacket::encode).decoder(OpenFactionPacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();

        INSTANCE.messageBuilder(FactionChoicePacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(FactionChoicePacket::encode).decoder(FactionChoicePacket::decode)
                .consumerMainThread((msg, ctx) -> msg.handle(ctx.get())).add();
    }

    public static void sync(ServerPlayer p) {
        sendTo(p, new SyncDataPacket(PlayerData.getFaction(p), PlayerData.getCompleted(p),
                PlayerData.getMana(p), PlayerData.MAX_MANA));
    }

    public static void sendTo(ServerPlayer p, Object msg) {
        INSTANCE.send(PacketDistributor.PLAYER.with(() -> p), msg);
    }
}
