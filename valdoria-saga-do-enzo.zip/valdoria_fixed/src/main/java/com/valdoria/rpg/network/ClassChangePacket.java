package com.valdoria.rpg.network;

import com.valdoria.rpg.data.PlayerData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/** Enviado pelo cliente quando o jogador escolhe/troca de classe. */
public class ClassChangePacket {
    public final int newClass;
    public ClassChangePacket(int newClass) { this.newClass = newClass; }

    public static void encode(ClassChangePacket p, FriendlyByteBuf buf) { buf.writeInt(p.newClass); }
    public static ClassChangePacket decode(FriendlyByteBuf buf) { return new ClassChangePacket(buf.readInt()); }

    public static void handle(ClassChangePacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;

            int changes = PlayerData.getClassChanges(sp);
            int currentClass = PlayerData.getPlayerClass(sp);
            boolean isFirst = currentClass == PlayerData.CLASS_NONE;

            // Máximo de 2 trocas após a escolha inicial
            if (!isFirst && changes >= 2) {
                sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§c✖ Você já usou todas as suas trocas de classe!"));
                return;
            }
            if (pkt.newClass < 1 || pkt.newClass > 4) return;

            // Missão 70 desbloqueada para Rei do Gelo
            if (pkt.newClass == PlayerData.CLASS_REI_GELO && PlayerData.getCompleted(sp) < 69) {
                sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§c❄ A classe Rei Secreto do Gelo só está disponível após a Quest 70!"));
                return;
            }

            PlayerData.setPlayerClass(sp, pkt.newClass);
            if (!isFirst) PlayerData.addClassChange(sp);

            String name = PlayerData.getClassName(sp);
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    "§b⚔ Classe alterada para: §f§l" + name + (isFirst ? "" : " §7(troca " + PlayerData.getClassChanges(sp) + "/2)")));

            if (pkt.newClass == PlayerData.CLASS_REI_GELO) {
                sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§b❄ Você sente o frio de Nivéria ceder... Debuffs reduzidos em 40%. Poder Redemoinho desbloqueado!"));
            }
            ModNetwork.sync(sp);
        });
        ctx.get().setPacketHandled(true);
    }
}
