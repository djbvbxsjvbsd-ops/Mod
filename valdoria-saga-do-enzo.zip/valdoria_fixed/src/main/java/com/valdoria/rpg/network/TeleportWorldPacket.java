package com.valdoria.rpg.network;

import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Packet enviado pelo cliente ao clicar em um mundo no WorldHubScreen.
 *   index 0 → Overworld (Valdoria)
 *   index 1 → Nivéria (dimensão de gelo)
 */
public class TeleportWorldPacket {
    public final int worldIndex;

    public TeleportWorldPacket(int worldIndex) { this.worldIndex = worldIndex; }

    public static void encode(TeleportWorldPacket p, FriendlyByteBuf buf) { buf.writeInt(p.worldIndex); }
    public static TeleportWorldPacket decode(FriendlyByteBuf buf) { return new TeleportWorldPacket(buf.readInt()); }

    public static void handle(TeleportWorldPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;

            ResourceKey<Level> target = switch (pkt.worldIndex) {
                case 1  -> NiveriaDimension.NIVERIA;
                default -> Level.OVERWORLD;
            };

            ServerLevel dest = sp.getServer().getLevel(target);
            if (dest == null) {
                sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§cEste mundo ainda não está disponível."));
                return;
            }

            if (sp.level().dimension().equals(target)) {
                sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§7Você já está neste mundo!"));
                return;
            }

            // Validação para Nivéria: nível 60+
            if (target.equals(NiveriaDimension.NIVERIA)) {
                int lvl = com.valdoria.rpg.data.PlayerData.getLevel(sp);
                if (lvl < 60) {
                    sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                            "§c❄ Você precisa estar no Nível 60 para acessar Nivéria!"));
                    return;
                }
            }

            // Teleportar para o spawn da dimensão destino
            net.minecraft.core.BlockPos spawnPos = dest.getSharedSpawnPos();
            sp.teleportTo(dest,
                    spawnPos.getX() + 0.5, spawnPos.getY() + 1.0, spawnPos.getZ() + 0.5,
                    sp.getYRot(), sp.getXRot());
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    "§b✦ Bem-vindo a " + (pkt.worldIndex == 1 ? "Nivéria" : "Valdoria") + "!"));
        });
        ctx.get().setPacketHandled(true);
    }
}
