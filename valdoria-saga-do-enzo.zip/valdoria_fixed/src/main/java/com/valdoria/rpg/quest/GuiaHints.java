package com.valdoria.rpg.quest;

import com.valdoria.rpg.data.PlayerData;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.Map;
import java.util.Set;

/** Textos e ajuda do Aldric (guia). */
public final class GuiaHints {
    private GuiaHints() {}

    private static final Map<String, String> WHERE = Map.ofEntries(
            Map.entry("minecraft:oak_log", "Corte árvores de carvalho."),
            Map.entry("minecraft:cobblestone", "Minere pedra com uma picareta."),
            Map.entry("minecraft:iron_ingot", "Funda minério de ferro na fornalha; ele fica abaixo de Y=60."),
            Map.entry("minecraft:diamond", "Diamantes ficam fundos, perto de Y=-58, com picareta de ferro."),
            Map.entry("minecraft:gold_ingot", "Funda minério de ouro; no Nether há de sobra."),
            Map.entry("minecraft:emerald", "Esmeraldas em montanhas, ou troque com aldeões."),
            Map.entry("minecraft:obsidian", "Água sobre lava parada vira obsidiana; precisa de picareta de diamante."),
            Map.entry("minecraft:blaze_rod", "Blazes ficam na Fortaleza do Nether."),
            Map.entry("minecraft:quartz", "Minério de quartzo no Nether."),
            Map.entry("minecraft:ender_pearl", "Endermen soltam pérolas; aparecem mais à noite."),
            Map.entry("minecraft:ender_eye", "Pérola do Fim + pó de Blaze."),
            Map.entry("minecraft:nether_star", "Só o Wither solta: 3 caveiras de wither + areia de almas."),
            Map.entry("minecraft:beacon", "Estrela do Nether + 5 vidros + 3 obsidianas."),
            Map.entry("minecraft:totem_of_undying", "Evocadores de mansões e invasões soltam totens."),
            Map.entry("minecraft:snow_block", "Craft com 4 bolas de neve."),
            Map.entry("minecraft:ice", "Quebre gelo com uma ferramenta de Toque Suave."),
            Map.entry("minecraft:spruce_log", "Troncos de pinheiro: taigas, ou cultive."),
            Map.entry("minecraft:bread", "3 trigos em fileira."),
            Map.entry("minecraft:furnace", "8 pedras lapidadas em volta."),
            Map.entry("minecraft:ender_dragon", "O Dragão está no End; quebre os cristais primeiro."),
            Map.entry("minecraft:wither_skeleton", "Fortaleza do Nether."),
            Map.entry("minecraft:enderman", "Aparecem à noite; não olhe nos olhos deles."),
            Map.entry("minecraft:spider", "Aparecem à noite."),
            Map.entry("minecraft:zombie", "Aparecem à noite."));

    /** Itens que o guia nunca entrega. */
    private static final Set<String> NO_AID = Set.of("minecraft:nether_star", "minecraft:beacon",
            "minecraft:totem_of_undying", "minecraft:golden_apple", "minecraft:gold_block", "minecraft:ender_eye");

    public static String describe(ServerPlayer p, Quest q) {
        return switch (q.type()) {
            case HAVE -> "Junte " + q.amount() + "x " + QuestFlags.friendlyItem(q.target())
                    + " (" + QuestManager.count(p, q.target()) + "/" + q.amount() + ").";
            case KILL -> "Derrote " + q.amount() + "x " + QuestFlags.friendlyEntity(q.target())
                    + " (" + PlayerData.getKills(p, q.target()) + "/" + q.amount() + ").";
            case FLAG -> QuestFlags.friendlyFlag(q.target()) + ".";
            case DIM -> "Vá para " + QuestFlags.friendlyDim(q.target()) + ".";
            case FACTION -> "Escolha Luz ou Trevas.";
        };
    }

    public static String questLine(ServerPlayer p) {
        int qid = PlayerData.getCompleted(p) + 1;
        if (qid > QuestData.size()) return "A Saga está completa, Escolhido!";
        Quest q = QuestData.get(qid);
        String hint = WHERE.get(q.target());
        return "Missão " + qid + " — " + q.title() + ". " + describe(p, q) + (hint != null ? " " + hint : "");
    }

    public static String dir(double dx, double dz) {
        String[] n = {"leste", "sudeste", "sul", "sudoeste", "oeste", "noroeste", "norte", "nordeste"};
        double ang = Math.toDegrees(Math.atan2(dz, dx));   // +x = leste, +z = sul
        int i = (int) Math.round(((ang % 360) + 360) % 360 / 45.0) % 8;
        return n[i];
    }

    /** Ajuda ao clicar no Aldric: objetivo, direção do alvo e, às vezes, material. */
    public static String aid(ServerPlayer p) {
        StringBuilder sb = new StringBuilder(questLine(p));
        EspTracker.Result r = EspTracker.compute(p);
        if (!r.pts().isEmpty()) {
            float[] t = r.pts().get(0);
            double dx = t[0] - p.getX(), dz = t[2] - p.getZ();
            sb.append(" Alvo a ").append((int) Math.sqrt(dx * dx + dz * dz)).append("m (").append(dir(dx, dz)).append(").");
        }
        int qid = PlayerData.getCompleted(p) + 1;
        if (qid <= QuestData.size()) {
            Quest q = QuestData.get(qid);
            if (q.type() == Quest.Type.HAVE && q.target().startsWith("minecraft:") && !NO_AID.contains(q.target())) {
                int missing = q.amount() - QuestManager.count(p, q.target());
                long now = p.serverLevel().getGameTime();
                long next = PlayerData.root(p).getLong("guia_aid");
                Item it = BuiltInRegistries.ITEM.getOptional(ResourceLocation.tryParse(q.target())).orElse(null);
                if (missing > 0 && it != null) {
                    if (now >= next) {
                        int n = Math.min(16, Math.max(1, missing / 4));
                        QuestManager.give(p, new ItemStack(it, n));
                        PlayerData.root(p).putLong("guia_aid", now + 12000L);
                        sb.append(" Tome ").append(n).append("x para ajudar!");
                    } else {
                        sb.append(" Posso ajudar com material de novo em ").append((next - now) / 20).append("s.");
                    }
                }
            }
        }
        return sb.toString();
    }
}
