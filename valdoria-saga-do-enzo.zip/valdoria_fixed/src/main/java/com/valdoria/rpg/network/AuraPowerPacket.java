package com.valdoria.rpg.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/**
 * Enviado pelo cliente (tecla T após transformação) → servidor
 * para ativar o poder único da aura atual.
 */
public class AuraPowerPacket {
    public AuraPowerPacket() {}
    public static void encode(AuraPowerPacket p, FriendlyByteBuf buf) {}
    public static AuraPowerPacket decode(FriendlyByteBuf buf) { return new AuraPowerPacket(); }

    public static void handle(AuraPowerPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            net.minecraft.server.level.ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            com.valdoria.rpg.event.AuraPowerHandler.activate(sp);
        });
        ctx.get().setPacketHandled(true);
    }
}
