// [WorldHubScreen.java] — Lobby de seleção de mundos com ícones dos itens do mod
package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.registry.ModItems;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

/**
 * Tela de lobby/hub de mundos — abre via tecla B (configurável) ou packet ao logar.
 * Mostra os mundos disponíveis com ícones dos próprios itens/blocos do mod.
 */
public class WorldHubScreen extends Screen {

    // ── Dimensões do card ────────────────────────────────────────────────────
    private static final int CARD_W = 130;
    private static final int CARD_H = 180;
    private static final int GAP    = 16;
    private static final int COLS   = 2;
    private static final int TOTAL_W = COLS * CARD_W + (COLS - 1) * GAP;

    // ── Mundos / dimensões disponíveis ───────────────────────────────────────
    //   index 0 = Overworld (Valdoria), index 1 = Nivéria
    private static final String[] WORLD_NAMES = {
            "Valdoria",
            "Nivéria"
    };
    private static final String[] WORLD_SUBS = {
            "Reino dos Homens",
            "Dimensão do Gelo Eterno"
    };
    private static final String[][] WORLD_DESCS = {
            {
                "Construa o seu castelo,",
                "complete missões,",
                "enfrente criaturas e",
                "domine o reino."
            },
            {
                "Dimensão congelada,",
                "cheia de perigos.",
                "Requer Nv 60 e a",
                "Chave Glacial."
            }
    };
    private static final int[] WORLD_COLORS    = { 0xFF2255AA, 0xFF44BBDD };
    private static final int[] WORLD_COLORS_HL = { 0xFF4499FF, 0xFF88EEFF };

    // Ícones: um item principal + dois secundários por mundo
    // Overworld: Espada Glacial principal + Fundação + Chave Real
    // Nivéria:   Cristal Glacial principal + Portal Nivéria + Coroa
    private ItemStack[] mainIcons;
    private ItemStack[][] subIcons;

    public WorldHubScreen() {
        super(Component.literal("Hub de Mundos"));
    }

    @Override
    protected void init() {
        super.init();
        // Instanciamos as ItemStacks aqui para garantir que o registro já resolveu
        mainIcons = new ItemStack[] {
                new ItemStack(ModItems.ESPADA_GLACIAL.get()),
                new ItemStack(ModItems.CRISTAL_GLACIAL.get())
        };
        subIcons = new ItemStack[][] {
                {
                    new ItemStack(ModItems.FOUNDATION_STONE.get()),
                    new ItemStack(ModItems.CHAVE_REAL.get())
                },
                {
                    new ItemStack(ModItems.PORTAL_NIVERIA.get()),
                    new ItemStack(ModItems.COROA_NIVERIA.get())
                }
        };
    }

    // ── Layout helpers ───────────────────────────────────────────────────────
    private int startX() { return width  / 2 - TOTAL_W / 2; }
    private int startY() { return height / 2 - CARD_H  / 2 - 30; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        // Fundo escurecido (já vem do renderBackground, mas reforçamos)
        renderBackground(g);

        int sx = startX(), sy = startY();
        int panW = TOTAL_W + 24, panH = CARD_H + 72;
        int panX = width / 2 - panW / 2, panY = sy - 36;

        // ── Painel principal ─────────────────────────────────────────────────
        g.fillGradient(panX, panY, panX + panW, panY + panH, 0xF4030A18, 0xF4010508);
        g.renderOutline(panX, panY, panW, panH, 0xFF0066AA);
        // Scanlines decorativas
        for (int i = 4; i < panH; i += 6)
            g.fill(panX, panY + i, panX + panW, panY + i + 1, 0x07FFFFFF);

        // ── Header ───────────────────────────────────────────────────────────
        int hdrH = 28;
        g.fill(panX, panY, panX + panW, panY + hdrH, 0xFF020C1A);
        g.fill(panX, panY + hdrH, panX + panW, panY + hdrH + 1, 0xFF0088CC);
        g.drawCenteredString(font, "§b✦ VALDORIA — PORTAL DE MUNDOS ✦", width / 2, panY + 6,  0xFF00DFFF);
        g.drawCenteredString(font, "§7Escolha seu destino, aventureiro",  width / 2, panY + 17, 0xFF5599BB);

        // ── Nível do jogador (canto superior direito do painel) ──────────────
        String lvlStr = "§7Missões §f" + ClientData.completed + "§7/101";
        g.drawString(font, lvlStr, panX + panW - font.width(lvlStr) - 8, panY + 6, 0xFFBBCCDD);

        // ── Cards ─────────────────────────────────────────────────────────────
        for (int i = 0; i < COLS; i++) {
            int cx = sx + i * (CARD_W + GAP);
            boolean hovered = mx >= cx && mx <= cx + CARD_W && my >= sy && my <= sy + CARD_H;
            drawCard(g, cx, sy, i, hovered, mx, my);
        }

        // ── Footer ───────────────────────────────────────────────────────────
        int fy = sy + CARD_H + 8;
        g.fill(panX, fy, panX + panW, fy + 1, 0xFF0066AA);
        g.fill(panX, fy + 1, panX + panW, fy + panH - CARD_H - 37, 0xFF010810);
        g.drawCenteredString(font, "§7Clique no mundo ou pressione  §b[1]§7 Valdoria  §3[2]§7 Nivéria",
                width / 2, fy + 7, 0xFF334455);
        g.drawCenteredString(font, "§7[ESC] Fechar", width / 2, fy + 18, 0xFF334455);

        super.render(g, mx, my, pt);
    }

    private void drawCard(GuiGraphics g, int x, int y, int idx,
                          boolean hovered, int mx, int my) {
        int color   = WORLD_COLORS[idx];
        int colorHL = WORLD_COLORS_HL[idx];
        int border  = hovered ? colorHL : color;
        int bgTop   = hovered ? 0xFF091828 : 0xFF050F1E;
        int bgBot   = 0xFF020609;

        // Fundo
        g.fillGradient(x, y, x + CARD_W, y + CARD_H, bgTop, bgBot);
        // Borda
        g.renderOutline(x, y, CARD_W, CARD_H, border);
        if (hovered) g.renderOutline(x + 2, y + 2, CARD_W - 4, CARD_H - 4, 0x44FFFFFF & border);
        // Glow topo
        g.fillGradient(x, y, x + CARD_W, y + 32, (0x99 << 24) | (border & 0x00FFFFFF), 0x00000000);

        // ── Ícone principal (item do mod, 32×32) ─────────────────────────────
        int iconX = x + CARD_W / 2 - 16;
        int iconY = y + 14;
        if (mainIcons != null && mainIcons[idx] != null) {
            // GuiGraphics.renderItem() renderiza no tamanho 16×16, escalonamos via pose
            g.pose().pushPose();
            g.pose().translate(iconX, iconY, 100);
            g.pose().scale(2.0F, 2.0F, 1.0F);
            g.renderItem(mainIcons[idx], 0, 0);
            g.pose().popPose();
        }

        // ── Nome do mundo ─────────────────────────────────────────────────────
        g.drawCenteredString(font, "§l" + WORLD_NAMES[idx], x + CARD_W / 2, y + 50, hovered ? colorHL : 0xFFE8F4FF);
        g.drawCenteredString(font, "§o§7" + WORLD_SUBS[idx], x + CARD_W / 2, y + 61, 0xFF8899AA);

        // Separador
        g.fill(x + 10, y + 72, x + CARD_W - 10, y + 73, border);

        // ── Descrição ─────────────────────────────────────────────────────────
        for (int l = 0; l < WORLD_DESCS[idx].length; l++)
            g.drawCenteredString(font, "§7" + WORLD_DESCS[idx][l],
                    x + CARD_W / 2, y + 78 + l * 10, 0xFFAABBCC);

        // ── Ícones secundários (mini, 16×16) ─────────────────────────────────
        int sub1X = x + CARD_W / 2 - 20;
        int sub2X = x + CARD_W / 2 + 4;
        int subY  = y + CARD_H - 38;
        if (subIcons != null && subIcons[idx] != null) {
            g.renderItem(subIcons[idx][0], sub1X, subY);
            g.renderItem(subIcons[idx][1], sub2X, subY);
        }

        // ── CTA hover / hotkey ────────────────────────────────────────────────
        if (hovered) {
            g.fill(x + 8, y + CARD_H - 18, x + CARD_W - 8, y + CARD_H - 4, 0x66FFFFFF & border);
            String cta = idx == 0 ? "§b→ ENTRAR EM VALDORIA" : "§3→ ENTRAR EM NIVÉRIA";
            g.drawCenteredString(font, cta, x + CARD_W / 2, y + CARD_H - 15, hovered ? colorHL : 0xFFFFFFFF);
        } else {
            g.drawCenteredString(font, "§8[" + (idx + 1) + "]", x + CARD_W / 2, y + CARD_H - 12, 0xFF446688);
        }
    }

    // ── Input ────────────────────────────────────────────────────────────────
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int sx = startX(), sy = startY();
        for (int i = 0; i < COLS; i++) {
            int cx = sx + i * (CARD_W + GAP);
            if (mx >= cx && mx <= cx + CARD_W && my >= sy && my <= sy + CARD_H) {
                selectWorld(i);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_1) { selectWorld(0); return true; }
        if (key == GLFW.GLFW_KEY_2) { selectWorld(1); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private void selectWorld(int idx) {
        if (minecraft == null || minecraft.player == null) return;
        onClose();
        // Envia o jogador para a dimensão selecionada
        ModNetwork.INSTANCE.sendToServer(
                new com.valdoria.rpg.network.TeleportWorldPacket(idx));
    }

    @Override public boolean isPauseScreen() { return false; }
}
