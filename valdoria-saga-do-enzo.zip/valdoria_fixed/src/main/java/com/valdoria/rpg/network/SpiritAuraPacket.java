package com.valdoria.rpg.network;

import com.valdoria.rpg.data.PlayerData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

/**
 * Enviado pelo cliente (tecla G) → servidor para alternar a Spirit Aura.
 * Lógica:
 *   - Se a aura atual está ativa → desativa.
 *   - Se a aura atual está desativada → ativa.
 *   - Se há um token disponível E o jogador quer avançar de nível → avança e ativa.
 *
 * O campo {@code advance} indica que o jogador quer trocar para o próximo nível
 * (Shift + G); sem Shift apenas liga/desliga o nível atual.
 */
public class SpiritAuraPacket {
    public final boolean advance; // true = Shift+G: avançar para o próximo nível

    public SpiritAuraPacket(boolean advance) { this.advance = advance; }

    public static void encode(SpiritAuraPacket p, FriendlyByteBuf buf) { buf.writeBoolean(p.advance); }
    public static SpiritAuraPacket decode(FriendlyByteBuf buf)         { return new SpiritAuraPacket(buf.readBoolean()); }

    public static void handle(SpiritAuraPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;

            int equipped = PlayerData.getAuraEquipped(sp);
            int maxUnlocked = PlayerData.getAuraLevel(sp);

            if (pkt.advance) {
                // Shift+G: avança para próximo nível se tiver token
                int tokens = PlayerData.getAuraTokens(sp);
                int available = PlayerData.nextAuraLevel(sp); // quanto o progresso de missões permite
                int next = equipped + 1;
                if (next > PlayerData.AURA_MAX) {
                    sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§c✦ Você já possui a Aura Onipotente — nível máximo."));
                    return;
                }
                if (next > available) {
                    int need = next * 15;
                    sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§7✦ Complete " + need + " missões para desbloquear " + PlayerData.getAuraName(next) + "§7."));
                    return;
                }
                if (tokens <= 0) {
                    sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§7✦ Você não tem tokens de aura. Complete mais 15 missões."));
                    return;
                }
                // Consome token, avança nível
                PlayerData.setAuraTokens(sp, tokens - 1);
                PlayerData.setAuraLevel(sp, next);
                PlayerData.setAuraEquipped(sp, next);
                PlayerData.setAuraActive(sp, true);
                sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    "§d✦ Novo nível desbloqueado: " + PlayerData.getAuraName(next)));
                sp.playSound(net.minecraft.sounds.SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 0.8F);
            } else {
                // G simples: liga/desliga aura atual
                if (equipped == PlayerData.AURA_NONE) {
                    // Nenhuma aura equipada → equipa a mais alta desbloqueada
                    if (maxUnlocked == 0) {
                        sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                            "§7✦ Nenhuma aura desbloqueada. Complete 15 missões para ganhar a primeira."));
                        return;
                    }
                    equipped = maxUnlocked;
                    PlayerData.setAuraEquipped(sp, equipped);
                }
                boolean wasActive = PlayerData.isAuraActive(sp);
                PlayerData.setAuraActive(sp, !wasActive);
                if (!wasActive) {
                    sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        PlayerData.getAuraName(equipped) + " §7ativada!"));
                    sp.playSound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, 0.6F, 1.4F);
                } else {
                    sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        PlayerData.getAuraName(equipped) + " §7desativada."));
                }
            }

            ModNetwork.sync(sp);
        });
        ctx.get().setPacketHandled(true);
    }
}
