package com.valdoria.rpg.client;

import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Intercepta a renderização do jogador local e substitui sua skin pela skin do mod.
 *
 * Funciona interceptando RenderPlayerEvent.Pre para redirecionar a textura usada
 * pelo renderer antes do draw call, e restaurando em Post.
 *
 * A skin PNG deve estar em:
 *   src/main/resources/assets/valdorianrpg/textures/skin/enzo_skin.png
 *
 * Em Forge 1.20 não é possível substituir diretamente a ResourceLocation de skin
 * via evento (o PlayerRenderer usa player.getSkinTextureLocation()).
 * A solução mais robusta é registrar o SkinLayer via ModBusEvents.
 * Este handler serve como fallback e documentação da abordagem alternativa.
 *
 * Para ativar a skin custom no spawn, garantimos que ao primeiro login o flag
 * "use_mod_skin" é setado — mas a aplicação real da textura é feita via SkinLayer
 * registrado em ModBusEvents.addPlayerRenderLayer.
 */
@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, value = Dist.CLIENT)
public final class SkinOverrideHandler {
    private SkinOverrideHandler() {}

    public static final ResourceLocation ENZO_SKIN =
            new ResourceLocation(ValdoriaMod.MODID, "textures/skin/enzo_skin.png");

    /**
     * Retorna true se o jogador local deve usar a skin do mod.
     * Critério: o jogador local é o "Enzo" da saga (qualquer player enquanto o mod estiver ativo,
     * já que o mod é single-player/whitelist).
     */
    public static boolean shouldUseSkin() {
        Minecraft mc = Minecraft.getInstance();
        return mc.player != null;
    }
}
