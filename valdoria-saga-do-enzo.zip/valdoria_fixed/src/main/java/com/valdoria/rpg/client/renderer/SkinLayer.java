package com.valdoria.rpg.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/**
 * Layer que substitui a skin do jogador (apenas jogador local) pela skin do mod.
 *
 * A skin PNG deve estar em:
 *   src/main/resources/assets/valdorianrpg/textures/skin/enzo_skin.png
 *
 * Para ativar: registre este layer em ModBusEvents (FMLClientSetupEvent) com:
 *   RenderingRegistry.registerEntityRenderingHandler(EntityType.PLAYER, ctx ->
 *       new PlayerRenderer(ctx, false) { /* add layer *\/ })
 * OU via LivingEntityRenderer#addLayer pelo evento de setup de renderers.
 *
 * A abordagem mais simples em Forge 1.20 é usar RenderPlayerEvent.Pre para
 * substituir a textura antes de renderizar — ver SkinOverrideHandler.
 */
public final class SkinLayer<T extends AbstractClientPlayer, M extends PlayerModel<T>>
        extends RenderLayer<T, M> {

    private static final ResourceLocation ENZO_SKIN =
            new ResourceLocation(ValdoriaMod.MODID, "textures/skin/enzo_skin.png");

    public SkinLayer(RenderLayerParent<T, M> renderer) {
        super(renderer);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                       T player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        // Renderiza a skin do mod por cima da skin vanilla.
        // Usa TRANSLUCENT_NO_CRUMBLING para suportar transparência no canal alpha.
        var vertexConsumer = buffer.getBuffer(RenderType.entityTranslucent(ENZO_SKIN));
        getParentModel().renderToBuffer(poseStack, vertexConsumer, packedLight,
                OverlayTexture.NO_OVERLAY, 1F, 1F, 1F, 1F);
    }
}
