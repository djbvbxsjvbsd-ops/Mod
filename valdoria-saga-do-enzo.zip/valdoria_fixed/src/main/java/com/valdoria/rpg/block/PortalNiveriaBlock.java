package com.valdoria.rpg.block;

import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.levelgen.Heightmap;

public class PortalNiveriaBlock extends Block {

    public PortalNiveriaBlock(Properties props) { super(props); }

    /** Partículas de raio azul-escuro emitidas continuamente pelo portal (lado cliente). */
    @Override
    @net.minecraftforge.api.distmarker.OnlyIn(net.minecraftforge.api.distmarker.Dist.CLIENT)
    public void animateTick(BlockState state, net.minecraft.world.level.Level level,
                            BlockPos pos, net.minecraft.util.RandomSource random) {
        // Raios azul-escuro saindo de dentro do portal em todas as direções
        double cx = pos.getX() + 0.5, cy = pos.getY() + 0.5, cz = pos.getZ() + 0.5;
        // Partículas END_ROD (branco azulado) + SOUL_FIRE_FLAME (azul escuro)
        for (int i = 0; i < 4; i++) {
            double ox = (random.nextDouble() - 0.5) * 1.2;
            double oy2 = (random.nextDouble() - 0.5) * 1.2;
            double oz2 = (random.nextDouble() - 0.5) * 1.2;
            level.addParticle(ParticleTypes.SOUL_FIRE_FLAME, cx + ox, cy + oy2, cz + oz2,
                    ox * 0.1, 0.05 + random.nextDouble() * 0.1, oz2 * 0.1);
            if (i < 2) {
                level.addParticle(ParticleTypes.END_ROD, cx + ox * 0.5, cy + oy2 * 0.5, cz + oz2 * 0.5,
                        ox * 0.05, 0.08, oz2 * 0.05);
            }
        }
        // Raio ocasional (effect visually like a spark)
        if (random.nextInt(10) == 0) {
            level.addParticle(ParticleTypes.ELECTRIC_SPARK, cx, cy, cz,
                    (random.nextDouble() - 0.5) * 0.5,
                    0.2 + random.nextDouble() * 0.3,
                    (random.nextDouble() - 0.5) * 0.5);
        }
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(entity instanceof ServerPlayer sp)) return;
        if (sp.isOnPortalCooldown()) { sp.setPortalCooldown(); return; }

        boolean emNiveria = sp.level().dimension().equals(NiveriaDimension.NIVERIA);

        if (emNiveria) {
            // ===== PORTAL DE VOLTA — Nivéria → Overworld =====
            ServerLevel overworld = sp.getServer().getLevel(Level.OVERWORLD);
            if (overworld == null) return;

            BlockPos owSpawn = overworld.getSharedSpawnPos();
            // Retorna para a frente da sala do portal no castelo (entrada norte da ala)
            // A ala de Nivéria fica em oz-28 (portal) e a passagem em oz-18.
            // Coloca o jogador dentro da ala (oz-25), voltado para sul (yRot=180).
            int owY = overworld.getHeight(
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    owSpawn.getX(), owSpawn.getZ() - 24) + 2;

            sp.teleportTo(overworld,
                    owSpawn.getX() + 0.5D, owY, owSpawn.getZ() - 24 + 0.5D,
                    180.0F, sp.getXRot());
            sp.setPortalCooldown();
            sp.sendSystemMessage(Component.literal(
                    "§a✦ Você retornou a Valdoria. Boa sorte, Escolhido."));

        } else {
            // ===== PORTAL DE IDA — Overworld → Nivéria =====
            ServerLevel niveria = sp.getServer().getLevel(NiveriaDimension.NIVERIA);
            if (niveria == null) return;

            // garante a sala/estruturas e chega no canto da plataforma (fora do portal de volta)
            com.valdoria.rpg.world.NiveriaStructures.ensureBuilt(niveria);
            sp.teleportTo(niveria,
                    2.5D, com.valdoria.rpg.world.NiveriaChunkGenerator.SPAWN_Y + 0.1D, 2.5D,
                    sp.getYRot(), sp.getXRot());
            sp.setPortalCooldown();
        }
    }
}
