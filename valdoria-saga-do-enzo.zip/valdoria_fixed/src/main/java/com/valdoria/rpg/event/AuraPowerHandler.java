package com.valdoria.rpg.event;

import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.network.ModNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.phys.AABB;
import java.util.List;

/**
 * Poderes únicos de cada nível de aura, ativados via tecla T.
 * Cooldown: 20s (400 ticks). Custo: 30 de mana.
 */
public final class AuraPowerHandler {
    private AuraPowerHandler() {}

    private static final int COOLDOWN_TICKS = 400; // 20 segundos
    private static final float MANA_COST    = 30F;

    /** Chave NBT para o cooldown do poder único de aura. */
    private static final String KEY_POWER_CD = "auraPowerCd";

    public static int getPowerCooldown(ServerPlayer sp) {
        return PlayerData.root(sp).getInt(KEY_POWER_CD);
    }
    public static void setPowerCooldown(ServerPlayer sp, int ticks) {
        PlayerData.root(sp).putInt(KEY_POWER_CD, Math.max(0, ticks));
    }
    public static void tickPowerCooldown(ServerPlayer sp) {
        int cd = getPowerCooldown(sp);
        if (cd > 0) PlayerData.root(sp).putInt(KEY_POWER_CD, cd - 1);
    }

    /** Chamado pelo servidor ao receber AuraPowerPacket. */
    public static void activate(ServerPlayer sp) {
        if (!PlayerData.isAuraActive(sp)) {
            sp.sendSystemMessage(Component.literal("§7✦ Ative a aura primeiro (tecla G)."));
            return;
        }
        int lv = PlayerData.getAuraEquipped(sp);
        if (lv <= 0) return;

        int cd = getPowerCooldown(sp);
        if (cd > 0) {
            sp.sendSystemMessage(Component.literal(
                "§7⏳ Poder em recarga: §f" + (cd / 20) + "s restantes."));
            return;
        }
        float mana = PlayerData.getMana(sp);
        if (mana < MANA_COST) {
            sp.sendSystemMessage(Component.literal(
                "§7✦ Mana insuficiente! Precisa de §f" + (int)MANA_COST + " §7mana."));
            return;
        }

        PlayerData.addMana(sp, -MANA_COST);
        setPowerCooldown(sp, COOLDOWN_TICKS);

        ServerLevel lvl = sp.serverLevel();

        switch (lv) {
            // ── 1: Verdante — Pulso de Cura ─────────────────────────────────
            case PlayerData.AURA_VERDANT -> {
                sp.heal(sp.getMaxHealth() * 0.4F);
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1, false, true));
                sp.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   200, 2, false, true));
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                        sp.getX(), sp.getY()+1, sp.getZ(), 60, 1.0, 1.5, 1.0, 0.1);
                sp.sendSystemMessage(Component.literal("§a✦ Pulso de Cura! §7+40% HP + Regeneração"));
                sp.playSound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, 0.8F, 1.4F);
            }

            // ── 2: Radiante — Choque de Luz ─────────────────────────────────
            case PlayerData.AURA_RADIANCE -> {
                List<Mob> mobs = lvl.getEntitiesOfClass(Mob.class,
                        new AABB(sp.blockPosition()).inflate(10));
                for (Mob m : mobs) {
                    m.hurt(sp.damageSources().playerAttack(sp), 12F);
                    m.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 0, false, true));
                }
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.END_ROD,
                        sp.getX(), sp.getY()+1, sp.getZ(), 100, 2.0, 1.0, 2.0, 0.5);
                sp.sendSystemMessage(Component.literal("§e✦ Choque de Luz! §7Inimigos em 10 blocos cegados e danificados."));
                sp.playSound(net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_IMPACT, 0.7F, 1.6F);
            }

            // ── 3: Brasa — Explosão de Chamas ───────────────────────────────
            case PlayerData.AURA_EMBER -> {
                List<Mob> mobs = lvl.getEntitiesOfClass(Mob.class,
                        new AABB(sp.blockPosition()).inflate(8));
                for (Mob m : mobs) {
                    m.hurt(sp.damageSources().playerAttack(sp), 20F);
                    m.setSecondsOnFire(6);
                }
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.FLAME,
                        sp.getX(), sp.getY()+1, sp.getZ(), 120, 2.0, 1.0, 2.0, 0.6);
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.LAVA,
                        sp.getX(), sp.getY()+1, sp.getZ(), 40, 1.5, 1.0, 1.5, 0.3);
                sp.sendSystemMessage(Component.literal("§6✦ Explosão de Chamas! §7Inimigos em 8 blocos em chamas."));
                sp.playSound(net.minecraft.sounds.SoundEvents.GENERIC_EXPLODE, 0.9F, 0.8F);
            }

            // ── 4: Carmesim — Fúria de Guerra ───────────────────────────────
            case PlayerData.AURA_CRIMSON -> {
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,     300, 3, false, true));
                sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,   300, 2, false, true));
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,300, 1, false, true));
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION,     300, 2, false, true));
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.CRIT,
                        sp.getX(), sp.getY()+1, sp.getZ(), 80, 0.8, 1.2, 0.8, 0.5);
                sp.sendSystemMessage(Component.literal("§c✦ Fúria de Guerra! §715s de poder máximo de combate."));
                sp.playSound(net.minecraft.sounds.SoundEvents.RAVAGER_ROAR, 1.0F, 1.0F);
            }

            // ── 5: Arcana — Vórtex Arcano ───────────────────────────────────
            case PlayerData.AURA_ARCANE -> {
                // Puxa todos os mobs para perto e causa dano mágico
                List<Mob> mobs = lvl.getEntitiesOfClass(Mob.class,
                        new AABB(sp.blockPosition()).inflate(15));
                for (Mob m : mobs) {
                    double dx = sp.getX() - m.getX();
                    double dy = sp.getY() - m.getY();
                    double dz = sp.getZ() - m.getZ();
                    double dist = Math.max(1.0, Math.sqrt(dx*dx+dy*dy+dz*dz));
                    m.setDeltaMovement(dx/dist * 1.5, dy/dist * 0.5 + 0.3, dz/dist * 1.5);
                    m.hurt(sp.damageSources().magic(), 18F);
                }
                // Raio em cada mob puxado
                for (Mob m : mobs) {
                    LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(lvl);
                    if (bolt != null) {
                        bolt.moveTo(m.getX(), m.getY(), m.getZ());
                        bolt.setVisualOnly(true);
                        lvl.addFreshEntity(bolt);
                    }
                }
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.WITCH,
                        sp.getX(), sp.getY()+1, sp.getZ(), 80, 2.0, 1.5, 2.0, 0.2);
                sp.sendSystemMessage(Component.literal("§5✦ Vórtex Arcano! §7Inimigos em 15 blocos puxados e danificados."));
                sp.playSound(net.minecraft.sounds.SoundEvents.ENDER_DRAGON_GROWL, 0.6F, 1.4F);
            }

            // ── 6: Glacial — Blizzard ───────────────────────────────────────
            case PlayerData.AURA_GLACIAL -> {
                List<Mob> mobs = lvl.getEntitiesOfClass(Mob.class,
                        new AABB(sp.blockPosition()).inflate(12));
                for (Mob m : mobs) {
                    m.hurt(sp.damageSources().playerAttack(sp), 16F);
                    m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 200, 4, false, true));
                    m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,          200, 2, false, true));
                    // Congela no chão (tentativa visual com freezing)
                    m.setTicksFrozen(200);
                }
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.SNOWFLAKE,
                        sp.getX(), sp.getY()+1, sp.getZ(), 150, 3.0, 2.0, 3.0, 0.3);
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.ITEM_SNOWBALL,
                        sp.getX(), sp.getY()+1, sp.getZ(), 60, 2.0, 1.5, 2.0, 0.8);
                sp.sendSystemMessage(Component.literal("§b✦ Blizzard! §7Inimigos em 12 blocos congelados e enfraquecidos."));
                sp.playSound(net.minecraft.sounds.SoundEvents.POWDER_SNOW_PLACE, 1.5F, 0.5F);
                sp.playSound(net.minecraft.sounds.SoundEvents.GLASS_BREAK, 1.0F, 0.6F);
            }

            // ── 7: Onipotente — Julgamento Divino ───────────────────────────
            case PlayerData.AURA_OMNIPOTENT -> {
                // Raios em TODOS os mobs em 20 blocos + buffs supremos
                List<Mob> mobs = lvl.getEntitiesOfClass(Mob.class,
                        new AABB(sp.blockPosition()).inflate(20));
                for (Mob m : mobs) {
                    m.hurt(sp.damageSources().playerAttack(sp), 40F);
                    LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(lvl);
                    if (bolt != null) {
                        bolt.moveTo(m.getX(), m.getY(), m.getZ());
                        bolt.setVisualOnly(false);
                        lvl.addFreshEntity(bolt);
                    }
                }
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,      600, 4, false, true));
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 600, 4, false, true));
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION,      600, 4, false, true));
                sp.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,        600, 9, false, true));
                sp.heal(sp.getMaxHealth());
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.TOTEM_OF_UNDYING,
                        sp.getX(), sp.getY()+1, sp.getZ(), 200, 2.0, 2.0, 2.0, 0.8);
                lvl.sendParticles(net.minecraft.core.particles.ParticleTypes.DRAGON_BREATH,
                        sp.getX(), sp.getY()+1, sp.getZ(), 100, 2.5, 1.5, 2.5, 0.5);
                sp.sendSystemMessage(Component.literal("§0§l✦ JULGAMENTO DIVINO! §r§7Raios em todos os inimigos. HP total restaurado."));
                sp.playSound(net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_THUNDER, 1.5F, 0.5F);
                sp.playSound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP,         1.0F, 0.3F);
            }
        }

        ModNetwork.sync(sp);
    }
}
