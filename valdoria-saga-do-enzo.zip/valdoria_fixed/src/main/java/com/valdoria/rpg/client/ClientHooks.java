package com.valdoria.rpg.client;

import com.valdoria.rpg.client.screen.FactionScreen;
import net.minecraft.client.Minecraft;

public final class ClientHooks {
    private ClientHooks() {}

    public static void openFactionScreen() {
        Minecraft.getInstance().setScreen(new FactionScreen());
    }
}
