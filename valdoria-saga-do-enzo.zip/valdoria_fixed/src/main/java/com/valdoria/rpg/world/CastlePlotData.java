package com.valdoria.rpg.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Alocador persistente: cada UUID recebe um terreno exclusivo no mundo. */
public final class CastlePlotData extends SavedData {
    private static final String DATA_NAME = "valdoria_castle_plots";
    private final Map<UUID, Integer> plots = new HashMap<>();

    public static CastlePlotData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                CastlePlotData::load,
                CastlePlotData::new,
                DATA_NAME
        );
    }

    public int getOrAllocate(UUID playerId) {
        Integer existing = plots.get(playerId);
        if (existing != null) return existing;
        Set<Integer> used = new HashSet<>(plots.values());
        int slot = 0;
        while (used.contains(slot)) slot++;
        plots.put(playerId, slot);
        setDirty();
        return slot;
    }

    public static CastlePlotData load(CompoundTag tag) {
        CastlePlotData data = new CastlePlotData();
        CompoundTag entries = tag.getCompound("plots");
        for (String key : entries.getAllKeys()) {
            try { data.plots.put(UUID.fromString(key), entries.getInt(key)); }
            catch (IllegalArgumentException ignored) { }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        CompoundTag entries = new CompoundTag();
        plots.forEach((uuid, slot) -> entries.putInt(uuid.toString(), slot));
        tag.put("plots", entries);
        return tag;
    }
}
