package com.valdoria.rpg.client.screen;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import org.joml.Matrix4f;

import java.util.Random;

/**
 * Cutscene final — Quest 101 "A Saga do Enzo"
 *
 * Fases (em ticks):
 *   0–79    fade-in preto
 *   80–259  céu partido + fragmentos do universo Degelko caindo
 *   260–399 fade-out para branco intenso ("big bang" inverso)
 *   400–499 tela branca pura (silêncio)
 *   500–799 mensagem dos mobs aparece letra por letra
 *   800–959 mensagem fica visível completa
 *   960–1039 fade-out final para preto
 *   1040+   fecha a tela e volta ao jogo
 */
public final class EndingCutsceneScreen extends Screen {

    // ---- estado ----
    private int tick = 0;
    private boolean soundedWither  = false;
    private boolean soundedExplode = false;
    private boolean soundedLevel   = false;
    private boolean soundedContinua = false;
    private boolean buttonAdded    = false;
    // shake do mundo desabando
    private float shakeX = 0, shakeY = 0;
    private final Random shakeRng = new Random();

    // fragmentos gerados uma vez
    private static final int FRAG_COUNT = 60;
    private final float[] fragX    = new float[FRAG_COUNT];
    private final float[] fragY    = new float[FRAG_COUNT];
    private final float[] fragVx   = new float[FRAG_COUNT];
    private final float[] fragVy   = new float[FRAG_COUNT];
    private final float[] fragSize = new float[FRAG_COUNT];
    private final float[] fragRot  = new float[FRAG_COUNT];
    private final float[] fragRotV = new float[FRAG_COUNT];
    private final int[]   fragColor= new int[FRAG_COUNT];

    // estrelas de fundo
    private static final int STAR_COUNT = 120;
    private final float[] starX = new float[STAR_COUNT];
    private final float[] starY = new float[STAR_COUNT];
    private final float[] starB = new float[STAR_COUNT]; // brilho 0-1

    // texto completo a ser digitado
    private static final String[] LINES = {
        "Guerreiro...",
        " ",
        "Você carregou o peso de um mundo",
        "que nunca pediu para ser salvo.",
        " ",
        "Nós não tínhamos esperança.",
        "Até que você chegou.",
        " ",
        "Você foi o motivo de estarmos vivos.",
        " ",
        "Obrigado.",
        " ",
        "— Os Mobs de Valdoria"
    };
    private static final int CHARS_PER_TICK = 1; // velocidade de digitação

    private final StringBuilder displayed = new StringBuilder();
    private int totalChars = 0;
    private int charsShown = 0;

    // ---- ticks por fase ----
    private static final int T_FADEIN_END    = 80;
    private static final int T_FRAGS_END     = 260;
    private static final int T_WHITE_START   = 300;
    private static final int T_WHITE_END     = 500;
    private static final int T_TEXT_START    = 500;
    private static final int T_TEXT_STAY     = 800;
    private static final int T_FADEOUT_END   = 1000;
    // ---- fases "CONTINUA..." e botão ----
    private static final int T_SHAKE_START   = 900;  // mundo começa a tremer
    private static final int T_SHAKE_END     = 1050;
    private static final int T_BLACK_START   = 1000;
    private static final int T_BLACK_END     = 1080;
    private static final int T_CONTINUA_START = 1090; // "CONTINUA..." aparece
    private static final int T_BUTTON_START  = 1200; // botão aparece
    // NÃO auto-fecha mais — botão fecha

    public EndingCutsceneScreen() {
        super(Component.empty());
        Random rng = new Random(12345L);
        for (int i = 0; i < FRAG_COUNT; i++) {
            fragX[i]    = rng.nextFloat();
            fragY[i]    = rng.nextFloat() * 0.6f;
            fragVx[i]   = (rng.nextFloat() - 0.5f) * 0.004f;
            fragVy[i]   = rng.nextFloat() * 0.003f + 0.001f;
            fragSize[i] = rng.nextFloat() * 0.06f + 0.02f;
            fragRot[i]  = rng.nextFloat() * 360f;
            fragRotV[i] = (rng.nextFloat() - 0.5f) * 2.0f;
            int r = rng.nextInt(80) + 80;
            int g = rng.nextInt(60) + 20;
            int b = rng.nextInt(50) + 10;
            fragColor[i] = (r << 16) | (g << 8) | b;
        }
        for (int i = 0; i < STAR_COUNT; i++) {
            starX[i] = rng.nextFloat();
            starY[i] = rng.nextFloat();
            starB[i] = rng.nextFloat();
        }
        // pré-calcula total de chars
        for (String l : LINES) totalChars += l.length();
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    protected void init() { super.init(); }

    @Override
    public void tick() {
        tick++;

        // Sons
        Minecraft mc = Minecraft.getInstance();
        if (!soundedWither && tick == T_FADEIN_END + 10 && mc.level != null) {
            mc.level.playLocalSound(mc.player.blockPosition(),
                    SoundEvents.WITHER_SPAWN, SoundSource.MASTER, 0.7f, 0.6f, false);
            soundedWither = true;
        }
        if (!soundedExplode && tick == T_WHITE_START && mc.level != null) {
            mc.level.playLocalSound(mc.player.blockPosition(),
                    SoundEvents.GENERIC_EXPLODE, SoundSource.MASTER, 1.0f, 0.4f, false);
            soundedExplode = true;
        }
        if (!soundedLevel && tick == T_TEXT_START + 20 && mc.level != null) {
            mc.level.playLocalSound(mc.player.blockPosition(),
                    SoundEvents.PLAYER_LEVELUP, SoundSource.MASTER, 1.0f, 0.8f, false);
            soundedLevel = true;
        }

        // Atualiza fragmentos
        for (int i = 0; i < FRAG_COUNT; i++) {
            fragX[i]   += fragVx[i];
            fragY[i]   += fragVy[i];
            fragRot[i] += fragRotV[i];
        }

        // Texto digitado
        if (tick >= T_TEXT_START && tick < T_TEXT_STAY) {
            int target = Math.min((tick - T_TEXT_START) * CHARS_PER_TICK, totalChars);
            while (charsShown < target) {
                int pos = charsShown;
                // descobre qual char é
                int remaining = pos;
                for (String line : LINES) {
                    if (remaining < line.length()) {
                        displayed.append(line.charAt(remaining));
                        break;
                    }
                    remaining -= line.length();
                    if (remaining == 0) { displayed.append('\n'); break; }
                }
                charsShown++;
            }
        }

        // Tremor do mundo desabando
        if (tick >= T_SHAKE_START && tick <= T_SHAKE_END) {
            float intensity = Math.min(1f, (tick - T_SHAKE_START) / 80f) * 8f;
            shakeX = (shakeRng.nextFloat() - 0.5f) * intensity;
            shakeY = (shakeRng.nextFloat() - 0.5f) * intensity;
        } else {
            shakeX = 0; shakeY = 0;
        }

        // Som do "CONTINUA..." (impacto grave)
        if (!soundedContinua && tick == T_CONTINUA_START && mc.level != null) {
            mc.level.playLocalSound(mc.player.blockPosition(),
                    SoundEvents.WITHER_DEATH, SoundSource.MASTER, 1.2f, 0.4f, false);
            soundedContinua = true;
        }

        // Adiciona o botão quando chegar a hora
        if (!buttonAdded && tick >= T_BUTTON_START) {
            buttonAdded = true;
            int bw = 180, bh = 24;
            int bx = (width - bw) / 2;
            int by = (int)(height * 0.72f);
            addRenderableWidget(Button.builder(
                    Component.literal("§a▶  Continuar Jogando"),
                    btn -> onClose()
            ).bounds(bx, by, bw, bh).build());
        }
    }

    @Override
    public void render(GuiGraphics gfx, int mx, int my, float partial) {
        int W = width, H = height;
        float t = tick + partial;

        // Aplica tremor do mundo
        if (shakeX != 0 || shakeY != 0) {
            gfx.pose().pushPose();
            gfx.pose().translate(shakeX, shakeY, 0);
        }

        // ---- fase 1: fade-in preto → cosmos ----
        float bgAlpha;
        if (t < T_FADEIN_END) {
            bgAlpha = 1.0f - (t / T_FADEIN_END);
        } else if (t < T_WHITE_START) {
            bgAlpha = 0f;
        } else if (t < T_WHITE_END) {
            // flash branco
            float prog = (t - T_WHITE_START) / (float)(T_WHITE_END - T_WHITE_START);
            // branco até meio, depois escurece
            bgAlpha = prog < 0.5f ? -(prog * 2) : (prog - 0.5f) * 2f;
            // reutilizamos a mesma variável mas desenhamos branco abaixo
        } else {
            bgAlpha = 0f;
        }

        // fundo preto total
        gfx.fill(0, 0, W, H, 0xFF000000);

        // cosmos (estrelas + fragmentos) — visível entre fade-in e flash branco
        if (t >= T_FADEIN_END && t < T_WHITE_START) {
            float cosmosAlpha = Math.min(1f, (t - T_FADEIN_END) / 30f);
            renderCosmos(gfx, W, H, cosmosAlpha, t);
        } else if (t >= T_WHITE_END && t < T_TEXT_START) {
            // cosmos voltando levemente como pano de fundo do texto
            float fade = (t - T_WHITE_END) / (float)(T_TEXT_START - T_WHITE_END);
            renderCosmos(gfx, W, H, fade * 0.4f, t);
        } else if (t >= T_TEXT_START) {
            renderCosmos(gfx, W, H, 0.3f, t);
        }

        // flash branco
        if (t >= T_WHITE_START && t < T_WHITE_END) {
            float prog = (t - T_WHITE_START) / (float)(T_WHITE_END - T_WHITE_START);
            int wAlpha;
            if (prog < 0.4f) {
                wAlpha = (int)(255 * (prog / 0.4f));
            } else if (prog < 0.6f) {
                wAlpha = 255;
            } else {
                wAlpha = (int)(255 * (1f - (prog - 0.6f) / 0.4f));
            }
            gfx.fill(0, 0, W, H, (wAlpha << 24) | 0xFFFFFF);
        }

        // fade-in inicial (preto sobre tudo)
        if (t < T_FADEIN_END) {
            int a = (int)(255 * (1f - t / T_FADEIN_END));
            gfx.fill(0, 0, W, H, (a << 24));
        }

        // ---- fase texto ----
        if (t >= T_TEXT_START && t < T_FADEOUT_END) {
            float textAlpha;
            if (t < T_TEXT_STAY) {
                textAlpha = Math.min(1f, (t - T_TEXT_START) / 60f);
            } else {
                textAlpha = Math.max(0f, 1f - (t - T_TEXT_STAY) / (float)(T_FADEOUT_END - T_TEXT_STAY));
            }
            renderText(gfx, W, H, textAlpha);
        }

        // fade-out final (do texto → preto)
        if (t >= T_FADEOUT_END && t < T_BLACK_END) {
            float prog = Math.min(1f, (t - T_FADEOUT_END) / (float)(T_BLACK_END - T_FADEOUT_END));
            int a = (int)(255 * prog);
            gfx.fill(0, 0, W, H, (a << 24));
        }

        // Fecha tremor
        if (shakeX != 0 || shakeY != 0) {
            gfx.pose().popPose();
        }

        // ---- FASE "CONTINUA..." ----
        if (t >= T_CONTINUA_START) {
            // Fundo preto sólido
            gfx.fill(0, 0, W, H, 0xFF000000);
            renderContinuaScreen(gfx, W, H, t);
        }
    }

    private void renderContinuaScreen(GuiGraphics gfx, int W, int H, float t) {
        net.minecraft.client.gui.Font font = Minecraft.getInstance().font;
        float elapsed = t - T_CONTINUA_START;

        // "CONTINUA..." aparece letra por letra com escala crescente
        String continua = "CONTINUA...";
        float textAlpha = Math.min(1f, elapsed / 40f);
        int ia = (int)(textAlpha * 255);

        // Texto principal centralizado — grande
        gfx.pose().pushPose();
        float scale = 3.5f + 0.3f * (float)Math.sin(elapsed * 0.03f);
        gfx.pose().translate(W / 2f, H * 0.42f, 0);
        gfx.pose().scale(scale, scale, 1f);

        int tw = font.width(continua);
        int col = (ia << 24) | 0xFFD700; // dourado
        gfx.drawString(font, continua, -tw / 2, -font.lineHeight / 2, col, true);
        gfx.pose().popPose();

        // Linha decorativa abaixo
        if (elapsed > 30) {
            float lineAlpha = Math.min(1f, (elapsed - 30) / 20f);
            int la = (int)(lineAlpha * 180);
            int lx1 = W / 2 - 120, lx2 = W / 2 + 120, ly = (int)(H * 0.56f);
            gfx.fill(lx1, ly, lx2, ly + 1, (la << 24) | 0xFFD700);
        }

        // Subtítulo
        if (elapsed > 50) {
            float subAlpha = Math.min(1f, (elapsed - 50) / 30f);
            int sa = (int)(subAlpha * 200);
            String sub = "§7A saga de Enzo ainda não terminou.";
            int stw = font.width(sub);
            gfx.drawString(font, sub, (W - stw) / 2, (int)(H * 0.60f), (sa << 24) | 0xAAAAAA, false);
        }
    }

    private void renderCosmos(GuiGraphics gfx, int W, int H, float alpha, float t) {
        if (alpha <= 0) return;
        int ia = (int)(alpha * 255);

        // estrelas
        for (int i = 0; i < STAR_COUNT; i++) {
            float twinkle = 0.5f + 0.5f * (float)Math.sin(t * 0.03f + starB[i] * 10f);
            int sa = (int)(ia * twinkle * starB[i]);
            int sx = (int)(starX[i] * W);
            int sy = (int)(starY[i] * H);
            int col = (sa << 24) | 0xFFFFFF;
            gfx.fill(sx, sy, sx + 1, sy + 1, col);
            if (starB[i] > 0.7f) gfx.fill(sx - 1, sy, sx + 2, sy + 1, (sa / 3 << 24) | 0xAAAAAA);
        }

        // fragmentos de Degelko
        for (int i = 0; i < FRAG_COUNT; i++) {
            float fx = fragX[i] * W;
            float fy = fragY[i] * H;
            float sz = fragSize[i] * Math.min(W, H);
            int col = (ia << 24) | fragColor[i];
            drawRotatedQuad(gfx, fx, fy, sz, fragRot[i], col);
        }

        // planeta principal — Degelko partido
        float cx = W * 0.5f, cy = H * 0.38f;
        float r  = Math.min(W, H) * 0.14f;
        float crack = Math.min(1f, Math.max(0f, (t - T_FADEIN_END) / (float)(T_WHITE_START - T_FADEIN_END)));

        // planeta base (círculo aproximado com quads)
        drawCircle(gfx, cx, cy, r, ia, 0x1A3366);  // azul escuro Degelko

        // rachadura sobre o planeta
        float crackLen = r * crack;
        int crackCol = (ia << 24) | 0xFF6600;
        gfx.fill((int)(cx - 2), (int)(cy - crackLen), (int)(cx + 2), (int)(cy + crackLen), crackCol);
        gfx.fill((int)(cx - crackLen * 0.6f), (int)(cy - 2), (int)(cx + crackLen * 0.6f), (int)(cy + 2), crackCol);
        gfx.fill((int)(cx - crackLen * 0.4f), (int)(cy - crackLen * 0.6f),
                 (int)(cx + 1), (int)(cy + crackLen * 0.4f), (ia / 2 << 24) | 0xFF4400);

        // brilho laranja ao redor (destruction glow)
        float glow = crack * r * 0.25f;
        for (int ring = 1; ring <= 4; ring++) {
            int ga = (int)(ia * crack * (1f - ring * 0.2f));
            drawCircleOutline(gfx, cx, cy, r + ring * glow * 0.5f, ga, 0xFF6600);
        }
    }

    private void renderText(GuiGraphics gfx, int W, int H, float alpha) {
        int ia = (int)(alpha * 255);
        if (ia <= 0) return;

        // painel semi-transparente
        int panelAlpha = (int)(ia * 0.55f);
        int panelY = (int)(H * 0.3f);
        int panelH = (int)(H * 0.45f);
        gfx.fill(W / 8, panelY, W * 7 / 8, panelY + panelH, (panelAlpha << 24));

        // borda suave
        int borderCol = (ia << 24) | 0x885500;
        gfx.fill(W / 8,       panelY,          W * 7 / 8, panelY + 1,      borderCol);
        gfx.fill(W / 8,       panelY + panelH, W * 7 / 8, panelY + panelH + 1, borderCol);

        // reconstró as linhas a partir do buffer
        String full = displayed.toString();
        String[] lines = full.split("\n", -1);

        int lineH   = 11;
        int totalH  = lines.length * lineH;
        int startY  = panelY + (panelH - totalH) / 2;

        net.minecraft.client.gui.Font font = Minecraft.getInstance().font;

        for (int i = 0; i < lines.length; i++) {
            String line = lines[i].trim();
            if (line.isEmpty()) continue;

            int color;
            boolean shadow;
            if (line.startsWith("—") || line.startsWith("Obrigado")) {
                // assinatura — dourado
                color = (ia << 24 >> 24 & 0xFF) << 24 | 0xFFD700;
                // simplificado: usar cor fixa com alpha manual
                color = blendColor(0xFFD700, ia);
                shadow = true;
            } else if (line.startsWith("Você foi")) {
                color = blendColor(0xFFFFAA, ia);
                shadow = true;
            } else {
                color = blendColor(0xE8E8E8, ia);
                shadow = false;
            }

            int tw = font.width(line);
            int tx = (W - tw) / 2;
            int ty = startY + i * lineH;
            gfx.drawString(font, line, tx, ty, color, shadow);
        }

        // cursor piscante enquanto está "digitando"
        if (charsShown < totalChars && tick < T_TEXT_STAY) {
            if ((tick / 15) % 2 == 0) {
                int lastW = font.width(lines[lines.length - 1].trim());
                int curX  = (W + lastW) / 2;
                int curY  = startY + (lines.length - 1) * lineH;
                gfx.fill(curX, curY, curX + 1, curY + lineH - 2, blendColor(0xFFFFFF, ia));
            }
        }
    }

    // ---- helpers de desenho ----

    private static int blendColor(int rgb, int alpha) {
        return (alpha << 24) | (rgb & 0xFFFFFF);
    }

    /** Desenha um quadrado rotacionado simples usando fill (aproximação). */
    private static void drawRotatedQuad(GuiGraphics gfx, float cx, float cy, float size, float deg, int color) {
        // aproximação: só um fill simples orientado pelo ângulo (sem matriz)
        // para uma cutscene isso é suficientemente bonito
        int s = Math.max(2, (int) size);
        gfx.fill((int)(cx - s / 2f), (int)(cy - s / 2f),
                 (int)(cx + s / 2f), (int)(cy + s / 2f), color);
        // "rotação" simulada: um traço diagonal
        int d = (int)(size * 0.4f);
        float rad = (float)Math.toRadians(deg);
        int dx = (int)(Math.cos(rad) * d);
        int dy = (int)(Math.sin(rad) * d);
        gfx.fill((int)(cx + dx - 1), (int)(cy + dy - 1),
                 (int)(cx + dx + 1), (int)(cy + dy + 1), color);
    }

    /** Desenha um círculo preenchido como uma série de faixas horizontais. */
    private static void drawCircle(GuiGraphics gfx, float cx, float cy, float r, int alpha, int rgb) {
        int ia = alpha;
        int ir = (int) r;
        for (int dy = -ir; dy <= ir; dy++) {
            int dx = (int) Math.sqrt(Math.max(0, r * r - dy * dy));
            // gradiente radial: mais claro no centro
            float dist = (float) Math.sqrt(dy * dy) / r;
            int a = (int)(ia * (1f - dist * 0.3f));
            gfx.fill((int)(cx - dx), (int)(cy + dy), (int)(cx + dx), (int)(cy + dy + 1),
                     (a << 24) | rgb);
        }
    }

    /** Desenha o outline de um círculo. */
    private static void drawCircleOutline(GuiGraphics gfx, float cx, float cy, float r, int alpha, int rgb) {
        int steps = 48;
        for (int i = 0; i < steps; i++) {
            double a = (i / (double) steps) * Math.PI * 2;
            int x = (int)(cx + Math.cos(a) * r);
            int y = (int)(cy + Math.sin(a) * r);
            gfx.fill(x - 1, y - 1, x + 1, y + 1, (alpha << 24) | rgb);
        }
    }

    // fecha sem abrir menu de pausa
    @Override
    public void onClose() {
        Minecraft.getInstance().setScreen(null);
    }

    // bloqueia todas as entradas durante a cutscene (exceto na fase CONTINUA onde o botão é clicável)
    @Override public boolean keyPressed(int k, int s, int m) {
        // ESC pula a cutscene diretamente para fase CONTINUA (ou fecha se já estiver nela)
        if (k == 256) {
            if (tick >= T_CONTINUA_START) {
                onClose();
            } else {
                tick = T_CONTINUA_START;
            }
            return true;
        }
        return tick >= T_BUTTON_START && super.keyPressed(k, s, m);
    }
    @Override public boolean mouseClicked(double x, double y, int b) {
        // Só permite clique quando o botão estiver visível
        if (tick >= T_BUTTON_START) return super.mouseClicked(x, y, b);
        return false;
    }
}
