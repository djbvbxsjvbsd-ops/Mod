// [ClientEvents.java] — teclados, overlay Nivéria, ESP de quest, Spirit Aura (tecla G)
package com.valdoria.rpg.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.client.renderer.GokuAura;
import com.valdoria.rpg.client.renderer.SpiritAuraRenderer;
import com.valdoria.rpg.client.screen.ClassScreen;
import com.valdoria.rpg.client.screen.MapScreen;
import com.valdoria.rpg.client.screen.ProfileScreen;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.network.SpiritAuraPacket;
import com.valdoria.rpg.network.AuraPowerPacket;
import com.valdoria.rpg.network.WhirlpoolPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, value = Dist.CLIENT)
public class ClientEvents {
    private static int coldFlicker = 0;

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        // Tick do renderer de aura (animação)
        SpiritAuraRenderer.clientTick();

        while (KeyMappings.PROFILE.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new ProfileScreen());
        }
        while (KeyMappings.MAP.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new MapScreen());
        }
        while (KeyMappings.HUD.consumeClick()) {
            ClientData.hudVisible = !ClientData.hudVisible;
        }
        while (KeyMappings.CLASS_SCR.consumeClick()) {
            if (mc.player != null && mc.screen == null) mc.setScreen(new ClassScreen());
        }
        while (KeyMappings.WHIRLPOOL.consumeClick()) {
            if (mc.player != null && ClientData.isIceKing() && mc.screen == null) {
                ModNetwork.INSTANCE.sendToServer(new WhirlpoolPacket());
            }
        }
        while (KeyMappings.WORLD_HUB.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                mc.setScreen(new com.valdoria.rpg.client.screen.WorldHubScreen());
            }
        }

        // ===== SPIRIT AURA — tecla G =====
        while (KeyMappings.SPIRIT_AURA.consumeClick()) {
            if (mc.player != null && mc.screen == null) {
                // Detecta Shift pressionado para "avançar nível"
                boolean shift = net.minecraft.client.gui.screens.Screen.hasShiftDown();
                ModNetwork.INSTANCE.sendToServer(new SpiritAuraPacket(shift));
            }
        }

        // ===== PODER ÚNICO DA AURA — tecla T (após transformação) =====
        while (KeyMappings.AURA_POWER.consumeClick()) {
            if (mc.player != null && mc.screen == null && ClientData.auraActive) {
                ModNetwork.INSTANCE.sendToServer(new AuraPowerPacket());
            }
        }

        coldFlicker++;
    }

    @SubscribeEvent
    public static void fog(ViewportEvent.ComputeFogColor e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        if (ClientData.completed >= 20 && ClientData.completed < 49 && mc.level.dimension() == Level.OVERWORLD) {
            e.setRed(0.70F); e.setGreen(0.05F); e.setBlue(0.05F);
        }
        if (ClientData.inNiveria) {
            e.setRed(0.60F); e.setGreen(0.78F); e.setBlue(0.95F);
        }
    }

    @SubscribeEvent
    public static void renderOverlay(RenderGuiOverlayEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();

        // --- Overlay Nivéria ---
        if (ClientData.inNiveria && e.getOverlay() == VanillaGuiOverlay.HOTBAR.type()) {
            boolean isKing = ClientData.isIceKing();
            int alpha = isKing ? 0x14 : 0x22;
            boolean visible = (coldFlicker / 20) % 2 == 0;
            if (visible && !isKing) {
                e.getGuiGraphics().fill(0, 0, w, h, (alpha << 24) | 0x006680);
                e.getGuiGraphics().drawCenteredString(mc.font, "§b❄ FRIO EXTREMO ❄", w / 2, h / 2 - 60, 0xFF88CCFF);
            }
            if (isKing && visible) {
                e.getGuiGraphics().drawCenteredString(mc.font, "§b❄ Rei do Gelo — 40% resist", w / 2, h / 2 - 60, 0xFF44CCFF);
            }
        }

        // --- HUD da Spirit Aura (canto inferior direito) ---
        if (ClientData.hudVisible && e.getOverlay() == VanillaGuiOverlay.HOTBAR.type()) {
            renderAuraHud(e, mc, w, h);
        }

        // --- Aura em PRIMEIRA PESSOA: vinheta colorida nas bordas da tela ---
        if (ClientData.auraActive && ClientData.auraEquipped > 0
                && e.getOverlay() == VanillaGuiOverlay.HOTBAR.type()
                && mc.options.getCameraType().isFirstPerson()
                && mc.screen == null) {
            renderFirstPersonAuraVignette(e.getGuiGraphics(), w, h, mc);
        }
    }

    private static int firstPersonAuraTick = 0;

    private static void renderFirstPersonAuraVignette(net.minecraft.client.gui.GuiGraphics gfx,
                                                       int w, int h, Minecraft mc) {
        firstPersonAuraTick++;
        int lv = ClientData.auraEquipped;
        float[] c = GokuAura.palette(lv);
        // Pulso suave
        float pulse = 0.55f + 0.45f * (float)Math.abs(Math.sin(firstPersonAuraTick * 0.04f));
        int r = (int)(c[0] * 180 * pulse);
        int g = (int)(c[1] * 180 * pulse);
        int b = (int)(c[2] * 180 * pulse);

        int vignetteAlpha = (int)(80 * pulse); // 0-80 de alpha

        // Vinheta nas 4 bordas (gradiente de fora para dentro)
        int thick = Math.max(20, w / 8); // espessura das bordas
        // Borda esquerda
        gfx.fillGradient(0, 0, thick, h,
                (vignetteAlpha << 24) | (r << 16) | (g << 8) | b,
                (0 << 24) | (r << 16) | (g << 8) | b);
        // Borda direita
        gfx.fillGradient(w - thick, 0, w, h,
                (0 << 24) | (r << 16) | (g << 8) | b,
                (vignetteAlpha << 24) | (r << 16) | (g << 8) | b);
        // Borda superior
        gfx.fillGradient(0, 0, w, thick,
                (vignetteAlpha << 24) | (r << 16) | (g << 8) | b,
                (0 << 24) | (r << 16) | (g << 8) | b);
        // Borda inferior
        gfx.fillGradient(0, h - thick, w, h,
                (0 << 24) | (r << 16) | (g << 8) | b,
                (vignetteAlpha << 24) | (r << 16) | (g << 8) | b);

        // Partículas de aura na borda inferior (simulando chamas subindo)
        // Usamos pixels aleatórios na parte inferior da tela
        java.util.Random rnd = new java.util.Random(firstPersonAuraTick / 3L);
        int sparks = 8 + lv * 2;
        for (int i = 0; i < sparks; i++) {
            int sx = rnd.nextInt(w);
            float yOff = (float)(rnd.nextFloat() * thick * 0.6f);
            float alpha = (float)(0.6f + 0.4f * rnd.nextFloat()) * pulse;
            int sa = (int)(alpha * 120);
            int col = (sa << 24) | (r << 16) | (g << 8) | b;
            int sh = (int)(4 + rnd.nextFloat() * 10);
            gfx.fill(sx - 1, (int)(h - yOff - sh), sx + 1, (int)(h - yOff), col);
        }
    }

    private static void renderAuraHud(RenderGuiOverlayEvent.Post e, Minecraft mc, int w, int h) {
        // Tokens disponíveis
        if (ClientData.auraTokens > 0) {
            String tokenTxt = "§d✦ Tokens de Aura: §f" + ClientData.auraTokens;
            e.getGuiGraphics().drawString(mc.font, tokenTxt, w - mc.font.width(tokenTxt) - 4, h - 55, 0xFFFFFFFF);
        }
        // Aura atual
        if (ClientData.auraLevel > 0) {
            String auraName = PlayerData.getAuraName(ClientData.auraEquipped);
            String status   = ClientData.auraActive ? "§a[ATIVA]" : "§7[inativa]";
            String line     = auraName + " " + status;
            e.getGuiGraphics().drawString(mc.font, line, w - mc.font.width(line) - 4, h - 42, 0xFFFFFFFF);
            if (!ClientData.auraActive && ClientData.auraLevel > 0) {
                String hint = "§7G = ativar | Shift+G = trocar";
                e.getGuiGraphics().drawString(mc.font, hint, w - mc.font.width(hint) - 4, h - 29, 0xAAAAAA);
            }
        }
    }

    // =========================================================================
    // ESP — bounding-box colorida ao redor do alvo da quest ativa
    // =========================================================================
    @SubscribeEvent
    public static void renderLevel(RenderLevelStageEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        // Render Spirit Aura
        if (e.getStage() == RenderLevelStageEvent.Stage.AFTER_ENTITIES) {
            if (ClientData.auraActive && ClientData.auraEquipped > 0) {
                PoseStack ps = e.getPoseStack();
                ps.pushPose();
                // Translata para origem da câmera (o PoseStack neste stage está em espaço câmera)
                var cam = mc.gameRenderer.getMainCamera().getPosition();
                ps.translate(-cam.x, -cam.y, -cam.z);
                // aura agora é desenhada no corpo pelo AuraBodyLayer
                ps.popPose();
            }
        }

        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        if (ClientData.espPts.isEmpty() && ClientData.questTargetType != 2) return;

        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        QuestEsp.render(e.getPoseStack(), buf);
        buf.endBatch(EspRenderTypes.ESP_LINES);
    }

    /** Distância até o alvo da missão (topo da tela). */
    @SubscribeEvent
    public static void espHud(RenderGuiOverlayEvent.Post e) {
        if (e.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui || ClientData.espKind == 0) return;
        String txt;
        if (ClientData.espPts.isEmpty()) {
            txt = "§7◆ " + ClientData.espLabel + " — sem alvo carregado por perto";
        } else {
            double best = Double.MAX_VALUE;
            for (float[] p : ClientData.espPts) {
                double dx = p[0] - mc.player.getX(), dy = p[1] - mc.player.getY(), dz = p[2] - mc.player.getZ();
                best = Math.min(best, Math.sqrt(dx * dx + dy * dy + dz * dz));
            }
            txt = "§e◆ " + ClientData.espLabel + " §f" + (int) best + "m";
        }
        e.getGuiGraphics().drawCenteredString(mc.font, txt, mc.getWindow().getGuiScaledWidth() / 2, 6, 0xFFFFFFFF);
    }
}
