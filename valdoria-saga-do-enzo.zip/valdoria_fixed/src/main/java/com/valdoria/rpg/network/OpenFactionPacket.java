package com.valdoria.rpg.network;

import com.valdoria.rpg.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

public class OpenFactionPacket {
    public OpenFactionPacket() {}
    public static void encode(OpenFactionPacket m, FriendlyByteBuf buf) {}
    public static OpenFactionPacket decode(FriendlyByteBuf buf) { return new OpenFactionPacket(); }

    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openFactionScreen);
    }
}
