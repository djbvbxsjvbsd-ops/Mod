package com.valdoria.rpg.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Matrix4f;

import java.util.Random;

/** Aura estilo Goku: chamas subindo em degradê + raios. Espaço local: Y para cima, pés em y=0. */
public final class GokuAura {
    private GokuAura() {}

    // {outer r,g,b, core r,g,b}
    private static final float[][] PAL = {
        {0, 0, 0, 0, 0, 0},
        {0.30F, 1.00F, 0.35F, 0.85F, 1.00F, 0.85F}, // 1 Verdante
        {1.00F, 0.85F, 0.10F, 1.00F, 1.00F, 0.65F}, // 2 Radiante
        {1.00F, 0.75F, 0.05F, 1.00F, 0.95F, 0.55F}, // 3 Brasa (+raios)
        {1.00F, 0.12F, 0.12F, 1.00F, 0.60F, 0.45F}, // 4 Carmesim
        {0.65F, 0.25F, 1.00F, 0.90F, 0.75F, 1.00F}, // 5 Arcana
        {0.10F, 0.55F, 1.00F, 0.70F, 0.95F, 1.00F}, // 6 Glacial
        {0.85F, 0.90F, 1.00F, 1.00F, 1.00F, 1.00F}, // 7 Onipotente
    };

    public static float[] palette(int level) {
        return PAL[Math.max(0, Math.min(level, PAL.length - 1))];
    }

    /**
     * @param c         {outer r,g,b, core r,g,b}
     * @param intensity 0..1 (mais chamas e mais altas)
     * @param w         raio da base
     * @param h         altura total
     */
    public static void draw(PoseStack ps, VertexConsumer vc, float time, float[] c,
                            float intensity, float w, float h, float alpha, boolean bolts) {
        Matrix4f m = ps.last().pose();
        int n = 10 + (int) (intensity * 10);
        flames(m, vc, time, n, w, h, c[0], c[1], c[2], alpha, 0);
        flames(m, vc, time * 1.3F, n - 2, w * 0.6F, h * 0.75F, c[3], c[4], c[5], alpha * 1.15F, 100);
        if (bolts) bolts(m, vc, time, w, h, c[3], c[4], c[5], alpha, 3 + (int) (intensity * 3));
    }

    private static float hash(int i) {
        float s = (float) Math.sin(i * 12.9898F) * 43758.547F;
        return s - (float) Math.floor(s);
    }

    private static void flames(Matrix4f m, VertexConsumer vc, float time, int n, float w, float h,
                               float r, float g, float b, float alpha, int salt) {
        for (int i = 0; i < n; i++) {
            int k = i + salt;
            float a = (float) (i / (double) n * Math.PI * 2.0) + (float) Math.sin(time * 0.05F + k) * 0.1F;
            float flick = 0.65F + 0.35F * (float) Math.abs(Math.sin(time * 0.35F + k * 1.7F));
            float height = h * (0.55F + 0.6F * hash(k)) * flick;
            float r0 = w * (0.75F + 0.25F * hash(k + 7));
            float bx = (float) Math.cos(a) * r0, bz = (float) Math.sin(a) * r0;
            float tx = -(float) Math.sin(a), tz = (float) Math.cos(a);
            float hw = w * 0.30F;
            float sx = (float) Math.sin(time * 0.20F + k) * 0.08F;
            float sz = (float) Math.cos(time * 0.17F + k) * 0.08F;
            float mx = bx * 0.8F + sx * 0.5F, mz = bz * 0.8F + sz * 0.5F, my = height * 0.55F;
            float ex = bx * 0.45F + sx, ez = bz * 0.45F + sz;
            float ba = alpha, ma = alpha * 0.7F;
            // base -> meio
            vc.vertex(m, bx + tx * hw, 0, bz + tz * hw).color(r, g, b, ba).endVertex();
            vc.vertex(m, bx - tx * hw, 0, bz - tz * hw).color(r, g, b, ba).endVertex();
            vc.vertex(m, mx - tx * hw * 0.6F, my, mz - tz * hw * 0.6F).color(r, g, b, ma).endVertex();
            vc.vertex(m, mx + tx * hw * 0.6F, my, mz + tz * hw * 0.6F).color(r, g, b, ma).endVertex();
            // meio -> ponta (alpha 0)
            vc.vertex(m, mx + tx * hw * 0.6F, my, mz + tz * hw * 0.6F).color(r, g, b, ma).endVertex();
            vc.vertex(m, mx - tx * hw * 0.6F, my, mz - tz * hw * 0.6F).color(r, g, b, ma).endVertex();
            vc.vertex(m, ex, height, ez).color(r, g, b, 0F).endVertex();
            vc.vertex(m, ex, height, ez).color(r, g, b, 0F).endVertex();
        }
    }

    private static void bolts(Matrix4f m, VertexConsumer vc, float time, float w, float h,
                              float r, float g, float b, float alpha, int count) {
        Random rnd = new Random((long) (time / 3F) * 7919L);
        float al = Math.min(1F, alpha * 1.6F);
        for (int k = 0; k < count; k++) {
            double a = rnd.nextDouble() * Math.PI * 2.0;
            float x = (float) (Math.cos(a) * w * 0.9F), z = (float) (Math.sin(a) * w * 0.9F);
            float y = rnd.nextFloat() * h * 0.3F;
            int segs = 5;
            for (int s = 0; s < segs; s++) {
                float nx = x + (rnd.nextFloat() - 0.5F) * 0.35F;
                float nz = z + (rnd.nextFloat() - 0.5F) * 0.35F;
                float ny = y + h * 0.7F / segs * (0.7F + rnd.nextFloat() * 0.6F);
                seg(m, vc, x, y, z, nx, ny, nz, 0.03F, r, g, b, al);
                x = nx; y = ny; z = nz;
            }
        }
    }

    private static void seg(Matrix4f m, VertexConsumer vc, float x0, float y0, float z0,
                            float x1, float y1, float z1, float th, float r, float g, float b, float a) {
        vc.vertex(m, x0 - th, y0, z0).color(r, g, b, a).endVertex();
        vc.vertex(m, x0 + th, y0, z0).color(r, g, b, a).endVertex();
        vc.vertex(m, x1 + th, y1, z1).color(r, g, b, a).endVertex();
        vc.vertex(m, x1 - th, y1, z1).color(r, g, b, a).endVertex();
        vc.vertex(m, x0, y0, z0 - th).color(r, g, b, a).endVertex();
        vc.vertex(m, x0, y0, z0 + th).color(r, g, b, a).endVertex();
        vc.vertex(m, x1, y1, z1 + th).color(r, g, b, a).endVertex();
        vc.vertex(m, x1, y1, z1 - th).color(r, g, b, a).endVertex();
    }
}
