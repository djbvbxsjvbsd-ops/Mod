// [NiveriaChunkGenerator.java] — CORRIGIDO: spawn acima do piso, não dentro do chão
package com.valdoria.rpg.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.biome.FixedBiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Nivéria: sala gigante de neve.
 *
 * BUG CORRIGIDO (print): o jogador spawnava DENTRO do chão porque o getBaseHeight()
 * retornava PISO_Y+5 (topo das camadas de blocos), mas o spawn system usava
 * esse valor como Y e o jogador aparecia preso entre os blocos de neve.
 *
 * FIX: getBaseHeight() agora retorna PISO_Y + 5 + 1 = SPAWN_Y (o primeiro Y de AR),
 * e a camada de neve foi ajustada para terminar exatamente em PISO_Y+4, deixando
 * PISO_Y+5 livre (ar). Assim o jogador spawna EM CIMA da neve, não dentro dela.
 *
 * Piso: pedra (0..PISO_Y-1) → packed ice (PISO_Y..PISO_Y+2) → ice (PISO_Y+3) → snow (PISO_Y+4)
 * Primeiro bloco de AR: PISO_Y + 5  ← spawn aqui
 */
public class NiveriaChunkGenerator extends ChunkGenerator {

    public static final Codec<NiveriaChunkGenerator> CODEC = RecordCodecBuilder.create(inst ->
            inst.group(BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.biomeSource))
                    .apply(inst, NiveriaChunkGenerator::new));

    // Sala de 512 blocos de raio ao redor da origem (1024x1024 de espaço interno)
    private static final int SALA_RAIO   = 512;
    // Altura interna da sala (do piso ao teto)
    private static final int SALA_ALTURA = 40;
    // Y do piso (base sólida)
    public  static final int PISO_Y      = 10;
    // ✅ FIX: Y do primeiro bloco de AR (onde o jogador spawna)
    //    Piso ocupa Y=10..14 (5 camadas: packed*3 + ice + snow)
    //    Y=15 é o primeiro ar → spawn correto
    public  static final int SPAWN_Y     = PISO_Y + 5;
    // Y do teto
    private static final int TETO_Y      = PISO_Y + SALA_ALTURA;
    // Espessura das paredes
    private static final int PAREDE_ESP  = 5;

    public NiveriaChunkGenerator(BiomeSource biomeSource) { super(biomeSource); }

    public static NiveriaChunkGenerator create(HolderLookup.Provider lookup) {
        Holder<Biome> iceBiome = lookup.lookupOrThrow(net.minecraft.core.registries.Registries.BIOME)
                .getOrThrow(net.minecraft.world.level.biome.Biomes.ICE_SPIKES);
        return new NiveriaChunkGenerator(new FixedBiomeSource(iceBiome));
    }

    @Override protected Codec<? extends ChunkGenerator> codec() { return CODEC; }

    /** Áreas onde as estruturas são construídas: sem picos de gelo. */
    private static boolean reservado(int x, int z) {
        return (Math.abs(x) <= 12 && Math.abs(z) <= 12)
                || (Math.abs(x - 80) <= 16 && Math.abs(z) <= 16)
                || (Math.abs(x + 120) <= 14 && Math.abs(z - 60) <= 14)
                || (Math.abs(x) <= 30 && Math.abs(z - 210) <= 40);
    }

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager sm, RandomState random, ChunkAccess chunk) {
        int cx = chunk.getPos().getMinBlockX();
        int cz = chunk.getPos().getMinBlockZ();
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        BlockState packed = Blocks.PACKED_ICE.defaultBlockState();
        BlockState blue   = Blocks.BLUE_ICE.defaultBlockState();
        BlockState lamp   = Blocks.SEA_LANTERN.defaultBlockState();
        BlockState air    = Blocks.AIR.defaultBlockState();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int wx = cx + lx;
                int wz = cz + lz;
                boolean dentro = Math.abs(wx) < SALA_RAIO && Math.abs(wz) < SALA_RAIO;

                if (!dentro) {
                    // fora da sala: bloco maciço de gelo
                    for (int y = 0; y <= TETO_Y + PAREDE_ESP + 5; y++) put(chunk, mp, wx, y, wz, packed);
                    continue;
                }

                boolean borda = Math.abs(wx) >= SALA_RAIO - PAREDE_ESP || Math.abs(wz) >= SALA_RAIO - PAREDE_ESP;

                // fundação + piso (gelo compactado)
                for (int y = 0; y <= PISO_Y + 3; y++) put(chunk, mp, wx, y, wz, packed);

                // topo do piso (Y=14): gelo compactado, manchas de gelo azul e lanternas marinhas embutidas
                BlockState top = packed;
                if (Math.floorMod(wx, 12) == 6 && Math.floorMod(wz, 12) == 6) top = lamp;
                else if (isBlueIcePatch(wx, wz)) top = blue;
                put(chunk, mp, wx, PISO_Y + 4, wz, top);

                // interior vazio
                for (int y = SPAWN_Y; y < TETO_Y; y++) put(chunk, mp, wx, y, wz, air);

                // teto de gelo azul + gelo compactado
                put(chunk, mp, wx, TETO_Y, wz, blue);
                for (int y = TETO_Y + 1; y <= TETO_Y + PAREDE_ESP; y++) put(chunk, mp, wx, y, wz, packed);

                // paredes de gelo azul
                if (borda) {
                    for (int y = SPAWN_Y; y <= TETO_Y; y++) put(chunk, mp, wx, y, wz, blue);
                    continue;
                }

                // pilares de gelo
                if (!reservado(wx, wz) && isIceSpike(wx, wz)) {
                    int h = 3 + (Math.abs(wx * 7919 + wz * 1013) % 8);
                    for (int sy = 0; sy < h; sy++) put(chunk, mp, wx, SPAWN_Y + sy, wz, packed);
                }
                // estalactites no teto
                if (isStalactite(wx, wz)) {
                    int h = 2 + (Math.abs(wx * 1009 + wz * 7727) % 6);
                    for (int sy = 0; sy < h; sy++) put(chunk, mp, wx, TETO_Y - 1 - sy, wz, blue);
                }
            }
        }
    }

    private static void put(ChunkAccess chunk, BlockPos.MutableBlockPos mp, int x, int y, int z, BlockState st) {
        if (y < -64 || y > 319) return;
        chunk.setBlockState(mp.set(x, y, z), st, false);
    }

    private boolean isIceSpike(int x, int z) {
        long h = (long)x * 341873128712L + (long)z * 132897987541L;
        return (h ^ (h >> 17)) % 18 == 0;
    }

    private boolean isStalactite(int x, int z) {
        long h = (long)x * 987654321L + (long)z * 123456789L;
        return (h ^ (h >> 13)) % 22 == 0;
    }

    private boolean isBlueIcePatch(int x, int z) {
        long h = (long)x * 1664525L + (long)z * 1013904223L;
        return (h ^ (h >> 9)) % 30 == 0;
    }

    @Override
    public void applyCarvers(WorldGenRegion r, long seed, RandomState rng, BiomeManager bm,
            StructureManager sm, ChunkAccess chunk, GenerationStep.Carving step) {}

    @Override public void spawnOriginalMobs(WorldGenRegion r) {}
    @Override public int getGenDepth() { return 384; }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor ex, Blender bl,
            RandomState rng, StructureManager sm, ChunkAccess chunk) {
        return CompletableFuture.completedFuture(chunk);
    }

    @Override public int getSeaLevel() { return PISO_Y; }
    @Override public int getMinY() { return -64; }

    /**
     * ✅ FIX CRÍTICO: retorna SPAWN_Y (primeiro bloco de ar) para que o
     * sistema de spawn coloque o jogador ACIMA do chão, não dentro dele.
     */
    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types t, LevelHeightAccessor lvl, RandomState rng) {
        return SPAWN_Y; // Y=15: primeiro bloco livre acima da neve
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor lvl, RandomState rng) {
        BlockState[] states = new BlockState[384];
        for (int i = 0; i < 384; i++) {
            int y = -64 + i;
            states[i] = y <= PISO_Y + 4 ? Blocks.PACKED_ICE.defaultBlockState() : Blocks.AIR.defaultBlockState();
        }
        return new NoiseColumn(-64, states);
    }

    @Override public void addDebugScreenInfo(List<String> info, RandomState rng, BlockPos pos) {}
    @Override public void applyBiomeDecoration(WorldGenLevel region, ChunkAccess chunk, StructureManager sm) {}
    @Override public void createStructures(RegistryAccess access, ChunkGeneratorStructureState state,
            StructureManager sm, ChunkAccess chunk, StructureTemplateManager stm) {}
    @Override public void createReferences(WorldGenLevel region, StructureManager sm, ChunkAccess chunk) {}
}
