// [QuestManager.java] — suporte a 101 missões + tokens de Spirit Aura (1 a cada 15 missões)
package com.valdoria.rpg.quest;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.network.EndingCutscenePacket;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.network.OpenFactionPacket;
import com.valdoria.rpg.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
public final class QuestManager {
    private QuestManager() {}
    public static void give(ServerPlayer p, ItemStack st) {
        if (!p.getInventory().add(st)) p.drop(st, false);
    }
    public static int count(ServerPlayer p, String itemId) {
        int n = 0;
        Inventory inv = p.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && itemId.equals(BuiltInRegistries.ITEM.getKey(s.getItem()).toString())) n += s.getCount();
        }
        return n;
    }
    public static boolean isMet(ServerPlayer p, Quest q) {
        return switch (q.type()) {
            case HAVE -> count(p, q.target()) >= q.amount();
            case KILL -> PlayerData.getKills(p, q.target()) >= q.amount();
            case DIM -> p.level().dimension().location().toString().equals(q.target());
            case FACTION -> PlayerData.getFaction(p) != 0;
            case FLAG -> PlayerData.hasFlag(p, q.target());
        };
    }
    public static void tick(ServerPlayer p) {
        QuestFlags.tick(p);
        int done = PlayerData.getCompleted(p);
        boolean changed = false;
        while (done < QuestData.size()) {
            Quest q = QuestData.get(done + 1);
            if (!isMet(p, q)) break;
            complete(p, q);
            done++;
            changed = true;
        }
        if (changed) ModNetwork.sync(p);
    }
    public static void complete(ServerPlayer p, Quest q) {
        PlayerData.setCompleted(p, q.id());
        // Atualiza o castelo imediatamente ao concluir a missão (sem esperar o tick periódico).
        com.valdoria.rpg.event.ServerEvents.checkCastleProgression(p);
        giveLoreBook(p, q.id());
        if (q.reward() != null) q.reward().accept(p);
        p.sendSystemMessage(Component.literal("§6✦ Missão " + q.id() + "/101 concluída: §f" + q.title()));
        p.sendSystemMessage(Component.literal("§7Você recebeu o livro: Saga do Enzo Vol. " + q.id()));
        p.playSound(SoundEvents.PLAYER_LEVELUP, 1.0F, 1.0F);

        // ===== SPIRIT AURA: 1 token a cada 15 missões concluídas =====
        if (q.id() % 15 == 0) {
            PlayerData.addAuraToken(p);
            int newLevel = q.id() / 15; // 1–6; missão 101 → 7 (Onipotente)
            if (newLevel > PlayerData.getAuraLevel(p)) {
                // notifica que há novo nível disponível para ser desbloqueado com o token
                String auraName = PlayerData.getAuraName(newLevel);
                p.sendSystemMessage(Component.literal("§d✦ Token de Aura obtido! Use §lShift+G§r§d para desbloquear " + auraName + "§d."));
                p.playSound(SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 1.5F);
            } else {
                p.sendSystemMessage(Component.literal("§d✦ Token de Aura Spirit obtido! Pressione §lShift+G§r§d para trocar de aura."));
                p.playSound(SoundEvents.ENCHANTMENT_TABLE_USE, 1.0F, 1.5F);
            }
        }
        // Missão 101 → desbloqueia Aura Onipotente + dispara cutscene final
        if (q.id() == 101) {
            PlayerData.addAuraToken(p);
            p.sendSystemMessage(Component.literal("§0§l✦ AURA ONIPOTENTE DESBLOQUEADA ✦"));
            p.sendSystemMessage(Component.literal("§7Pressione §lShift+G§r§7 para despertar o poder absoluto."));
            p.playSound(SoundEvents.WITHER_SPAWN, 0.6F, 0.5F);
            // Aguarda 60 ticks (3 s) para o cliente processar antes de abrir a cutscene
            // Usamos uma thread agendada simples via servidor
            net.minecraft.server.MinecraftServer srv = p.getServer();
            if (srv != null) {
                final ServerPlayer fp = p;
                // scheduleTask garante execução na thread do servidor após N ticks
                new java.util.Timer(true).schedule(new java.util.TimerTask() {
                    @Override public void run() {
                        srv.execute(() -> ModNetwork.sendTo(fp, new EndingCutscenePacket()));
                    }
                }, 3000L); // 3 segundos
            }
        }

        if (q.id() % 10 == 0 && q.id() < 101) {
            int nextAct = q.id() / 10 + 1;
            if (nextAct <= QuestData.ACT_NAMES.length) {
                p.sendSystemMessage(Component.literal("§e§l" + QuestData.ACT_NAMES[nextAct - 1] + " começa!"));
            }
        }
        if (q.id() == 48) {
            PlayerData.setFlag(p, "malachar_spawned");
            p.sendSystemMessage(Component.literal("§c§lMALACHAR DESPERTOU. Derrote-o."));
        }
        if (q.id() == 49) {
            openNiveriaPortal(p);
        }
        if (q.id() == 50) {
            p.sendSystemMessage(Component.literal("§b❄ Você chegou a Nivéria."));
        }
        if (q.id() == 51) {
            openNiveriaPortal(p);
        }
        if (q.id() == 10 && PlayerData.getFaction(p) == 0) {
            ModNetwork.sendTo(p, new OpenFactionPacket());
        }
        // ===== CUTSCENE FINAL — missão 101 =====
        if (q.id() == 101) {
            p.sendSystemMessage(Component.literal("§6§l✦ A SAGA DO ENZO ESTÁ COMPLETA! ✦"));
            ModNetwork.sendTo(p, new com.valdoria.rpg.network.EndingCutscenePacket());
        }
    }
    public static void openNiveriaPortal(ServerPlayer p) {
        ServerLevel overworld = p.getServer().getLevel(Level.OVERWORLD);
        if (overworld == null) return;
        BlockPos pos = overworld.getSharedSpawnPos();
        overworld.setBlockAndUpdate(pos, ModBlocks.PORTAL_NIVERIA.get().defaultBlockState());
        overworld.setBlockAndUpdate(pos.above(), ModBlocks.PORTAL_NIVERIA.get().defaultBlockState());
        p.sendSystemMessage(Component.literal("§bO Portal de Nivéria se abriu no Castelo!"));
    }
    public static void giveLoreBook(ServerPlayer player, int questId) {
        if (questId < 1 || questId > QuestData.size()) return;
        give(player, makeBook(QuestData.get(questId)));
    }
    public static ItemStack makeBook(Quest q) {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", "Saga do Enzo Vol. " + q.id());
        tag.putString("author", "Rei Aldric");
        ListTag pages = new ListTag();
        pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(
                QuestData.actName(q.act()) + "\n\nVol. " + q.id() + ": " + q.title()))));
        for (String chunk : paginate(q.lore(), 200)) {
            pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(chunk))));
        }
        tag.put("pages", pages);
        tag.putBoolean("resolved", true);
        return book;
    }
    private static List<String> paginate(String text, int max) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : text.split(" ")) {
            if (cur.length() > 0 && cur.length() + w.length() + 1 > max) { out.add(cur.toString()); cur.setLength(0); }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }
}
