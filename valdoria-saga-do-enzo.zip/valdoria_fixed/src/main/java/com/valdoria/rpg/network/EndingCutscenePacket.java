package com.valdoria.rpg.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Enviado pelo servidor ao cliente quando a missão 101 é concluída.
 * Aciona a tela de cutscene final (EndingCutsceneScreen).
 */
public class EndingCutscenePacket {
    public EndingCutscenePacket() {}

    public static void encode(EndingCutscenePacket p, FriendlyByteBuf buf) {}
    public static EndingCutscenePacket decode(FriendlyByteBuf buf) { return new EndingCutscenePacket(); }

    public static void handle(EndingCutscenePacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () ->
                net.minecraft.client.Minecraft.getInstance().setScreen(
                    new com.valdoria.rpg.client.screen.EndingCutsceneScreen())
            )
        );
        ctx.get().setPacketHandled(true);
    }
}
