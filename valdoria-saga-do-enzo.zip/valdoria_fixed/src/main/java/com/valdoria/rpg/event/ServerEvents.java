// [ServerEvents.java] — classes + Rei do Gelo + facção + Spirit Aura buffs
// ATUALIZADO: livros de lore do castelo por estágio + mensagens descritivas
package com.valdoria.rpg.event;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.entity.MalacharEntity;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.network.OpenFactionPacket;
import com.valdoria.rpg.quest.QuestManager;
import com.valdoria.rpg.registry.ModItems;
import com.valdoria.rpg.world.CastleBuilder;
import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import com.valdoria.rpg.block.PortalNiveriaBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID)
public class ServerEvents {

    // =========================================================================
    //  DADOS DE LORE DE CADA ESTÁGIO DO CASTELO
    //  Paralelo exato ao CastleBuilder: 16 estágios, nível 5 → 80
    // =========================================================================
    private static final String[] CASTLE_STAGE_TITLE = {
        "",  // índice 0 não usado
        "O Alicerce de Valdoria",           // estágio 1  — lv 5
        "As Muralhas se Erguem",            // estágio 2  — lv 10
        "Torres dos Vigias",                // estágio 3  — lv 15
        "A Nave da Catedral",               // estágio 4  — lv 20
        "O Grande Salão",                   // estágio 5  — lv 25
        "A Câmara do Conselho",             // estágio 6  — lv 30
        "Torres Frontais Imponentes",       // estágio 7  — lv 35
        "Torres Traseiras da Guarda",       // estágio 8  — lv 40
        "A Biblioteca Sagrada",             // estágio 9  — lv 45
        "A Sala do Trono Final",            // estágio 10 — lv 50
        "A Torre Central Suprema",          // estágio 11 — lv 55
        "A Ala de Nivéria",                 // estágio 12 — lv 60
        "O Pátio e a Capelinha",            // estágio 13 — lv 65
        "A Sala de Treino e o Estábulo",    // estágio 14 — lv 70
        "Decoração e Iluminação",           // estágio 15 — lv 75
        "O Castelo Completo de Valdoria",   // estágio 16 — lv 80
    };

    private static final String[] CASTLE_STAGE_LORE = {
        "",  // índice 0 não usado

        // Estágio 1 — lv 5
        "Aldric cravou a Pedra de Fundação no vale. 'Todo reino nasce de uma pedra, " +
        "Enzo. Esta é a nossa.' O terreno foi nivelado, o solo consagrado. " +
        "Setenta blocos de terra cederam lugar ao piso de pedra de Valdoria. " +
        "A saga começou aqui.",

        // Estágio 2 — lv 10
        "As muralhas de pedra lapidada cresceram ao redor do terreno sagrado. " +
        "Quarenta e oito blocos de cada lado, oito de altura, coroadas de ameias. " +
        "Um fosso d'água circunda tudo — e uma ponte de carvalho cruza o sul. " +
        "'Um reino sem muros é apenas uma promessa', disse o rei.",

        // Estágio 3 — lv 15
        "Quatro torres góticas surgiram nos cantos da muralha. " +
        "Pedra lascada, madeira de carvalho negro e agulhas de deepslate pontilham o horizonte. " +
        "Vigias ocupam cada posto. 'Que o inimigo saiba: Valdoria tem olhos em todas as direções.'",

        // Estágio 4 — lv 20
        "A nave central se ergueu como uma catedral: vinte e oito blocos de largura, " +
        "trinta e seis de comprimento, quarenta e oito de altura. " +
        "Quatro andares com pisos de madeira escura, escadaria em espiral, " +
        "vitral dourado e roxo nas janelas, telhado em V de deepslate. " +
        "Valdoria ganhou coração e pulmões.",

        // Estágio 5 — lv 25
        "O térreo virou o Grande Salão. Tapete vermelho do trono à entrada, " +
        "mesas de ofício nos cantos, colunas de pedra lapidada flanqueando o corredor central. " +
        "O primeiro andar recebeu câmaras dos guardas, camas e baús. " +
        "Lanternas penduradas iluminam a noite como constelações internas.",

        // Estágio 6 — lv 30
        "No segundo andar, a Câmara do Conselho foi inaugurada. " +
        "Uma mesa redonda de madeira, oito cadeiras ao redor. " +
        "O trono dourado do rei enfrenta a janela sul. " +
        "Um beacon sobre uma plataforma de ouro pulsa no centro — " +
        "símbolo de que o poder de Valdoria não se apaga.",

        // Estágio 7 — lv 35
        "Duas torres imensas flanqueiam o portão sul: raio de quatro blocos, " +
        "trinta e oito andares de altura, agulhas de deepslate que tocam as nuvens. " +
        "Uma passarela de carvalho conecta as torres à nave no nível doze. " +
        "Um arco de granito polido marca a entrada do reino. " +
        "De longe, Valdoria já se parece com uma catedral de outro mundo.",

        // Estágio 8 — lv 40
        "Duas torres traseiras subiram ao norte, ainda mais altas que as frontais: " +
        "quarenta e dois blocos de corpo e vinte de spire. " +
        "Elas guardam a entrada do pátio norte e conectam ao segundo andar por passarelas. " +
        "Nenhum exército atravessa Valdoria por trás sem ser visto.",

        // Estágio 9 — lv 45
        "O terceiro andar foi consagrado à sabedoria. " +
        "Paredes inteiras de estantes em todos os lados. " +
        "Mesa de encantamento no centro, rodeada de livros. " +
        "Mesas de estudo espalhadas, baús com pergaminhos de missão. " +
        "Aldric chamou este lugar de 'O Arquivo Vivo de Valdoria'.",

        // Estágio 10 — lv 50
        "O quarto andar abriga a Sala do Trono Final — de deepslate lapidado, " +
        "vitral multicolorido no teto, tapete roxo do trono à entrada. " +
        "O Trono Supremo de ouro maciço domina o norte da sala, " +
        "beacon pulsando acima dele. É aqui que o destino de Valdoria será decidido. " +
        "É aqui que o Escolhido enfrentará o que vier.",

        // Estágio 11 — lv 55
        "Do centro da nave emergiu a Torre Central Suprema. " +
        "Cinquenta blocos de corpo, vinte e cinco de spire: " +
        "setenta e cinco blocos acima do telo, visível a centenas de blocos de distância. " +
        "Sua lanterna no pico nunca se apaga. " +
        "'Enquanto essa luz brilhar', disse Aldric, 'Valdoria existe.'",

        // Estágio 12 — lv 60
        "A ala norte foi construída em honra a Nivéria. " +
        "Paredes de gelo compactado e pedra, piso de blue ice, neve ao redor. " +
        "O Portal de Nivéria foi erguido: frame de packed ice, interior de cristal azul, " +
        "beacon acima, pirâmide de ouro abaixo. " +
        "A passagem entre mundos está pronta. O frio eterno aguarda.",

        // Estágio 13 — lv 65
        "O pátio sul foi pavimentado em padrão xadrez de andesita e granito. " +
        "Uma fonte iluminada por lanterna de luz do mar pulsa no centro. " +
        "Quatro árvores decorativas marcam os cantos. " +
        "A leste, uma capelinha com vitral dourado e roxo abriga um altar sagrado. " +
        "O jardim norte recebe as torres traseiras com pinheiros congelados.",

        // Estágio 14 — lv 70
        "A ala oeste virou sala de treino: alvos, mesa de ferreiro, " +
        "bigorna, mesa de crafting e caixa de equipamentos. " +
        "A ala leste recebeu o estábulo de carvalho com divisórias, " +
        "feno no teto e lanternas internas. " +
        "Valdoria agora tem força para treinar e recursos para sustentar seus cavaleiros.",

        // Estágio 15 — lv 75
        "Lanternas foram instaladas ao longo de todo o topo das muralhas — " +
        "uma a cada três blocos, nos quatro lados. " +
        "Contrafotes de deepslate reforçam as paredes da nave. " +
        "Passarelas de carvalho percorrem o interior das muralhas. " +
        "Torres medianas surgiram no meio de cada lado. " +
        "Bandeiras vermelhas e amarelas tremulam nos picos das torres frontais.",

        // Estágio 16 — lv 80
        "A bandeira de Valdoria, em vermelho, amarelo e ouro, " +
        "foi fixada no pico absoluto da Torre Central Suprema. " +
        "Estátuas de guardiões de ferro e ouro vigiam os quatro cantos internos. " +
        "O pátio sul recebeu flores. O gelo ao redor do portal de Nivéria se cristalizou. " +
        "Relíquias de ferro decoram o salão do trono. " +
        "O castelo está completo. A saga de Valdoria, enfim, tem uma casa digna.",
    };

    // Mensagens de chat curtas que aparecem no jogo ao evoluir o castelo
    private static final String[] CASTLE_STAGE_MSG = {
        "",
        "§e🏰 §fO alicerce foi plantado. Valdoria tem fundação!",
        "§e🏰 §fAs muralhas e o fosso cercam o reino. O portão sul está aberto.",
        "§e🏰 §fQuatro torres góticas guardam os cantos. Ninguém passa despercebido.",
        "§e🏰 §fA nave da catedral se ergueu! §74 andares, vitral, escadaria interna.",
        "§e🏰 §fO Grande Salão e as câmaras dos guardas foram inaugurados.",
        "§e🏰 §fA Câmara do Conselho está pronta. O trono de ouro espera o rei.",
        "§e🏰 §f§lDuas torres imensas flanqueiam o portão sul!§r §7O skyline de Valdoria nunca mais será o mesmo.",
        "§e🏰 §fTorres traseiras altas guardam o norte. Passarelas conectam os andares.",
        "§e🏰 §fA Biblioteca Sagrada foi aberta no 3º andar. O conhecimento é poder.",
        "§e🏰 §f§lA Sala do Trono Final está pronta.§r §7O destino de Valdoria se decide aqui.",
        "§e🏰 §f§lA Torre Central Suprema toca as nuvens!§r §775 blocos de altura.",
        "§e🏰 §f❄ A Ala de Nivéria e o Portal de Gelo foram construídos a norte.",
        "§e🏰 §fO Pátio Sul, a Fonte e a Capelinha foram inaugurados.",
        "§e🏰 §fSala de treino e estábulo prontos. Valdoria se prepara para a guerra.",
        "§e🏰 §fIluminação e torres medianas completam as muralhas. Bandeiras ao vento!",
        "§6§l✦ O CASTELO DE VALDORIA ESTÁ COMPLETO! ✦§r §eEstágio 16/16 — Nível 80.",
    };

    // =========================================================================
    //  LOGIN
    // =========================================================================
    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (!PlayerData.hasFlag(sp, "starter")) {
            PlayerData.setFlag(sp, "starter");
            PlayerData.setMana(sp, PlayerData.MAX_MANA);
            QuestManager.give(sp, new ItemStack(ModItems.FOUNDATION_STONE.get()));
            sp.sendSystemMessage(Component.literal(
                    "§6Bem-vindo a Valdoria, Enzo. Use /valdoria quest. P=Perfil M=Mapa H=HUD C=Classe G=Aura Spirit"));
        }
        if (!PlayerData.hasFlag(sp, "guia_sino")) {
            PlayerData.setFlag(sp, "guia_sino");
            QuestManager.give(sp, new ItemStack(ModItems.SINO_GUIA.get()));
            PlayerData.root(sp).putBoolean("guia_ativo", true);
        }
        ModNetwork.sync(sp);

        if (PlayerData.getCompleted(sp) >= 10 && PlayerData.getFaction(sp) == 0) {
            ModNetwork.sendTo(sp, new OpenFactionPacket());
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        var old = e.getOriginal().getPersistentData();
        if (old.contains(Player.PERSISTED_NBT_TAG, 10)) {
            e.getEntity().getPersistentData().put(Player.PERSISTED_NBT_TAG,
                    old.getCompound(Player.PERSISTED_NBT_TAG).copy());
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ModNetwork.sync(sp);
    }

    // =========================================================================
    //  TICK PRINCIPAL
    // =========================================================================
    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer sp)) return;

        if (sp.tickCount % 20 == 0) {
            PlayerData.tickWhirlpool(sp);
            com.valdoria.rpg.event.AuraPowerHandler.tickPowerCooldown(sp);
            // Regen de mana (roda ANTES do drain para não cancelar)
            float manaRegen = PlayerData.getFaction(sp) == 1 ? 3.0F : 2.0F;
            if (PlayerData.getPlayerClass(sp) == PlayerData.CLASS_MAGO) manaRegen *= 1.5F;
            // Sem regen se aura ativa (a aura drena mais do que regenera)
            if (!PlayerData.isAuraActive(sp)) {
                PlayerData.addMana(sp, manaRegen);
            }
            // Drenagem de mana da aura: 2 mana/seg quando ativa (tick separado do regen)
            if (PlayerData.isAuraActive(sp) && PlayerData.getAuraEquipped(sp) > 0) {
                float mana = PlayerData.getMana(sp);
                if (mana <= 2.0F) {
                    // Desativa aura automaticamente se mana acabou
                    PlayerData.setAuraActive(sp, false);
                    sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§7✦ Aura desativada — sem mana!"));
                } else {
                    PlayerData.addMana(sp, -2.0F); // -2 mana/seg
                }
            }
            QuestManager.tick(sp);
            ModNetwork.sync(sp);
            applyNiveriaDebuffs(sp);
            checkMalacharProximity(sp);
            checkFactionPending(sp);
        }
        if (sp.tickCount % 5 == 0)    com.valdoria.rpg.quest.EspTracker.send(sp);
        if (sp.tickCount % 100 == 20) com.valdoria.rpg.entity.GuiaAldric.ensure(sp);
        if (sp.tickCount % 100 == 50) com.valdoria.rpg.world.NiveriaMobs.tick(sp);
        if (sp.tickCount % 1200 == 600) horde(sp);
        if (sp.tickCount % 200 == 0)  checkCastleProgression(sp);
        if (sp.tickCount % 200 == 100) checkNiveriaHunger(sp);
        if (sp.tickCount % 20 == 10) {
            applyClassPassives(sp);
            applyAuraBuffs(sp);
        }
    }

    // =========================================================================
    //  PROGRESSÃO DO CASTELO — com livro de lore + mensagem descritiva
    // =========================================================================
    private static void checkCastleProgression(ServerPlayer sp) {
        int level = PlayerData.getLevel(sp);
        // Estágio sobe a cada 5 níveis: lv5→1, lv10→2 … lv80→16
        int stage = Math.min(level / 5, 16);
        if (stage < 1 || PlayerData.hasFlag(sp, "castle_stage_" + stage)) return;

        ServerLevel overworld = sp.getServer().getLevel(Level.OVERWORLD);
        if (overworld == null) return;

        // Marcar todos os estágios anteriores como concluídos (caso o jogador tenha pulado níveis)
        for (int s = 1; s <= stage; s++) {
            PlayerData.setFlag(sp, "castle_stage_" + s);
        }

        // Construir o castelo no estágio atual
        CastleBuilder.build(overworld, stage);

        // ── A) Mensagem descritiva no chat ──────────────────────────────────
        sp.sendSystemMessage(Component.literal(CASTLE_STAGE_MSG[stage]));
        sp.sendSystemMessage(Component.literal(
                "§7📖 Você recebeu: §fCrônicas do Castelo Vol. " + stage));
        sp.playSound(net.minecraft.sounds.SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 0.6F, 1.0F);

        // ── B) Livro de lore do castelo ──────────────────────────────────────
        QuestManager.give(sp, makeCastleBook(stage));
    }

    /**
     * Gera um Written Book narrando o estágio do castelo.
     * Título: "Crônicas do Castelo Vol. X"
     * Autor: Rei Aldric
     * Conteúdo: lore descritivo do que foi construído naquele estágio
     */
    private static ItemStack makeCastleBook(int stage) {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();

        tag.putString("title",  "Crônicas do Castelo Vol. " + stage);
        tag.putString("author", "Rei Aldric");

        ListTag pages = new ListTag();

        // Página 1 — cabeçalho com estágio e nível
        String header = "§l" + CASTLE_STAGE_TITLE[stage] + "\n\n"
                      + "§oEstágio " + stage + "/16\n"
                      + "§oNível " + (stage * 5) + "\n\n"
                      + "§r— Crônicas de Valdoria —";
        pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(header))));

        // Páginas seguintes — lore paginado a 230 chars por página
        for (String chunk : paginate(CASTLE_STAGE_LORE[stage], 230)) {
            pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(chunk))));
        }

        // Última página — nota de Aldric
        String footer = "§o\"Cada pedra que você posicionou, Enzo, foi uma palavra na história " +
                        "de Valdoria. Continue. O castelo aguarda sua forma final.\"\n\n" +
                        "§r— Aldric, Rei de Valdoria";
        pages.add(StringTag.valueOf(Component.Serializer.toJson(Component.literal(footer))));

        tag.put("pages", pages);
        tag.putBoolean("resolved", true);
        return book;
    }

    private static java.util.List<String> paginate(String text, int max) {
        java.util.List<String> out = new java.util.ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String w : text.split(" ")) {
            if (cur.length() > 0 && cur.length() + w.length() + 1 > max) {
                out.add(cur.toString());
                cur.setLength(0);
            }
            if (cur.length() > 0) cur.append(' ');
            cur.append(w);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    // =========================================================================
    //  SPIRIT AURA — buffs
    // =========================================================================
    private static void applyAuraBuffs(ServerPlayer sp) {
        if (!PlayerData.isAuraActive(sp)) return;
        int lv = PlayerData.getAuraEquipped(sp);
        if (lv <= 0) return;

        final int DUR = 30;

        switch (lv) {
            case PlayerData.AURA_VERDANT -> {
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, DUR, 0, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,   DUR, 0, true, false));
            }
            case PlayerData.AURA_RADIANCE -> {
                sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, DUR, 0, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,   DUR, 0, true, false));
            }
            case PlayerData.AURA_EMBER -> {
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, DUR, 0, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, DUR, 0, true, false));
            }
            case PlayerData.AURA_CRIMSON -> {
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,     DUR, 1, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,   DUR, 0, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION,     DUR, 0, true, false));
            }
            case PlayerData.AURA_ARCANE -> {
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,      DUR, 1, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, DUR, 1, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,        DUR, 1, true, false));
            }
            case PlayerData.AURA_GLACIAL -> {
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,      DUR, 1, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, DUR, 1, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,    DUR, 1, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,      DUR, 0, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION,      DUR, 1, true, false));
            }
            case PlayerData.AURA_OMNIPOTENT -> {
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,      DUR, 2, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, DUR, 3, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED,    DUR, 2, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION,      DUR, 2, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.ABSORPTION,        DUR, 3, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,      DUR, 0, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE,   DUR, 0, true, false));
                sp.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING,   DUR, 0, true, false));
                if (sp.getHealth() < sp.getMaxHealth()) sp.heal(0.5F);
            }
        }
    }

    // =========================================================================
    //  FACÇÃO
    // =========================================================================
    private static void checkFactionPending(ServerPlayer sp) {
        if (PlayerData.getCompleted(sp) < 10) return;
        if (PlayerData.getFaction(sp) != 0) return;
        if (sp.tickCount % 100 == 0) {
            ModNetwork.sendTo(sp, new OpenFactionPacket());
            sp.sendSystemMessage(Component.literal(
                    "§e⚑ Você completou 10 missões! Escolha sua facção: §bAnjo §7ou §cDemônio"));
        }
    }

    // =========================================================================
    //  CLASSE PASSIVA
    // =========================================================================
    private static void applyClassPassives(ServerPlayer sp) {
        int cls = PlayerData.getPlayerClass(sp);
        if (cls == PlayerData.CLASS_ARQUEIRO) {
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 25, 0, true, false));
        }
        if (cls == PlayerData.CLASS_GUERREIRO) {
            if (sp.getHealth() > 5 && sp.getHealth() < sp.getMaxHealth()) {
                sp.heal(0.05F);
            }
        }
    }

    // =========================================================================
    //  NIVÉRIA — debuffs, fome, estruturas
    // =========================================================================
    private static void applyNiveriaDebuffs(ServerPlayer sp) {
        if (!sp.level().dimension().equals(NiveriaDimension.NIVERIA)) return;
        boolean isIceKing = PlayerData.getPlayerClass(sp) == PlayerData.CLASS_REI_GELO;
        int dur = isIceKing ? 36 : 60;
        int auraLv = PlayerData.getAuraEquipped(sp);
        if (PlayerData.isAuraActive(sp) && (auraLv == PlayerData.AURA_GLACIAL || auraLv == PlayerData.AURA_OMNIPOTENT)) return;

        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, dur, 0, true, false));
        sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,          dur, 0, true, false));

        if (!PlayerData.hasFlag(sp, "niveria_structures")) {
            PlayerData.setFlag(sp, "niveria_structures");
            com.valdoria.rpg.world.NiveriaStructures.ensureBuilt(sp.serverLevel());
        }
        if (!PlayerData.hasFlag(sp, "portal_niveria_entered")) {
            PlayerData.setFlag(sp, "portal_niveria_entered");
            String msg = isIceKing
                    ? "§b❄ Você entrou em Nivéria. Como Rei do Gelo, o frio te afeta apenas 40%."
                    : "§b❄ Você entrou em Nivéria. A sala de neve eterna o aguarda...";
            sp.sendSystemMessage(Component.literal(msg));
            sp.sendSystemMessage(Component.literal(
                    "§7[Nivéria é uma sala GIGANTE e FECHADA de gelo. Explore com cuidado!]"));
            sp.sendSystemMessage(Component.literal(
                    "§e[Portal de volta: bloco brilhante no centro do spawn (0,0). Use §b/valdoria back §ese perdido!]"));
        }
    }

    private static void checkNiveriaHunger(ServerPlayer sp) {
        if (!sp.level().dimension().equals(NiveriaDimension.NIVERIA)) return;
        boolean isIceKing = PlayerData.getPlayerClass(sp) == PlayerData.CLASS_REI_GELO;
        if (PlayerData.isAuraActive(sp) && PlayerData.getAuraEquipped(sp) == PlayerData.AURA_OMNIPOTENT) return;
        float exhaustion = isIceKing ? 1.2F : 2.0F;
        sp.getFoodData().addExhaustion(exhaustion);
    }

    // =========================================================================
    //  MALACHAR — spawn próximo ao spawn
    // =========================================================================
    private static void checkMalacharProximity(ServerPlayer sp) {
        if (sp.level().dimension() != Level.OVERWORLD) return;
        if (PlayerData.getCompleted(sp) != 49) return;
        if (PlayerData.hasFlag(sp, "malachar_spawned")) return;
        BlockPos spawn = sp.serverLevel().getSharedSpawnPos();
        double dist = sp.distanceToSqr(spawn.getX(), spawn.getY(), spawn.getZ());
        if (dist < 30.0D * 30.0D) {
            MalacharEntity.spawnNear(sp);
            PlayerData.setFlag(sp, "malachar_spawned");
        }
    }

    // =========================================================================
    //  HORDE
    // =========================================================================
    private static void horde(ServerPlayer sp) {
        int done = PlayerData.getCompleted(sp);
        if (done < 11 || done >= 49) return;
        ServerLevel lvl = sp.serverLevel();
        int n = 2 + done / 10;
        for (int i = 0; i < n; i++) {
            double x = sp.getX() + (lvl.random.nextDouble() - 0.5D) * 24.0D;
            double z = sp.getZ() + (lvl.random.nextDouble() - 0.5D) * 24.0D;
            Mob mob;
            if (lvl.dimension() == Level.NETHER && done >= 20) {
                Piglin pg = EntityType.PIGLIN.create(lvl);
                if (pg == null) continue;
                pg.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_SWORD));
                mob = pg;
            } else if (i % 2 == 0) {
                mob = EntityType.ZOMBIE.create(lvl);
            } else {
                mob = EntityType.SKELETON.create(lvl);
            }
            if (mob == null) continue;
            mob.moveTo(x, sp.getY(), z, lvl.random.nextFloat() * 360.0F, 0.0F);
            if (!lvl.noCollision(mob)) continue;
            mob.setTarget(sp);
            lvl.addFreshEntity(mob);
        }
    }

    // =========================================================================
    //  EVENTOS DE MORTE E DANO
    // =========================================================================
    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer sp) {
            ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(e.getEntity().getType());
            if (key != null) PlayerData.addKill(sp, key.toString());
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer sp)) return;
        int cls = PlayerData.getPlayerClass(sp);
        if (PlayerData.getFaction(sp) == 2)   e.setAmount(e.getAmount() * 1.15F);
        if (cls == PlayerData.CLASS_MAGO)      e.setAmount(e.getAmount() * 1.10F);
        if (cls == PlayerData.CLASS_REI_GELO)  e.setAmount(e.getAmount() * 1.08F);
    }

    // =========================================================================
    //  QUEST SECRETA — "Chave Secreta"
    //  Encosta a Chave Glacial no PortalNiveriaBlock (desativado) para ativá-lo
    //  Essa quest NUNCA aparece no contador de missões — é um evento secreto.
    // =========================================================================
    @SubscribeEvent
    public static void onRightClickBlock(PlayerInteractEvent.RightClickBlock e) {
        if (e.getLevel().isClientSide()) return;
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;

        // Checa se o bloco clicado é o Portal de Nivéria
        BlockPos pos = e.getPos();
        if (!(e.getLevel().getBlockState(pos).getBlock() instanceof PortalNiveriaBlock)) return;

        // Verifica se o jogador tem a Chave Glacial na mão
        ItemStack held = e.getItemStack();
        boolean hasKey = !held.isEmpty() &&
                net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(held.getItem()) != null &&
                net.minecraftforge.registries.ForgeRegistries.ITEMS.getKey(held.getItem()).toString()
                        .equals("valdorianrpg:chave_glacial");

        if (!hasKey) return;
        // Só funciona uma vez por portal (ou pode ser repetível – mantemos repetível pois é "mágico")
        if (PlayerData.hasFlag(sp, "chave_secreta_usada")) return;

        // ---- Marcar como usada e mostrar quest ----
        PlayerData.setFlag(sp, "chave_secreta_usada");
        e.setCanceled(true); // cancela uso normal do item

        sp.sendSystemMessage(Component.literal(""));
        sp.sendSystemMessage(Component.literal("§5✦ MISSÃO SECRETA: §fChave Secreta"));
        sp.sendSystemMessage(Component.literal("§7A Chave Glacial vibrou ao toque do portal dormido."));
        sp.sendSystemMessage(Component.literal("§b❄ O portal de Nivéria desperta com seu poder!"));
        sp.sendSystemMessage(Component.literal(""));

        // ---- Efeitos visuais: raios de DENTRO do portal (não do céu) ----
        activatePortalWithPower(sp.serverLevel(), pos, sp);
    }

    /**
     * Dispara os raios de poder de DENTRO do portal.
     * Os raios são spawned nas bordas internas do frame, simulando
     * energia vindo de dentro do portal para fora.
     */
    private static void activatePortalWithPower(ServerLevel lvl, BlockPos portalPos, ServerPlayer sp) {
        double cx = portalPos.getX() + 0.5;
        double cy = portalPos.getY() + 0.5;
        double cz = portalPos.getZ() + 0.5;

        // Raios em posições ao redor do portal (simulando raios saindo de dentro)
        double[][] boltOffsets = {
            {0, 0, 0},   // centro
            {1, 0, 0},   // leste
            {-1, 0, 0},  // oeste
            {0, 0, 1},   // sul
            {0, 0, -1},  // norte
            {1, 0, 1},
            {-1, 0, -1},
        };

        for (double[] off : boltOffsets) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(lvl);
            if (bolt == null) continue;
            bolt.moveTo(cx + off[0], cy + off[1], cz + off[2]);
            bolt.setVisualOnly(false); // raio COM dano/som
            lvl.addFreshEntity(bolt);
        }

        // Partículas de portal/poder saindo do centro em todas as direções
        lvl.sendParticles(ParticleTypes.PORTAL,
                cx, cy, cz, 150, 1.5, 1.5, 1.5, 0.3);
        lvl.sendParticles(ParticleTypes.END_ROD,
                cx, cy, cz, 80, 1.0, 1.5, 1.0, 0.5);
        lvl.sendParticles(ParticleTypes.DRAGON_BREATH,
                cx, cy, cz, 60, 0.5, 1.0, 0.5, 0.2);

        // Sons épicos
        lvl.playSound(null, portalPos,
                net.minecraft.sounds.SoundEvents.END_PORTAL_SPAWN,
                net.minecraft.sounds.SoundSource.AMBIENT, 1.5F, 0.8F);
        lvl.playSound(null, portalPos,
                net.minecraft.sounds.SoundEvents.LIGHTNING_BOLT_THUNDER,
                net.minecraft.sounds.SoundSource.WEATHER, 1.0F, 1.2F);

        // Mensagem de conclusão após o efeito
        sp.sendSystemMessage(Component.literal("§5§l✦ CHAVE SECRETA COMPLETADA! ✦"));
        sp.sendSystemMessage(Component.literal("§bO portal de Nivéria foi ativado com o poder da Chave Glacial!"));
        sp.sendSystemMessage(Component.literal("§7(Esta missão secreta não conta no total de 101.)"));
        sp.playSound(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, 1.0F, 0.5F);
    }
}
