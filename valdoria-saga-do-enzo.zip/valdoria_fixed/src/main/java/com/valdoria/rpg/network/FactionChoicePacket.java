package com.valdoria.rpg.network;

import com.valdoria.rpg.data.PlayerData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraftforge.network.NetworkEvent;

public class FactionChoicePacket {
    private final int faction;

    public FactionChoicePacket(int faction) { this.faction = faction; }

    public static void encode(FactionChoicePacket m, FriendlyByteBuf buf) { buf.writeInt(m.faction); }
    public static FactionChoicePacket decode(FriendlyByteBuf buf) { return new FactionChoicePacket(buf.readInt()); }

    public void handle(NetworkEvent.Context ctx) {
        ServerPlayer sp = ctx.getSender();
        if (sp == null || (faction != 1 && faction != 2)) return;
        // Só bloqueia se já escolheu facção antes
        if (PlayerData.getFaction(sp) != 0) return;
        PlayerData.setFaction(sp, faction);
        sp.sendSystemMessage(Component.literal(faction == 1
                ? "§bVocê escolheu a LUZ. Seu mana regenera mais rápido."
                : "§cVocê escolheu as TREVAS. Seus golpes causam +15% de dano."));
        sp.playSound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
        ModNetwork.sync(sp);
    }
}
