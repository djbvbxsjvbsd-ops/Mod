package com.valdoria.rpg.client.renderer;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.entity.GuiaAldric;
import net.minecraft.client.model.VillagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * Renderer do NPC Guia Aldric — usa modelo de Villager com textura própria.
 * Textura esperada: assets/valdorianrpg/textures/entity/guia_aldric.png
 */
public class GuiaRenderer extends MobRenderer<GuiaAldric, VillagerModel<GuiaAldric>> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ValdoriaMod.MODID, "textures/entity/guia_aldric.png");

    public GuiaRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new VillagerModel<>(ctx.bakeLayer(ModelLayers.VILLAGER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(GuiaAldric entity) {
        return TEXTURE;
    }
}
