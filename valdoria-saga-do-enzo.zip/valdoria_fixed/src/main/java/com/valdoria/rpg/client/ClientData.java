package com.valdoria.rpg.client;

import com.valdoria.rpg.data.PlayerData;
import java.util.List;

/** Dados sincronizados do servidor mantidos no lado cliente. Thread-safe por ser só lido na main thread. */
public final class ClientData {
    private ClientData() {}

    public static int    faction    = 0;
    public static int    completed  = 0;
    public static float  mana       = 100F;
    public static float  maxMana    = 100F;
    public static boolean hudVisible = true;
    public static boolean inNiveria  = false;
    public static int    glacialFrags = 0;

    // fragmentosGlaciais — alias usado por HudOverlay e ProfileScreen
    public static int    fragmentosGlaciais = 0;

    // Classe
    public static int playerClass  = 0;
    public static int classChanges = 0;
    /** Cooldown do Redemoinho em ticks — acessado como whirlpoolCooldown por HudOverlay/ProfileScreen. */
    public static int whirlpoolCooldown = 0;

    // Spirit Aura
    public static int     auraTokens   = 0;
    public static int     auraLevel    = 0;  // nível máx desbloqueado
    public static int     auraEquipped = 0;  // nível atualmente equipado
    public static boolean auraActive   = false;

    // ESP quest
    public static int    espKind = 0;
    public static String espLabel = "";
    public static List<float[]> espPts = List.of();
    public static int    questTargetType = 0;
    public static String questTarget = "";   // usado por QuestEsp
    public static int    questId = 0;        // usado por QuestEsp

    // ---- update helpers ----

    public static void update(int f, int c, float m, float mm) {
        faction = f; completed = c; mana = m; maxMana = mm;
    }

    public static void updateClass(int cls, int cc, int wcd) {
        playerClass = cls; classChanges = cc; whirlpoolCooldown = wcd;
    }

    public static void updateAura(int tokens, int level, int equipped, boolean active) {
        auraTokens = tokens; auraLevel = level; auraEquipped = equipped; auraActive = active;
    }

    public static void updateNiveria(boolean niveria, int frags) {
        inNiveria = niveria;
        glacialFrags = frags;
        fragmentosGlaciais = frags;
    }

    public static void updateQuestTarget(int type, String target, int qId) {
        questTargetType = type;
        questTarget = target;
        questId = qId;
    }

    public static void updateEsp(int kind, String label, List<float[]> pts) {
        espKind = kind;
        espLabel = label;
        espPts = pts;
    }

    // ---- computed helpers ----

    public static boolean isIceKing() { return playerClass == 4; }

    /** Ato atual (1-based) calculado a partir de missões concluídas. */
    public static int act() {
        return Math.min((completed / 10) + 1, 11);
    }

    /** Nome da facção para exibição. */
    public static String factionName() {
        return switch (faction) {
            case 1 -> "Luz";
            case 2 -> "Trevas";
            default -> "Nenhuma";
        };
    }

    /** Nome da dimensão atual. */
    public static String dimensionName() {
        return inNiveria ? "Nivéria" : "Overworld";
    }

    /** Nome da classe do jogador (usado por ProfileScreen). */
    public static String className() {
        return switch (playerClass) {
            case PlayerData.CLASS_GUERREIRO -> "Guerreiro";
            case PlayerData.CLASS_MAGO      -> "Mago";
            case PlayerData.CLASS_ARQUEIRO  -> "Arqueiro";
            case PlayerData.CLASS_REI_GELO  -> "Rei Secreto do Gelo";
            default                         -> "Sem Classe";
        };
    }
}
