package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.client.ClientData;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Lobby principal temático de Valdoria. */
public class ValdoriaLobbyScreen extends Screen {
    private String page = "home";
    private static final String[] LABELS = {"PLAY", "MARKETPLACE", "QUESTS", "CASTELO", "MULTIPLAYER", "CLASSES"};
    private static final int[] COLORS = {0xFFB88735,0xFF7B4BC4,0xFF318CBA,0xFFB34B4B,0xFF368B76,0xFF5476B8};

    public ValdoriaLobbyScreen() { super(Component.literal("Valdoria — Lobby")); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float partial) {
        renderBackground(g);
        int panelW = Math.min(430, width - 24), panelH = Math.min(300, height - 24);
        int x = (width-panelW)/2, y = (height-panelH)/2;
        g.fillGradient(x,y,x+panelW,y+panelH,0xF20A1020,0xF2050812);
        g.renderOutline(x,y,panelW,panelH,0xFFB88735);
        g.fill(x,y,x+panelW,y+42,0xFF171321);
        g.fill(x,y+41,x+panelW,y+43,0xFFB88735);
        g.drawCenteredString(font,"§6§l✦ VALDORIA ✦",width/2,y+8,0xFFFFD77A);
        g.drawCenteredString(font,"§7A SAGA DO ENZO  •  REINO MULTIJOGADOR",width/2,y+25,0xFFB8B5C8);

        if ("home".equals(page)) {
            g.drawCenteredString(font,"§fEscolha seu próximo destino",width/2,y+57,0xFFFFFFFF);
            int bw=126,bh=48,gap=12;
            for(int i=0;i<LABELS.length;i++){
                int col=i%3,row=i/3;
                int bx=width/2-(bw*3+gap*2)/2+col*(bw+gap);
                int by=y+82+row*(bh+12);
                boolean hover=mx>=bx&&mx<=bx+bw&&my>=by&&my<=by+bh;
                g.fillGradient(bx,by,bx+bw,by+bh,hover?0xFF29334A:0xFF151D2D,0xFF090E19);
                g.renderOutline(bx,by,bw,bh,hover?0xFFFFD77A:COLORS[i]);
                g.drawCenteredString(font,"§l"+LABELS[i],bx+bw/2,by+17,0xFFFFFFFF);
                String sub=switch(i){case 0->"§7Entrar no reino";case 1->"§7Itens e relíquias";case 2->"§7Sua jornada";case 3->"§7Evolução pessoal";case 4->"§7Aliados online";default->"§7Poderes e classes";};
                g.drawCenteredString(font,sub,bx+bw/2,by+31,0xFFB9C2D2);
            }
            g.drawCenteredString(font,"§7Progresso: §f"+ClientData.completed+"§7 / 101 quests",width/2,y+panelH-20,0xFFB8B5C8);
        } else {
            g.drawCenteredString(font,"§6§l"+page.toUpperCase(java.util.Locale.ROOT),width/2,y+65,0xFFFFD77A);
            if ("marketplace".equals(page)) {
                g.drawCenteredString(font,"§7Mercado de Valdoria",width/2,y+100,0xFFFFFFFF);
                g.drawCenteredString(font,"§fRelíquias, equipamentos e cosméticos",width/2,y+122,0xFFFFFFFF);
                g.drawCenteredString(font,"§8A loja exibirá os itens registrados no mod.",width/2,y+145,0xFFAAAAAA);
                g.drawCenteredString(font,"§8Nenhuma compra com dinheiro real é feita aqui.",width/2,y+160,0xFFAAAAAA);
            } else if ("quests".equals(page)) {
                g.drawCenteredString(font,"§fMissões concluídas: §e"+ClientData.completed+"§7 / 101",width/2,y+112,0xFFFFFFFF);
                g.drawCenteredString(font,"§7Continue a história para desbloquear novas áreas.",width/2,y+137,0xFFAAAAAA);
            } else if ("castle".equals(page)) {
                int stage=Math.min(16,Math.max(0,(1+ClientData.completed*79/101)/5));
                g.drawCenteredString(font,"§fSeu castelo: §eEstágio "+stage+"§7 / 16",width/2,y+112,0xFFFFFFFF);
                g.drawCenteredString(font,"§7Cada marco de nível constrói uma nova parte.",width/2,y+137,0xFFAAAAAA);
                g.drawCenteredString(font,"§7Seu lote é exclusivo e salvo no servidor.",width/2,y+155,0xFFAAAAAA);
            } else if ("multiplayer".equals(page)) {
                g.drawCenteredString(font,"§fJogadores conectados",width/2,y+95,0xFFFFFFFF);
                int yy=y+116;
                if(minecraft!=null&&minecraft.getConnection()!=null){
                    for(var info:minecraft.getConnection().getOnlinePlayers()){
                        if(yy>y+panelH-45) break;
                        g.drawCenteredString(font,"§a• §f"+info.getProfile().getName(),width/2,yy,0xFFFFFFFF);
                        yy+=14;
                    }
                }
                g.drawCenteredString(font,"§7Visite os territórios dos jogadores no mundo.",width/2,y+panelH-30,0xFFAAAAAA);
            } else {
                g.drawCenteredString(font,"§7As classes são escolhidas durante a aventura.",width/2,y+120,0xFFAAAAAA);
            }
            g.drawCenteredString(font,"§eClique ou pressione ESC para voltar",width/2,y+panelH-17,0xFFFFD77A);
        }
        super.render(g,mx,my,partial);
    }

    @Override
    public boolean mouseClicked(double mx,double my,int button){
        if(button!=0) return super.mouseClicked(mx,my,button);
        if(!"home".equals(page)){page="home";return true;}
        int bw=126,bh=48,gap=12;
        int y=(height-Math.min(300,height-24))/2+82;
        for(int i=0;i<LABELS.length;i++){
            int bx=width/2-(bw*3+gap*2)/2+(i%3)*(bw+gap);
            int by=y+(i/3)*(bh+12);
            if(mx>=bx&&mx<=bx+bw&&my>=by&&my<=by+bh){
                switch(i){
                    case 0 -> { if(minecraft!=null) minecraft.setScreen(new WorldHubScreen()); }
                    case 1 -> page="marketplace";
                    case 2 -> page="quests";
                    case 3 -> page="castle";
                    case 4 -> page="multiplayer";
                    case 5 -> page="classes";
                }
                return true;
            }
        }
        return super.mouseClicked(mx,my,button);
    }

    @Override public boolean keyPressed(int key,int scan,int mods){
        if(key==GLFW.GLFW_KEY_ESCAPE&&!page.equals("home")){page="home";return true;}
        return super.keyPressed(key,scan,mods);
    }
    @Override public boolean isPauseScreen(){return false;}
}
