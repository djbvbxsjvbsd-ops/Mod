package com.valdoria.rpg.item;

import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.network.ModNetwork;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.Level;

public class ValdoriaSword extends SwordItem {
    private static final float MANA_COST = 20.0F;

    public ValdoriaSword(Tier tier, int dmg, float speed, Properties props) {
        super(tier, dmg, speed, props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack st = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer sp
                && !sp.getCooldowns().isOnCooldown(this) && PlayerData.getMana(sp) >= MANA_COST) {
            PlayerData.addMana(sp, -MANA_COST);
            for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, sp.getBoundingBox().inflate(5.0D),
                    x -> x != sp && x.isAlive() && !(x instanceof Player))) {
                e.hurt(sp.damageSources().playerAttack(sp), 12.0F);
            }
            ((ServerLevel) level).sendParticles(ParticleTypes.SWEEP_ATTACK, sp.getX(), sp.getY() + 1.0D, sp.getZ(), 12, 2.0D, 0.3D, 2.0D, 0.0D);
            sp.playSound(SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0F, 1.2F);
            sp.getCooldowns().addCooldown(this, 60);
            ModNetwork.sync(sp);
            return InteractionResultHolder.success(st);
        }
        return InteractionResultHolder.pass(st);
    }
}
