// [ModBusEvents.java] — registra atributos das entidades + skin layer do jogador
package com.valdoria.rpg.event;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.client.renderer.SkinLayer;
import com.valdoria.rpg.entity.*;
import com.valdoria.rpg.registry.ModEntities;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModBusEvents {

    @SubscribeEvent
    public static void onEntityAttributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.MALACHAR.get(), MalacharEntity.createAttributes().build());
        e.put(ModEntities.CRIATURA_CONGELADA.get(), CriaturaCongelada.createAttributes().build());
        e.put(ModEntities.ESQUELETO_CONGELADO.get(), EsqueletoCongelado.createAttributes().build());
        e.put(ModEntities.GUARDIAO_GLACIAL.get(), GuardiaoGlacial.createAttributes().build());
        e.put(ModEntities.SENHOR_GELO.get(), SenhorGelo.createAttributes().build());
        e.put(ModEntities.ENZO_GLACIAL.get(), EnzoGlacial.createAttributes().build());
        e.put(ModEntities.DRAGAO_GELO.get(), DragaoGelo.createAttributes().build());
        e.put(ModEntities.GUIA_ALDRIC.get(), GuiaAldric.createAttributes().build());
    }

    /**
     * Adiciona o SkinLayer ao renderer do jogador (slim e normal).
     * Isso faz a skin do mod sobrepor a skin vanilla no momento do render.
     * Executado apenas no lado cliente.
     */
    @SubscribeEvent
    @net.minecraftforge.api.distmarker.OnlyIn(Dist.CLIENT)
    public static void addPlayerLayers(EntityRenderersEvent.AddLayers e) {
        for (String skinType : new String[]{"default", "slim"}) {
            PlayerRenderer renderer = e.getSkin(skinType);
            if (renderer != null) {
                renderer.addLayer(new SkinLayer<>(renderer));
            }
        }
    }
}
