package com.valdoria.rpg.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.IronGolemRenderer;
import net.minecraft.client.renderer.entity.SkeletonRenderer;
import net.minecraft.client.renderer.entity.WitherSkeletonRenderer;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.monster.AbstractSkeleton;
import net.minecraft.world.entity.monster.Zombie;

/** Renderers com textura de gelo própria (textures/entity/*.png). */
public final class IceRenderers {
    private IceRenderers() {}

    private static ResourceLocation tex(String n) {
        return new ResourceLocation(ValdoriaMod.MODID, "textures/entity/" + n + ".png");
    }

    public static EntityRendererProvider<Zombie> zombie(String name, float scale) {
        return ctx -> new IceZombie(ctx, tex(name), scale);
    }
    public static EntityRendererProvider<AbstractSkeleton> skeleton(String name) {
        return ctx -> new IceSkeleton(ctx, tex(name));
    }
    public static EntityRendererProvider<AbstractSkeleton> witherSkeleton(String name) {
        return ctx -> new IceWither(ctx, tex(name));
    }
    public static EntityRendererProvider<IronGolem> golem(String name) {
        return ctx -> new IceGolem(ctx, tex(name));
    }

    static class IceZombie extends ZombieRenderer {
        private final ResourceLocation t; private final float s;
        IceZombie(EntityRendererProvider.Context c, ResourceLocation t, float s) { super(c); this.t = t; this.s = s; }
        @Override public ResourceLocation getTextureLocation(Zombie z) { return t; }
        @Override protected void scale(Zombie z, PoseStack ps, float pt) { ps.scale(s, s, s); }
    }
    static class IceSkeleton extends SkeletonRenderer {
        private final ResourceLocation t;
        IceSkeleton(EntityRendererProvider.Context c, ResourceLocation t) { super(c); this.t = t; }
        @Override public ResourceLocation getTextureLocation(AbstractSkeleton e) { return t; }
    }
    static class IceWither extends WitherSkeletonRenderer {
        private final ResourceLocation t;
        IceWither(EntityRendererProvider.Context c, ResourceLocation t) { super(c); this.t = t; }
        @Override public ResourceLocation getTextureLocation(AbstractSkeleton e) { return t; }
    }
    static class IceGolem extends IronGolemRenderer {
        private final ResourceLocation t;
        IceGolem(EntityRendererProvider.Context c, ResourceLocation t) { super(c); this.t = t; }
        @Override public ResourceLocation getTextureLocation(IronGolem e) { return t; }
    }
}
