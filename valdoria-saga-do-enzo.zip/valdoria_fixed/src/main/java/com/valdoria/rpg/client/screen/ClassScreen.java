// [ClassScreen.java] — Tela de escolha/troca de classe — visual tecnológico
package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.network.ClassChangePacket;
import com.valdoria.rpg.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class ClassScreen extends Screen {
    private static final int CARD_W = 78, CARD_H = 130;
    private static final int GAP = 6;
    private static final int COLS = 4;
    private static final int TOTAL_W = COLS * CARD_W + (COLS - 1) * GAP;

    // IDs das classes: 1=Guerreiro 2=Mago 3=Arqueiro 4=Rei Gelo
    private static final int[] CLASS_IDS = {1, 2, 3, 4};
    private static final String[] ICONS   = {"⚔", "✦", "➶", "❄"};
    private static final String[] NAMES   = {"Guerreiro", "Mago", "Arqueiro", "Rei do Gelo"};
    private static final String[] DESCS   = {
            "Corpo a corpo\nPoderoso. HP\nregen passivo.",
            "Mana +50%\nDano mágico\n+10%.",
            "Velocidade\n+10%. Fome\nreduzida.",
            "Debuffs -40%\nem Nivéria.\nRedemoinho!"
    };
    private static final String[] HOTKEYS = {"[1]", "[2]", "[3]", "[4]"};
    private static final int[] COLORS     = {0xFFCC2222, 0xFF9922CC, 0xFF22AA44, 0xFF1188CC};
    private static final int[] COLORS_HL  = {0xFFFF5555, 0xFFCC55FF, 0xFF55DD77, 0xFF44CCFF};

    public ClassScreen() { super(Component.literal("Classe")); }

    private int startX() { return width / 2 - TOTAL_W / 2; }
    private int startY() { return height / 2 - CARD_H / 2 - 24; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        boolean canChange = ClientData.classChanges < 2 || ClientData.playerClass == 0;
        int sx = startX(), sy = startY();

        // ─── Header ───────────────────────────────────────────────────────
        int headerH = 26;
        g.fillGradient(sx - 4, sy - headerH - 4, sx + TOTAL_W + 4, sy - 4, 0xFF050F1A, 0xFF020609);
        g.renderOutline(sx - 4, sy - headerH - 4, TOTAL_W + 8, headerH, 0xFF00BFFF);
        g.drawCenteredString(font, "§b⚡ SISTEMA DE CLASSES — VALDORIA RPG", width / 2, sy - headerH + 4, 0xFF00DFFF);

        // Status de trocas
        String changesText = ClientData.playerClass == 0
                ? "§7Escolha sua classe inicial"
                : "§7Trocas usadas: §f" + ClientData.classChanges + " §7/ §f2";
        g.drawCenteredString(font, changesText, width / 2, sy - headerH + 14, 0xFF7EC8E3);

        // ─── Cards de Classe ──────────────────────────────────────────────
        for (int i = 0; i < CLASS_IDS.length; i++) {
            int cx = sx + i * (CARD_W + GAP);
            boolean hovered = mx >= cx && mx <= cx + CARD_W && my >= sy && my <= sy + CARD_H;
            boolean isSelected = ClientData.playerClass == CLASS_IDS[i];
            boolean isLocked   = CLASS_IDS[i] == 4 && ClientData.completed < 69;
            drawCard(g, cx, sy, i, hovered, isSelected, isLocked, canChange);
        }

        // ─── Footer info ──────────────────────────────────────────────────
        int fy = sy + CARD_H + 8;
        g.fillGradient(sx - 4, fy, sx + TOTAL_W + 4, fy + 36, 0xFF030C16, 0xFF020609);
        g.renderOutline(sx - 4, fy, TOTAL_W + 8, 36, 0xFF005580);
        if (!canChange) {
            g.drawCenteredString(font, "§c✖ Limite de trocas atingido (2/2)", width / 2, fy + 6, 0xFFFF4444);
        } else if (ClientData.playerClass == 0) {
            g.drawCenteredString(font, "§aClique em uma classe ou use as teclas [1]-[4]", width / 2, fy + 6, 0xFF88FF88);
        } else {
            g.drawCenteredString(font, "§7Clique para trocar | Restam §f" + (2 - ClientData.classChanges) + "§7 troca(s)",
                    width / 2, fy + 6, 0xFF7EC8E3);
        }
        g.drawCenteredString(font, "§7[ESC] Fechar", width / 2, fy + 20, 0xFF334455);

        super.render(g, mx, my, pt);
    }

    private void drawCard(GuiGraphics g, int x, int y, int idx,
                          boolean hovered, boolean selected, boolean locked, boolean canChange) {
        int color    = COLORS[idx];
        int colorHL  = COLORS_HL[idx];
        int borderC  = selected ? colorHL : (hovered && canChange && !locked ? colorHL : color);
        int bgTop    = selected ? 0xFF0A1E30 : (hovered ? 0xFF071522 : 0xFF040E1A);
        int bgBot    = 0xFF020609;

        // Fundo
        g.fillGradient(x, y, x + CARD_W, y + CARD_H, bgTop, bgBot);
        // Borda (dupla se selecionado)
        g.renderOutline(x, y, CARD_W, CARD_H, borderC);
        if (selected) g.renderOutline(x + 2, y + 2, CARD_W - 4, CARD_H - 4, 0x55FFFFFF & borderC);

        // Glow no topo
        g.fillGradient(x, y, x + CARD_W, y + 24, (0x88 << 24 | (borderC & 0x00FFFFFF)), 0x00000000);

        // Ícone grande
        g.drawCenteredString(font, "§l" + ICONS[idx], x + CARD_W / 2, y + 14, hovered ? colorHL : color);

        // Nome
        g.drawCenteredString(font, "§l" + NAMES[idx], x + CARD_W / 2, y + 28, 0xFFE0F0FF);

        // Separador
        g.fill(x + 8, y + 38, x + CARD_W - 8, y + 39, borderC);

        // Descrição linha a linha
        String[] lines = DESCS[idx].split("\n");
        for (int l = 0; l < lines.length; l++) {
            g.drawCenteredString(font, "§7" + lines[l], x + CARD_W / 2, y + 44 + l * 10, 0xFFBBCCDD);
        }

        // Hotkey
        g.drawCenteredString(font, "§8" + HOTKEYS[idx], x + CARD_W / 2, y + CARD_H - 24, 0xFF446688);

        // Locked ou Selected overlay
        if (locked) {
            g.fill(x, y, x + CARD_W, y + CARD_H, 0xAA000000);
            g.drawCenteredString(font, "§c🔒", x + CARD_W / 2, y + CARD_H / 2 - 12, 0xFFFF4444);
            g.drawCenteredString(font, "§cQuest 70", x + CARD_W / 2, y + CARD_H / 2, 0xFFFF4444);
        } else if (selected) {
            g.drawCenteredString(font, "§a✔ ATIVO", x + CARD_W / 2, y + CARD_H - 12, 0xFF44FF88);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int sx = startX(), sy = startY();
        for (int i = 0; i < CLASS_IDS.length; i++) {
            int cx = sx + i * (CARD_W + GAP);
            if (mx >= cx && mx <= cx + CARD_W && my >= sy && my <= sy + CARD_H) {
                trySelect(CLASS_IDS[i]);
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_1) { trySelect(1); return true; }
        if (key == GLFW.GLFW_KEY_2) { trySelect(2); return true; }
        if (key == GLFW.GLFW_KEY_3) { trySelect(3); return true; }
        if (key == GLFW.GLFW_KEY_4) { trySelect(4); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private void trySelect(int classId) {
        if (ClientData.playerClass == classId) return;
        ModNetwork.INSTANCE.sendToServer(new ClassChangePacket(classId));
        onClose();
    }

    @Override public boolean isPauseScreen() { return false; }
}
