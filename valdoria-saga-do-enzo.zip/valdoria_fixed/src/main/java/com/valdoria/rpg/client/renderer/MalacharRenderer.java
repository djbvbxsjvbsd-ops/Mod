package com.valdoria.rpg.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.client.model.ZombieModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Zombie;

/** Enzo Demoníaco: skin própria + aura estilo Goku (muda com a vida). */
public class MalacharRenderer extends ZombieRenderer {
    private static final ResourceLocation TEX =
            new ResourceLocation(ValdoriaMod.MODID, "textures/entity/enzo_demonio.png");

    public MalacharRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.layers.removeIf(l -> l instanceof HumanoidArmorLayer); // armadura não cobre a skin
        this.addLayer(new DemonAura(this));
    }

    @Override
    public ResourceLocation getTextureLocation(Zombie z) { return TEX; }

    private static class DemonAura extends RenderLayer<Zombie, ZombieModel<Zombie>> {
        DemonAura(RenderLayerParent<Zombie, ZombieModel<Zombie>> p) { super(p); }

        @Override
        public void render(PoseStack ps, MultiBufferSource buf, int light, Zombie z,
                           float limbSwing, float limbSwingAmount, float partialTick,
                           float ageInTicks, float netHeadYaw, float headPitch) {
            float pct = z.getHealth() / z.getMaxHealth();
            float[] c;
            float intensity;
            if (pct <= 0.25F)      { c = new float[]{1.0F, 0.35F, 0.0F, 1.0F, 0.90F, 0.50F}; intensity = 1.0F; } // fúria
            else if (pct <= 0.60F) { c = new float[]{0.7F, 0.10F, 0.9F, 1.0F, 0.60F, 1.00F}; intensity = 0.7F; } // fase 2
            else                   { c = new float[]{0.9F, 0.05F, 0.05F, 1.0F, 0.50F, 0.30F}; intensity = 0.4F; } // fase 1

            ps.pushPose();
            ps.translate(0.0D, 1.501D, 0.0D);
            ps.scale(-1.0F, -1.0F, 1.0F); // desfaz a inversão do layer: Y para cima
            GokuAura.draw(ps, buf.getBuffer(RenderType.lightning()), ageInTicks, c,
                    intensity, 0.55F, 2.0F, 0.55F, pct <= 0.60F);
            ps.popPose();
        }
    }
}
