package com.valdoria.rpg.quest;

import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.entity.EnzoGlacial;
import com.valdoria.rpg.registry.ModEntities;
import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Set;

/** Ativa flags + highlight colorido em TODAS as quests 1-101. */
public final class QuestFlags {
    private QuestFlags() {}

    private static final double[] VILA    = {80, 0};
    private static final double[] TEMPLO  = {-120, 60};
    private static final double[] CASTELO = {0, 200};
    private static final double[] ARENA   = {0, 218};

    private static final Set<Block> PLACED = Set.of(
            Blocks.COBBLESTONE, Blocks.STONE_BRICKS, Blocks.OAK_PLANKS,
            Blocks.SPRUCE_PLANKS, Blocks.BRICKS, Blocks.DIRT);

    private static boolean near(ServerPlayer p, double[] c, double r) {
        double dx = p.getX() - c[0], dz = p.getZ() - c[1];
        return dx*dx + dz*dz <= r*r;
    }

    private static void set(ServerPlayer p, String flag, boolean cond) {
        if (cond && !PlayerData.hasFlag(p, flag)) PlayerData.setFlag(p, flag);
    }

    // ===== HIGHLIGHT COLORIDO — TODAS AS QUESTS 1-101 =====
    public static void tickHighlight(ServerPlayer sp) {
        int done = PlayerData.getCompleted(sp);
        if (done >= 101) return;

        int questIdx = done + 1;
        if (questIdx > QuestData.size()) return;

        Quest q = QuestData.get(questIdx);

        // Reenvia a cada 100 ticks (~5s) para não spammar
        int ticker = PlayerData.root(sp).getInt("highlight_tick");
        PlayerData.root(sp).putInt("highlight_tick", ticker + 1);
        if ((ticker + 1) % 100 != 0) return;

        String targetDisplay = formatTarget(q);
        if (targetDisplay == null) return;

        ChatFormatting color = getQuestColor(questIdx);

        MutableComponent msg = Component.literal("§l◆ MISSÃO " + questIdx + "/101: §r")
                .append(Component.literal(q.title())
                        .withStyle(Style.EMPTY.withColor(color).withBold(false)))
                .append(Component.literal(" §7▶ "))
                .append(Component.literal(targetDisplay)
                        .withStyle(Style.EMPTY.withColor(color).withBold(true).withItalic(true)));

        String progress = getProgress(sp, q);
        if (progress != null) {
            msg = msg.append(Component.literal(" §8(" + progress + ")"));
        }

        sp.sendSystemMessage(msg);
    }

    /**
     * Cor por ato:
     * Ato I   (1-10)  → amarelo ouro
     * Ato II  (11-20) → laranja
     * Ato III (21-30) → vermelho
     * Ato IV  (31-40) → magenta
     * Ato V   (41-50) → branco brilhante
     * Ato VI  (51-60) → ciano
     * Ato VII (61-70) → verde
     * Ato VIII(71-80) → azul
     * Ato IX  (81-90) → roxo
     * Ato X   (91-101)→ vermelho escuro
     */
    private static ChatFormatting getQuestColor(int id) {
        if (id <= 10) return ChatFormatting.GOLD;
        if (id <= 20) return ChatFormatting.YELLOW;
        if (id <= 30) return ChatFormatting.RED;
        if (id <= 40) return ChatFormatting.LIGHT_PURPLE;
        if (id <= 50) return ChatFormatting.WHITE;
        if (id <= 60) return ChatFormatting.AQUA;
        if (id <= 70) return ChatFormatting.GREEN;
        if (id <= 80) return ChatFormatting.BLUE;
        if (id <= 90) return ChatFormatting.DARK_PURPLE;
        return ChatFormatting.DARK_RED;
    }

    private static String formatTarget(Quest q) {
        return switch (q.type()) {
            case HAVE    -> "⬡ " + friendlyItem(q.target()) + " x" + q.amount();
            case KILL    -> "☠ " + friendlyEntity(q.target()) + " x" + q.amount();
            case FLAG    -> "⚑ " + friendlyFlag(q.target());
            case DIM     -> "⬟ Vá para: " + friendlyDim(q.target());
            case FACTION -> "✦ Escolha sua fação! [Luz ou Trevas]";
        };
    }

    private static String getProgress(ServerPlayer sp, Quest q) {
        return switch (q.type()) {
            case HAVE -> QuestManager.count(sp, q.target()) + "/" + q.amount();
            case KILL -> PlayerData.getKills(sp, q.target()) + "/" + q.amount();
            default   -> null;
        };
    }

    // ===== NOMES AMIGÁVEIS =====

    public static String friendlyItem(String id) {
        return switch (id) {
            // Ato I-V (overworld)
            case "minecraft:oak_log"                     -> "Troncos de Carvalho";
            case "minecraft:cobblestone"                  -> "Pedras";
            case "valdorianrpg:foundation_stone"          -> "Pedra de Fundação";
            case "minecraft:oak_planks"                   -> "Tábuas de Carvalho";
            case "minecraft:stone_bricks"                 -> "Pedras Lapidadas";
            case "minecraft:iron_ingot"                   -> "Lingotes de Ferro";
            case "minecraft:torch"                        -> "Tochas";
            case "minecraft:diamond"                      -> "Diamantes";
            case "minecraft:gold_ingot"                   -> "Lingotes de Ouro";
            case "minecraft:emerald"                      -> "Esmeraldas";
            case "minecraft:obsidian"                     -> "Obsidiana";
            case "minecraft:blaze_rod"                    -> "Hastes de Blaze";
            case "minecraft:quartz"                       -> "Quartzo";
            case "minecraft:polished_blackstone_bricks"   -> "Pedra Negra Polida";
            case "minecraft:gold_block"                   -> "Blocos de Ouro";
            case "minecraft:ender_pearl"                  -> "Pérolas do Fim";
            case "minecraft:ender_eye"                    -> "Olhos do Fim";
            case "minecraft:chorus_fruit"                 -> "Fruto do Coro";
            case "minecraft:end_stone"                    -> "Pedra do Fim";
            case "minecraft:purpur_block"                 -> "Bloco Púrpura";
            case "minecraft:nether_star"                  -> "Estrela do Nether";
            case "minecraft:beacon"                       -> "Beacon";
            case "minecraft:golden_apple"                 -> "Maçãs Douradas";
            case "valdorianrpg:guardian_essence"          -> "Essência do Guardião";
            case "minecraft:totem_of_undying"             -> "Totem da Imortalidade";
            case "valdorianrpg:ultimate_sword"            -> "Espada Definitiva";
            case "valdorianrpg:ultimate_chestplate"       -> "Peitoral Definitivo";
            case "valdorianrpg:dungeon_key"               -> "Chave da Masmorra";
            // Ato VI-X (Nivéria)
            case "minecraft:snow_block"                   -> "Blocos de Neve";
            case "minecraft:ice"                          -> "Blocos de Gelo";
            case "minecraft:spruce_log"                   -> "Troncos de Pinheiro";
            case "minecraft:bread"                        -> "Pão";
            case "minecraft:furnace"                      -> "Fornalha";
            case "minecraft:diamond_sword"                -> "Espada de Diamante";
            case "valdorianrpg:chave_glacial"             -> "Chave Glacial";
            case "valdorianrpg:cristal_glacial"           -> "Cristal Glacial";
            case "valdorianrpg:fragmento_glacial"         -> "Fragmento Glacial";
            case "valdorianrpg:espada_glacial"            -> "Espada Glacial";
            case "valdorianrpg:armadura_glacial_chestplate"-> "Peitoral Glacial";
            case "valdorianrpg:chave_real"                -> "Chave Real";
            case "valdorianrpg:coroa_niveria"             -> "Coroa de Nivéria";
            case "valdorianrpg:coracao_niveria"           -> "Coração de Nivéria";
            default -> id.contains(":") ? id.split(":")[1].replace("_", " ") : id;
        };
    }

    public static String friendlyEntity(String id) {
        return switch (id) {
            case "minecraft:zombie"            -> "Zumbis";
            case "minecraft:spider"            -> "Aranhas";
            case "minecraft:skeleton"          -> "Esqueletos";
            case "minecraft:creeper"           -> "Creepers";
            case "minecraft:piglin"            -> "Piglins";
            case "minecraft:wither_skeleton"   -> "Esqueletos Wither";
            case "minecraft:zombified_piglin"  -> "Piglins Zumbificados";
            case "minecraft:enderman"          -> "Endermen";
            case "minecraft:ender_dragon"      -> "Dragão do Fim";
            case "valdorianrpg:criatura_congelada"  -> "Criaturas Congeladas";
            case "valdorianrpg:esqueleto_congelado" -> "Esqueletos Congelados";
            case "valdorianrpg:guardiao_glacial"    -> "Guardiões Glaciais";
            default -> id.contains(":") ? id.split(":")[1].replace("_", " ") : id;
        };
    }

    public static String friendlyFlag(String flag) {
        return switch (flag) {
            case "malachar_dead"              -> "Derrote Malachar";
            case "portal_niveria_entered"     -> "Entre pela porta de Nivéria";
            case "nevasca_survived"           -> "Sobreviva à primeira nevasca";
            case "aldric_found_niveria"       -> "Aguarde a visão de Aldric (90s em Nivéria)";
            case "passagem_secreta_found"     -> "Desça abaixo de Y=40 na sala";
            case "portal_niveria_built"       -> "Tenha a Chave Glacial";
            case "ice_spikes_explored"        -> "Explore 100+ blocos do centro da sala";
            case "vila_nevada_found"          -> "Encontre a Vila Nevada (+80,0)";
            case "montanha_nevada_top"        -> "Suba acima de Y=40 na sala";
            case "templo_glacial_found"       -> "Encontre o Templo Glacial (-120,60)";
            case "livro_templo_found"         -> "Entre no Templo e abra o baú";
            case "profecia_niveria_read"      -> "Leia a Profecia (explore o templo)";
            case "forja_glacial_built"        -> "Tenha um Blast Furnace no inventário";
            case "guardiao_glacial_dead"      -> "Derrote o Guardião Glacial";
            case "rei_gelo_classe_desbloqueada" -> "Classe desbloqueada — pressione [C]";
            case "senhor_gelo_dead"           -> "Derrote o Senhor do Gelo";
            case "dragao_gelo_dead"           -> "Derrote o Dragão de Gelo";
            case "cidade_niveria_found"       -> "Chegue ao Castelo de Nivéria (0,200)";
            case "torre_glacial_built"        -> "Construa uma torre de 12 blocos";
            case "portal_arena_final_ativado" -> "Tenha a Coroa de Nivéria";
            case "castelo_enzo_glacial_entered"-> "Entre no Castelo do Enzo Glacial";
            case "arena_final_reached"        -> "Chegue à Arena Final (topo do castelo)";
            case "ultimo_guardiao_dead"       -> "Derrote o Último Guardião";
            case "enzo_glacial_dead"          -> "Derrote o Enzo Glacial";
            default -> flag.replace("_", " ");
        };
    }

    public static String friendlyDim(String dim) {
        return switch (dim) {
            case "minecraft:the_nether"    -> "Nether";
            case "minecraft:the_end"       -> "The End";
            case "minecraft:overworld"     -> "Overworld";
            case "valdorianrpg:niveria"    -> "Sala de Nivéria (portal no castelo)";
            default -> dim;
        };
    }

    // ===== LÓGICA PRINCIPAL =====

    public static void tick(ServerPlayer sp) {
        tickHighlight(sp);

        int done = PlayerData.getCompleted(sp);
        if (done < 49) return;
        boolean niv = sp.level().dimension().equals(NiveriaDimension.NIVERIA);

        set(sp, "portal_niveria_built", QuestManager.count(sp, "valdorianrpg:chave_glacial") >= 1);
        if (!niv) return;

        ServerLevel lvl = sp.serverLevel();
        int secs = PlayerData.root(sp).getInt("niveria_secs") + 1;
        PlayerData.root(sp).putInt("niveria_secs", secs);

        double sx = sp.getX(), sz = sp.getZ();

        set(sp, "nevasca_survived",         secs >= 60);
        set(sp, "aldric_found_niveria",     secs >= 90);
        // passagem secreta = descer para área abaixo do piso normal da sala
        set(sp, "passagem_secreta_found",   sp.getY() < 18);
        // explorar 100+ blocos do centro
        set(sp, "ice_spikes_explored",      sx*sx + sz*sz >= 100.0D*100.0D);
        set(sp, "vila_nevada_found",        near(sp, VILA, 40));
        // "montanha" na sala = subir nos picos de gelo (Y > 40)
        set(sp, "montanha_nevada_top",      sp.getY() >= 40);
        set(sp, "templo_glacial_found",     near(sp, TEMPLO, 30));
        set(sp, "livro_templo_found",       near(sp, TEMPLO, 12));
        set(sp, "profecia_niveria_read",    PlayerData.hasFlag(sp, "livro_templo_found"));
        set(sp, "forja_glacial_built",      QuestManager.count(sp, "minecraft:blast_furnace") >= 1);
        set(sp, "rei_gelo_classe_desbloqueada", PlayerData.hasFlag(sp, "guardiao_glacial_dead"));
        set(sp, "cidade_niveria_found",     near(sp, CASTELO, 60));
        set(sp, "torre_glacial_built",      pillar(sp, 12));
        set(sp, "portal_arena_final_ativado", QuestManager.count(sp, "valdorianrpg:coroa_niveria") >= 1);
        set(sp, "castelo_enzo_glacial_entered", near(sp, CASTELO, 20));
        set(sp, "arena_final_reached",
                near(sp, ARENA, 8) && lvl.getBlockState(sp.blockPosition().below()).is(Blocks.BLUE_ICE));

        spawnBoss(sp, done);
    }

    private static boolean pillar(ServerPlayer sp, int h) {
        ServerLevel l = sp.serverLevel();
        BlockPos p = sp.blockPosition().below();
        int n = 0;
        while (n < h && PLACED.contains(l.getBlockState(p.below(n)).getBlock())) n++;
        return n >= h;
    }

    private static void spawnBoss(ServerPlayer sp, int done) {
        if (done >= QuestData.size()) return;
        Quest q = QuestData.get(done + 1);
        if (q.type() != Quest.Type.FLAG) return;

        EntityType<?> type = switch (q.target()) {
            case "guardiao_glacial_dead", "ultimo_guardiao_dead" -> ModEntities.GUARDIAO_GLACIAL.get();
            case "senhor_gelo_dead"   -> ModEntities.SENHOR_GELO.get();
            case "dragao_gelo_dead"   -> ModEntities.DRAGAO_GELO.get();
            case "enzo_glacial_dead"  -> ModEntities.ENZO_GLACIAL.get();
            default -> null;
        };
        if (type == null) return;

        String key = "boss_spawned_" + q.id();
        if (PlayerData.hasFlag(sp, key)) return;
        PlayerData.setFlag(sp, key);

        ServerLevel lvl = sp.serverLevel();
        if (type == ModEntities.ENZO_GLACIAL.get()) { EnzoGlacial.spawnNear(sp); return; }

        Entity e = type.create(lvl);
        if (e == null) return;
        double x = sp.getX() + 8.0D, z = sp.getZ();
        double y = lvl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int)x, (int)z);
        e.moveTo(x, y, z, 0.0F, 0.0F);
        lvl.addFreshEntity(e);
    }
}
