# Valdoria: A Saga do Enzo — atualização multiplayer

## O que foi adicionado
- Lote de castelo exclusivo por UUID, persistido no `SavedData` do mundo.
- Cada jogador recebe um terreno em uma grade de 128 blocos; as construções deixam de usar o spawn global compartilhado.
- A evolução do castelo considera as 101 quests individuais do jogador e distribui os 16 estágios ao longo da campanha.
- Lobby inicial personalizado com PLAY, MARKETPLACE, QUESTS, CASTELO, MULTIPLAYER e CLASSES.
- PLAY abre o seletor de mundos já existente; as páginas de quests/castelo/jogadores exibem o progresso local sincronizado.

## Como jogar com outras pessoas
1. Instale a mesma versão do mod em todos os clientes.
2. Inicie um servidor Minecraft Forge 1.20.1 (47.x) com o mod instalado.
3. Os demais jogadores entram nesse servidor usando a mesma versão do mod.
4. Cada UUID recebe seu próprio lote quando o primeiro estágio do castelo é desbloqueado.

Também funciona em mundo LAN com o mod instalado em todos os participantes.

## Observações importantes
- O multiplayer usa a infraestrutura normal de servidor Forge; não cria matchmaking, contas ou servidores públicos automáticos.
- A página MARKETPLACE do lobby é a interface inicial/placeholder visual. Ela ainda não realiza compras nem transações.
- A página CLASSES é um atalho informativo; a escolha de classe continua integrada ao fluxo atual do mod.
- O projeto foi atualizado no código-fonte, mas não foi possível executar `gradle build` neste ambiente porque o pacote não contém `gradlew` e não há Gradle instalado. Compile com Java 17 e ForgeGradle no seu ambiente antes de distribuir o JAR.
