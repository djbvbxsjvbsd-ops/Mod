package com.valdoria.rpg.client.renderer;

import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.VillagerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.npc.Villager;

/**
 * Renderer do NPC Guia Aldric — usa modelo de Villager com textura própria.
 * Textura esperada: assets/valdorianrpg/textures/entity/guia_aldric.png
 */
public class GuiaRenderer extends VillagerRenderer {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ValdoriaMod.MODID, "textures/entity/guia_aldric.png");

    public GuiaRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public ResourceLocation getTextureLocation(Villager villager) {
        return TEXTURE;
    }
}
