package com.valdoria.rpg.client;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.entity.*;
import com.valdoria.rpg.registry.ModEntities;
import net.minecraft.client.model.ZombieModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(KeyMappings.PROFILE);
        e.register(KeyMappings.MAP);
        e.register(KeyMappings.HUD);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("valdoria_hud", HudOverlay::render);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        // Malachar usa renderer customizado que ignora drop chance de equipamento
        e.registerEntityRenderer(ModEntities.MALACHAR.get(),
            ctx -> new HumanoidMobRenderer<>(ctx,
                new ZombieModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5F) {});

        // Entidades glaciais
        e.registerEntityRenderer(ModEntities.ENZO_GLACIAL.get(), ZombieRenderer::new);
        e.registerEntityRenderer(ModEntities.CRIATURA_CONGELADA.get(), ZombieRenderer::new);
        e.registerEntityRenderer(ModEntities.ESQUELETO_CONGELADO.get(), ZombieRenderer::new);
        e.registerEntityRenderer(ModEntities.GUARDIAO_GLACIAL.get(), ZombieRenderer::new);
        e.registerEntityRenderer(ModEntities.SENHOR_GELO.get(), ZombieRenderer::new);
    }
}
