package com.valdoria.rpg.client;

/** Dados sincronizados do servidor mantidos no lado cliente. Thread-safe por ser só lido na main thread. */
public final class ClientData {
    private ClientData() {}

    public static int    faction    = 0;
    public static int    completed  = 0;
    public static float  mana       = 100F;
    public static float  maxMana    = 100F;
    public static boolean hudVisible = true;
    public static boolean inNiveria  = false;
    public static int    glacialFrags = 0;

    // Classe
    public static int playerClass  = 0;
    public static int classChanges = 0;
    public static int whirlpoolCd  = 0;

    // Spirit Aura
    public static int     auraTokens  = 0;
    public static int     auraLevel   = 0;  // nível máx desbloqueado
    public static int     auraEquipped = 0; // nível atualmente equipado
    public static boolean auraActive  = false;

    // ESP quest
    public static int    espKind = 0;
    public static String espLabel = "";
    public static java.util.List<float[]> espPts = java.util.List.of();
    public static int    questTargetType = 0;

    public static void update(int f, int c, float m, float mm) {
        faction = f; completed = c; mana = m; maxMana = mm;
    }
    public static void updateClass(int cls, int cc, int wcd) {
        playerClass = cls; classChanges = cc; whirlpoolCd = wcd;
    }
    public static void updateAura(int tokens, int level, int equipped, boolean active) {
        auraTokens = tokens; auraLevel = level; auraEquipped = equipped; auraActive = active;
    }
    public static boolean isIceKing() { return playerClass == 4; }
}
