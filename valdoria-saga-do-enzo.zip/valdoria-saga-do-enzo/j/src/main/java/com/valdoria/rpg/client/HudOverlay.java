// [HudOverlay.java] — SUBSTITUI o original; adiciona indicador de frio e fragmentos glaciais
package com.valdoria.rpg.client;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.client.gui.overlay.ForgeGui;
public class HudOverlay {
    private static final int PW = 120, PH = 60, MARGIN = 4;
    private static final float TEXT_SCALE = 0.6F;
    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui || !ClientData.hudVisible) return;
        double guiScale = mc.getWindow().getGuiScale();
        float target = Math.max(190.0F, Math.min(mc.getWindow().getWidth() * 0.20F, 320.0F));
        float s = (float) (target / (PW * guiScale));
        s = Math.max(0.5F, Math.min(s, 2.0F));
        s = Math.min(s, (h * 0.40F) / PH);
        g.pose().pushPose();
        g.pose().translate(MARGIN, MARGIN, 0.0F);
        g.pose().scale(s, s, 1.0F);
        g.fill(0, 0, PW, PH, 0xAA101018);
        g.renderOutline(0, 0, PW, PH, ClientData.inNiveria ? 0xFF4488FF : 0xFFB8860B);
        InventoryScreen.renderEntityInInventoryFollowsMouse(g, 16, 44, 18, 16.0F, -6.0F, p);
        int bx = 34, bw = 80, bh = 8;
        bar(g, mc.font, bx, 4, bw, bh, p.getHealth() / Math.max(1.0F, p.getMaxHealth()), 0xFFD32F2F,
                String.format("HP %.0f/%.0f", p.getHealth(), p.getMaxHealth()));
        bar(g, mc.font, bx, 14, bw, bh, ClientData.mana / Math.max(1.0F, ClientData.maxMana), 0xFF2979FF,
                String.format("Mana %.0f", ClientData.mana));
        bar(g, mc.font, bx, 24, bw, bh, p.experienceProgress, 0xFF43A047, "XP Nv " + p.experienceLevel);
        bar(g, mc.font, bx, 34, bw, bh, p.getFoodData().getFoodLevel() / 20.0F, 0xFFF57C00,
                "Fome " + p.getFoodData().getFoodLevel());
        int totalQ = Math.max(101, ClientData.completed + 1);
        text(g, mc.font, "Ato " + ClientData.act() + " | " + Math.min(101, ClientData.completed + 1) + "/101", bx, 45, 0xFFE0B040);
        if (ClientData.inNiveria) {
            text(g, mc.font, "§b❄ FRIO  Frags: " + ClientData.fragmentosGlaciais, bx, 53, 0xFF88CCFF);
        }
        g.pose().popPose();
    }
    private static void bar(GuiGraphics g, Font font, int x, int y, int w, int h, float frac, int color, String t) {
        frac = Math.max(0.0F, Math.min(1.0F, frac));
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + 1 + (int) ((w - 2) * frac), y + h - 1, color);
        text(g, font, t, x + 3, y + 2, 0xFFFFFFFF);
    }
    private static void text(GuiGraphics g, Font font, String t, int x, int y, int color) {
        g.pose().pushPose();
        g.pose().scale(TEXT_SCALE, TEXT_SCALE, 1.0F);
        g.drawString(font, t, (int) (x / TEXT_SCALE), (int) (y / TEXT_SCALE), color, false);
        g.pose().popPose();
    }
}
